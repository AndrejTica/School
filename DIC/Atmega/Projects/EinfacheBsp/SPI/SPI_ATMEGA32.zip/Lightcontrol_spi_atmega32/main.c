#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "spi.h"

uint8_t aAddress;
uint8_t aData;

int main (void)
{
	aAddress = 0x21;
	aData = 31;

	spiMasterInit();

	while(1)
	{
		_delay_ms(10);
		spiMasterWrite(aData);
	}

	return(0);
}
