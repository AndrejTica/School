/**
 * 
 * Autor: pfleury
 * Date : 20.12.2008
 *
 * @defgroup avr_lib spi Library
 *
 * @brief Provide several spi functions
 *
**/

	//#include "default.h"
	#include "spi.h"
	#include <avr/io.h>

	/**
	 * @brief Initialize SPI Master connection (current chip is master)
	**/
	void spiMasterInit(void)
	{
		/* Set MOSI,SCK and SS output, all others input */
		DDRB |= (1<<PB5)|(1<<PB7)|(1<<PB4);
        DDRB &= ~(1<<PB6);
		/* Enable SPI, Master, set clock rate fck/8 */
		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0)|(1<<CPHA)|(1<<CPOL);
        SPCR &= ~(1<<DORD);
        SPSR |= (1<<SPI2X);
	}

	/**
	 * @brief Write byte to slave
	 * @param data Data to transmit
	**/
	unsigned char spiMasterRead(uint8_t cData)
	{
		/* Start transmission */
		SPDR = cData;
		/* Wait for transmission complete */
		loop_until_bit_is_set(SPSR, SPIF);
        /* Recieve Byte */
		SPDR = 0x00;
		/* Wait for transmission complete */
		loop_until_bit_is_set(SPSR, SPIF);
        
        return SPDR;
	}
	/**
	 * @brief Write byte to slave
	 * @param data aData to transmit
                   aAddress   
	**/
	void spiMasterWrite(uint8_t cData)
	{
		SPCR  |= (1<<MSTR); ///Set SPI Master again, I don't know why but pfleurys lib always resets the bit and after 3h of debugging i just fixed it like that.
		/* Start transmission */
		SPDR = cData;
		/* Wait for transmission complete */
		while(!(SPSR & (1<<SPIF)));
	}
	
