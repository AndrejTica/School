/**
 * 
 * Autor: pfleury
 * Date : 20.12.2008
 *
 * @defgroup avr_lib spi Library
 *
 * @brief Provide several spi functions
 *
**/

#ifndef _SPI_H
	#define _SPI_H  
    
    #include <avr/io.h> 

    volatile uint8_t icnt;
    volatile unsigned char * volatile iptr;
 

	/**
	 * @brief Initialize SPI Master connection (current chip is master)
	**/
	void spiMasterInit(void);

	/**
	 * @brief Write byte to slave
	 * @param cData Data to transmit
	**/
	uint8_t spiMasterRead(uint8_t cData);
    

    /**
	 * @brief Write byte to slave
	 * @param cData Data to transmit
	**/
	void spiMasterWrite(uint8_t cData);    


#endif
