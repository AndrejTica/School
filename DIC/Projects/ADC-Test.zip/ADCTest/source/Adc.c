//! ADC.c
/*! A interface for the easy use of the ADC
 * @file Adc.c
 * @author    Ingomar Mayer
 * @version   1.0
 * @date      2019
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "Adc.h"

uint16_t *analogRead_addressVar = 0;  //!< this variable is used for the functions that rely on the ISR and thus need the address of the save variable

/*
static const uint8_t AdcPrescaler[] = {
	0x0,	// ADC_P2,
	0x2,	// ADC_P4,
	0x3,	// ADC_P8,
	0x4,	// ADC_P16,
	0x5,	// ADC_P32,
	0x6,	// ADC_P64,
	0x7 	// ADC_P128
};

static const uint8_t AdcRefVoltage[] = {
	0x0		//ADC_RVOLTAGE_AREF,
	0x1		//ADC_RVOLTAGE_AVCC,
	0x2		//ADC_RVOLTAGE_A11,
	0x3		//ADC_RVOLTAGE_A256
};
*/

void initADC(TADCRefVoltage refVoltage, TADCPrescaler prescaler){
	ADCSRA = 0;
	ADCSRB = 0;
	ADMUX = 0;
	
	ADCSRA |= ((prescaler+1) << ADPS0);
	ADMUX |= (refVoltage << REFS0);
	ADCSRA |= (1<<ADEN);
}

uint16_t analogRead(uint8_t adcPin){
	ADMUX |= (adcPin<<MUX0);
	ADCSRA |= (1<<ADSC);
	while ((ADCSRA>>ADSC)&0x01){}
	uint16_t result = ADCL;
	result += ADCH<<8;
	return result;
}

void analogRead_v(uint8_t adcPin, uint16_t *addressVar){
	analogRead_addressVar = addressVar;
	ADMUX |= (adcPin<<MUX0);
	ADCSRA |= (1<<ADIE);
	sei();
	ADCSRA |= (1<<ADSC);
}

uint16_t analogRead_FreeRunMode(){
	uint16_t result = ADCL;
	result += ADCH<<8;
	return result;
}

void analogRead_Noiseless(uint8_t adcPin, uint16_t *addressVar){
	analogRead_addressVar = addressVar;
	ADCSRA &= ~(1<<ADATE);
	ADCSRA |= (1<<ADIE);
	ADMUX |= (adcPin<<MUX0);
	sei();
	SMCR |= (1<<SM0);
	SMCR &= ~((1<<SM1) | (1<<SM2));
	SMCR |= (1<<SE);
}
	
void startADC_FreeRunMode(uint8_t adcPin){
	ADMUX |= (adcPin<<MUX0);
	ADCSRA |= (1<<ADATE);
	ADCSRA |= (1<<ADSC);
}
	
void stopADC_FreeRunMode(){
	ADCSRA &= ~(1<<ADATE);
}

void stopADC(){
	ADCSRA = 0;
	ADMUX = 0;
	ADCSRB = 0;
}

ISR(ADC_vect){
	SMCR &= ~(1<<SE);
	uint16_t result = ADCL;
	result += ADCH<<8;
	*analogRead_addressVar = result;
}
