/*
 * HTLStddef
 *
 * Created: 29.05.2019 14:37:36
 * Author : ingom
 */ 

#ifndef HTLSTDDEV
#define HTLSTDDEV

typedef enum
{
	EFALSE = 0,
	ETRUE = 1
} TBool;

#endif