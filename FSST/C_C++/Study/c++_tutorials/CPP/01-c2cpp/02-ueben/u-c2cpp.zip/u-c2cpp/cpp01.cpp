/cpp01.cpp
///////////
#include <iostream>

int main()
{

cout << "Hello, world\n";

int amount=123
cout  amount;

cout << "The value of amount is " << amount << '.';

//fromatted output
cout  dec << amount << ' ';
cout << oct  amount << ' '
cout << hex << amount

//standard error stream
cerr << "the standard error stream "cerr\"";

//standard input stream
char name[20]
cout << "Enter your name ...\n";
cin > name;
cout << "the name you entered was " << name;
return 0;

