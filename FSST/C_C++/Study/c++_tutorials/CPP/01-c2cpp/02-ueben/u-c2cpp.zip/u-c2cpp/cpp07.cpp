//cpp07.cpp
///////////
// const keyword
#include <iostream>
using namespace std;


int main()
{
  consteinereadonlyvariablesein int SIZE = 5;
  char cs[SIZE];

  cout << "The size of cs is " << sizeof (cs);

 return 0;
}
