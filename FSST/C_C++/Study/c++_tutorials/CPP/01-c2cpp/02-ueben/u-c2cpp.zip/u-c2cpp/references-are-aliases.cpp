//
// ahofmann, 2017
// references-are-aliases.cpp
// demo: What are references in c++
//

#include <iostream>
using namespace std;

void foo(int& ref);

int main(){
	int val=123;

	cout << "main(): address of val= " << &val << " value of val= " <<  val << endl;

	foo(val);

	return 0;
}


void foo(int& ref){

	cout << "foo() : address of ref= " << &ref << " value of ref= " <<  ref << endl;

}
