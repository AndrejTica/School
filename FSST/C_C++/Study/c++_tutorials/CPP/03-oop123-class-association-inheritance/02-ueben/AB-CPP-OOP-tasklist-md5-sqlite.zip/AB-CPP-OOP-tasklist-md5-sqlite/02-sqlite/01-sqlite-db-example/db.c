/*
*
1.) install sqlite
	sudo apt-get install sqlite3
	sudo apt-get install libsqlite3-dev 


2.) create sql-script: people.sql
create table people (
        id              integer,
        firstname       varchar(20),
        lastname        varchar(20),
        phonenumber     char(10)
);

insert into people (id, firstname, lastname, phonenumber) values
        (1, 'Fred', 'Flintstone', '5055551234');
insert into people (id, firstname, lastname, phonenumber) values
        (2, 'Wilma', 'Flintstone', '5055551234');
insert into people (id, firstname, lastname, phonenumber) values
        (3, 'Barny', 'Rubble', '5055554321');
        

3.) create database people.sqlite 
	sqlite3 people.sqlite < people.sql

	strings < people.sqlite

4.) Edit db.c (see later) and compile
	gcc db.c -o db.exe -lsqlite3


5.) manage SQLITE databases with
	https://addons.mozilla.org/de/firefox/addon/sqlite-manager/
	or
	http://sqlitestudio.one.pl/index.rvt?act=download
*/

#include <stdio.h>
#include <stdlib.h>

#include <sqlite3.h>

#define DBNAME "people.sqlite"

int main(void) {
	sqlite3* conn;
	sqlite3_stmt* res;
	
	int error = 0;
	int rec_count = 0;
	const char* errMSG;
	const char* tail;


	error = sqlite3_open(DBNAME, &conn);
	if (error) {
		puts("Can not open database");
		exit(0);
	}

	error = sqlite3_exec(conn,
	"update people set phonenumber=\'5055559999\' where id=3",
	0, 0, 0);

	error = sqlite3_prepare_v2(conn,
	"select lastname,firstname,phonenumber,id from people order by id",
	-1, &res, &tail);

	if (error != SQLITE_OK) {
		puts("We did not get any data!");
		exit(0);
	}

	puts("========================================");
	rec_count=0;
	while (sqlite3_step(res) == SQLITE_ROW) {
		printf("%10s|", sqlite3_column_text(res, 0)); // lastname
		printf("%10s|", sqlite3_column_text(res, 1)); // firstname
		printf("%10s|", sqlite3_column_text(res, 2)); // phonenumber
		printf("%u\n", sqlite3_column_int(res, 3)); // id

		rec_count++;
	}
	puts("========================================");
	printf("We received %d records.\n", rec_count);

	sqlite3_finalize(res);
	sqlite3_close(conn);

	return 0;
}

