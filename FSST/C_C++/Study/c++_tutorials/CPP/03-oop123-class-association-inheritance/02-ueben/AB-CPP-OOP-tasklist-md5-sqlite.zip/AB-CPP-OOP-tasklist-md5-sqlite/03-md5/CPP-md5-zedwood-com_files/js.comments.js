$( document ).ready(function() {
    Comments.setup();
});
var Comments = {};
Comments.setup = function() {
	$("#comment-border").show();
	var h = getHashParams();
	if (h['msg']=='thanks')
	{
		$("#comment-border").show();
		$("#comment-form").append('<span style="color:blue">Thanks! we\'ll review your comment when we get a chance.</span>');
		return;
	}

	var form = $("<form></form>");
	form.attr('action', document.URL);
	form.attr('method', 'POST');
	form.attr('onsubmit', 'Comments.onSubmit');

	var td1_label = $('<td>Name:</td>');
	var td1_input = $('<td><input type="text" name="author" class="simple" /></td>');
	var tr1 = $('<tr></tr>').append(td1_label).append(td1_input);

	var td2_label = $('<td>Email:</td>');
	var td2_input = $('<td><input type="text" name="email" class="simple" /></td>');
	var tr2 = $('<tr></tr>').append(td2_label).append(td2_input);

	var td3_label = $('<td>URL:</td>');
	var td3_input = $('<td><input type="text" name="url" class="simple" /></td>');
	var tr3 = $('<tr></tr>').append(td3_label).append(td3_input);
	
	var table = $('<table></table>').append(tr1).append(tr2).append(tr3);
	var textarea = $('<textarea name="comments" rows="6" style="width:99%" id="commentarea" style="color:#999;">Add your comment</textarea>');
	textarea.attr('onfocus', "if (this.innerHTML=='Add your comment'){ this.innerHTML='';} this.style.color='#000000';");
	var button = $('<button type="submit" name="submit_button">Submit</button>');

	form.append(table);
	form.append(textarea);
	form.append(button);
	$('#comment-form').append(form);

	//$('input[name=author]').val( getCookie('cmta') );
	//$('input[name=email]').val( getCookie('cmte') ? getCookie('cmte').replace('|','@') : '' );
	//$('input[name=url]').val( getCookie('cmtu') );
}
Comments.onSubmit = function()
{
	//setCookie('cmta', $('input[name=author]').val() );
	//setCookie('cmte', $('input[name=email]').val().replace('@','|') );
	//setCookie('cmtu', $('input[name=url]').val()    );
	return true;
}

function getCookie( name ) {
	var start = document.cookie.indexOf( name + "=" );
	var len = start + name.length + 1;
	if ( ( !start ) && ( name != document.cookie.substring( 0, name.length ) ) ) {
		return null;
	}
	if ( start == -1 ) return null;
	var end = document.cookie.indexOf( ';', len );
	if ( end == -1 ) end = document.cookie.length;
	return unescape( document.cookie.substring( len, end ) );
}

function setCookie( name, value, expires, path, domain, secure ) {
	var today = new Date();
	today.setTime( today.getTime() );
	expires = expires? expires * 1000 * 60 * 60 * 24 : 5 * 1000 * 60 * 60 * 24;//default 5 days
	var expires_date = new Date( today.getTime() + (expires) );
	document.cookie = name+'='+escape( value ) +
		( ( expires ) ? ';expires='+expires_date.toGMTString() : '' ) + //expires.toGMTString()
		( ( path ) ? ';path=' + path : '' ) +
		( ( domain ) ? ';domain=' + domain : '' ) +
		( ( secure ) ? ';secure' : '' );
}

function deleteCookie( name, path, domain ) {
	if ( getCookie( name ) ) document.cookie = name + '=' +
			( ( path ) ? ';path=' + path : '') +
			( ( domain ) ? ';domain=' + domain : '' ) +
			';expires=Thu, 01-Jan-1970 00:00:01 GMT';
}

function getHashParams() {

    var hashParams = {};
    var e,
        a = /\+/g,  // Regex for replacing addition symbol with a space
        r = /([^&;=]+)=?([^&;]*)/g,
        d = function (s) { return decodeURIComponent(s.replace(a, " ")); },
        q = window.location.hash.substring(1);

    while (e = r.exec(q))
       hashParams[d(e[1])] = d(e[2]);

    return hashParams;
}
