/*

TEIL 1: sqlite installieren und erstes C Programm
------------------------------------------------------------------------------

http://www.linuxjournal.com/content/accessing-sqlite-c

sudo apt-get install sqlite
sudo apt-get install libsqlite3-dev 


Datei: people.sql
create table people (
        id              integer,
        firstname       varchar(20),
        lastname        varchar(20),
        phonenumber     char(10)
);

insert into people (id, firstname, lastname, phonenumber) values
        (1, 'Fred', 'Flintstone', '5055551234');

insert into people (id, firstname, lastname, phonenumber) values
        (2, 'Wilma', 'Flintstone', '5055551234');

insert into people (id, firstname, lastname, phonenumber) values
        (3, 'Barny', 'Rubble', '5055554321');
        

        
sqlite3 people.sl3 < create.sql

strings < people.sl3

gcc ./db.c -o db -lsqlite3


TEIL 2: SQLITE DB verwalten
------------------------------------------------------------------------------
1.) https://addons.mozilla.org/de/firefox/addon/sqlite-manager/
2.) http://sqlitestudio.one.pl/index.rvt?act=download
/opt/sqlitestudio/sqlitestudio


TEIL 3: CPP Wrapper Klasse für SQLITE
------------------------------------------------------------------------------
http://sqlitewrapper.kompex-online.com/index.php?content=download



TEIL 4: MD5 Hash Function
------------------------------------------------------------------------------
http://www.zedwood.com/article/121/cpp-md5-function



TEIL 5: BeagleBoard-Verwaltung (BB)
------------------------------------------------------------------------------
USER (username, klasse, email, tel, beschreibung)
BB (id, beschreibung)
ENTLEHNUNG(startDatum,endDatum, bb_id, username)

Mit Trigger: create_date, modify_date, deleted

Erfasse: USER,BB
Erfasse: ENTLEHUNG (user und bb müssen existieren)
Lösche: USER,BB
Lösche: ENTLEHNUNG


Liste: USER,BB,
Liste: ENTLEHUNG
Liste: Wieviele BB sind noch verfügbar
Liste: Wieviele BB sind entlehnt [von User]
Liste: Wer ist zu mahnen (hat das EntlehnDatum überschritten)



*/


#include <stdio.h>
#include <stdlib.h>

#include <sqlite3.h>

#define DBNAME "people.sl3"


int main(void) {
	sqlite3* conn;
	sqlite3_stmt* res;
	
	int error = 0;
	int rec_count = 0;
	const char* errMSG;
	const char* tail;


	error = sqlite3_open(DBNAME, &conn);
	if (error) {
		puts("Can not open database");
		exit(0);
	}

	error = sqlite3_exec(conn,
	"update people set phonenumber=\'5055559999\' where id=3",
	0, 0, 0);

	error = sqlite3_prepare_v2(conn,
	"select lastname,firstname,phonenumber,id from people order by id",
	1000, &res, &tail);

	if (error != SQLITE_OK) {
		puts("We did not get any data!");
		exit(0);
	}

	puts("==========================");

	rec_count=0;
	while (sqlite3_step(res) == SQLITE_ROW) {
		printf("%s|", sqlite3_column_text(res, 0)); // id
		printf("%s|", sqlite3_column_text(res, 1)); // firstname
		printf("%s|", sqlite3_column_text(res, 2)); // lastname
		printf("%u\n", sqlite3_column_int(res, 3)); // phonenumber

		rec_count++;
	}

	puts("==========================");

	printf("We received %d records.\n", rec_count);

	sqlite3_finalize(res);

	sqlite3_close(conn);

	return 0;
}

