forkme.c
	zeigt fork(), getpid(), getppid()
	gemeinsam


forkSortChild.c
	zeigt auch pipe()
	gemeinsam

forkSortBoth-Merge.c 
	(via fileChild.bin, fileParent.bin)
	allein

