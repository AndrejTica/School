Aufgaben: Threads und fork in C
