/*
 * Reduzierung des Bildschirmflackerns
http://javacooperation.gmxhome.de/BildschirmflackernDeu.html


Wie ihr in dem vorigen Beispiel sicherlich bemerkt habt, flackert der Ball sehr stark. 
Der Grund daf�r ist recht einfach. 

Vor jedem Aufruf der Methode paint() durch repaint() in unserem Thread wird das Bild vollst�ndig 
gel�scht um dann erneut gezeichnet zu werden. 
Dadurch erscheint f�r den Bruchteil einer Sekunde ein vollkommen leerer Bildschirm, 
was wir als Flackern wahrnehmen. Um dieses Flackern des Bildes zu verhindern, gibt es 
zun�chst drei verschiedene M�glichkeiten.

   1. Bildschirm nicht l�schen
   2. Bildschirm nur dort l�schen, wo es n�tig ist
   3. Die Doppelpufferung

Bildschirm nicht l�schen

Dieser Ansatz erscheint auf den ersten Blick als die L�sung aller Probleme. 
In unserem Fall w�rde es aber bedeuten, dass der Ball eine dicke, rote Linie 
hinterlassen w�rde. Wir wollen den Ball aber als bewegten Ball wahrnehmen 
und nicht als Objekt, dass eine rote Linie hinter sich herzieht. 
Das L�schen des Bildschirmes zu unterdr�cken ist also nur 

	f�r nicht bewegte Animationen sinnvoll.
	
Auch f�r den sp�teren Verlauf dieser Lektion ist es wichtig zu verstehen, dass 
jedesmal wenn repaint() aufgerufen wird, nicht gleich auch die Methode paint() aufgerufen wird. 
Stattdessen ist eine Methode namens update() dazwischengeschaltet. 
Wird diese nicht �berschrieben, so ist diese Methode daf�r verantwortlich, 

dass der Bildschirm mit einem leeren Bild �berlagert und anschlie�end durch den Aufruf von paint() 
von der Methode update() aus, neu gezeichnt wird. 
Um also das L�schen des Bildschirms zu unterdr�cken, muss man update() so �berschreiben, 
dass sie nur noch paint() aufruft. Dies ist in drei Zeilen zu bewerkstelligen.
public void update(Graphics g)
{

      paint(g);

}

Wie gesagt ist diese M�glichkeit nur bei statischen Animationen wirklich praktikabel 
und wird somit nur selten verwendet.


Bildschirm nur dort l�schen, wo es n�tig ist

Die Idee dieses Ansatzes besteht darin, den Bildschirm nur dort zu l�schen, 
wo sich im letzten Schritt ein Graphikelement befunden hat, sich nun aber 
keines mehr befindet. Dieser Ansatz l�sst sich z. B. bei dem sehr bekannten 
Spiel Snakin' ganz gut umsetzen, indem man als letztes Glied der Schlange ein 
Element in der Farbe des Hintergrundes, und somit unsichtbares Element, anh�ngt. 
Dadurch wird immer beim n�chsten Schritt das vorher letzte Element �berlagert. 
Da sich diese Methode nur in bestimmten F�llen anwenden l��t und dann immer nach 
einer, auf das spezifische Problem abgestimmten, Vorgehensweise verlangt, m�chte 
ich nicht n�her auf diese Methode eingehen. 


Wenden wir uns stattdessen der sogenannten Doppelpufferung zu, die man als 
Standardmethode ohne Abwandlung in jedes Applet mit Animationen �bernehmen 
und somit das Flakern des Bildes effektiv unterdr�cken kann.

Die Doppelpufferung

Die Doppelpufferung kann in jedes Applet, ohne gro�en, programiertechnischen Aufwand 
eingebaut werden. Beim Doppelpuffern wird bei jedem Animationsschritt zun�chst die 
gesamte Bildschirmausgabe in ein Offscreen-Image geschrieben. 
Erst wenn alle Ausgabeoperationen abgeschlossen sind, wird dieses Offscreen-Image 
auf die Fensteroberfl�che kopiert. Im Detail sind dazu folgende Schritte erforderlich:

   1. Das Fensterobjekt beschafft sich durch Aufruf von createImage ein Offscreen-Image und 
      speichert es in einer Instanzvariablen ( = Erzeugen eines leeren Bildes)
   2. Durch Aufruf von getGraphics wird ein Grafikkontext zu diesem Image beschafft
   3. Alle Bildschirmausgaben (inklusive L�schen des Bildschirms) gehen zun�chst 
      auf den Offscreen-Grafikkontext ( = Zeichnen des Bildes im Hintergrund)
   4. Wenn alle Ausgabeoperationen abgeschlossen sind, wird das Offscreen-Image mit 
   drawImage in das Ausgabefenster kopiert. ( = Zeichnen des Bildes im Vordergrund)

Durch diese Vorgehensweise wird erreicht, dass das Bild komplett aufgebaut ist, 
bevor es angezeigt wird. Da beim anschlie�enden Kopieren die neuen Pixel direkt �ber die 
alten kopiert werden, erscheinen dem Betrachter nur die Teile des Bildes ver�ndert, 
die auch tats�chlich ge�ndert wurden. Ein Flackern, das entsteht, weil Fl�chen f�r 
einen kurzen Zeitraum gel�scht und dann wieder gef�llt werden, kann nicht mehr auftreten.

Einziger, gravierender Nachteil der Doppelpufferung ist jedoch, dass die Konstruktion 
des OffscreenImages ziemlich speicheraufwendig ist, und au�erdem die Bilddaten 
zweimal geschrieben werden. In den meisten F�llen und auf schnellen Rechnern ist es 
jedoch weitaus vorteilhafter, in sehr kurzer Zeit die Doppelpufferung zu realisieren, 
als sich lange mit der Suche nach alternativen M�glichkeiten aufzuhalten.

So, aber nach der ganzen Theorie nun zur Implementierung der Doppelpufferung in 
unserem Ball - Applet aus dem letzten Kapitel!
Der Programcode zur Umsetzung der Doppelpufferung
// Definition zweier Instanzvariablen f�r die Doppelpufferung im Kopf des Programmes
private Image dbImage;
private Graphics dbg;

... anderer Programcode ...

* Update - Methode, Realisierung der Doppelpufferung zur Reduzierung des Bildschirmflackerns 
public void update (Graphics g)
{

      // Initialisierung des DoubleBuffers
      if (dbImage == null)
      {
            dbImage = createImage (this.getSize().width, this.getSize().height);
            dbg = dbImage.getGraphics ();
      }

      // Bildschirm im Hintergrund l�schen
      dbg.setColor (getBackground ());
      dbg.fillRect (0, 0, this.getSize().width, this.getSize().height);

      // Auf gel�schten Hintergrund Vordergrund zeichnen
      dbg.setColor (getForeground());
      paint (dbg);

      // Nun fertig gezeichnetes Bild Offscreen auf dem richtigen Bildschirm anzeigen
      g.drawImage (dbImage, 0, 0, this);

}

Wie schon erw�hnt l��t sich der obige Programmcode in jedes Applet �bernehmen, 
so auch in unser Ball - Beispiel von vorher.
 */

import javax.swing.SwingUtilities;
import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JSlider;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class SpielFirstGame extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton jButtonStart = null;
	private JButton jButtonStop = null;
	private JButton jButtonEnd = null;
	private JPanel jPanelSpiel = null;

	private JLabel jLabel = null;
	private JLabel jLabel1 = null;
	private JLabel jLabel11 = null;
	private JLabel jLabel12 = null;

	
	private int ballX,ballY;
	private int ballBreite,ballHoehe;
	private int ballSchrittweiteX,ballSchrittweiteY;
	
	private int brettX,brettY;
	private int brettBreite,brettHoehe;
	private int brettRichtung; //rauf....-1,    runter ...1
	
	  
	private javax.swing.Timer spiel_timer;  //  @jve:decl-index=0:
	int delay; // in ms		

	Graphics spielfeld= null; //Spielfeld
	int spielfeld_breite; //Spielfeld breite
	int spielfeld_hoehe; //Spielfeld hoehe
	
	
	/**
	 * --------------------------------------------------
	 */

	public void startTimer()
	{		
		spiel_timer= new javax.swing.Timer
		(
			delay,
			new java.awt.event.ActionListener()
			{
				public void actionPerformed (java.awt.event.ActionEvent e)
					{
						actionGame();
						
						//ruft update() und dann paint() auf
						// beide k�nnen �berschrieben werden
						repaint();
					}
							
			}
		);
		
		spiel_timer.start();		
	}
	
	
	public void actionGame() {

		// Ball positionieren ,d.h. bewegen
		   ballX+=ballSchrittweiteX;
		   ballY+=ballSchrittweiteY;

		   brettY+=brettRichtung;

		   // Brett ist ganz oben
		   if (brettY<0) {  
		       brettY=0;
		       //move=0;
		   }
		   
		   // Brett ist ganz unten
		   else if (brettY>spielfeld_hoehe-20) {
		       brettY=spielfeld_hoehe-20;
		       //move=0;
		   }

		   // Ball ist ganz links
		   //		 ball in andere Richtung
		   if (ballX<0) {
		       ballX=0;
		       ballSchrittweiteX *=-1; 
		   }
		   // Ball ist ganz rechts
		   //		 ball ist raus ENDE
		   else if (ballX > spielfeld_breite-ballBreite/2) {
		       //gameState=3;
		       JOptionPane.showMessageDialog(null, "Schade: Ein Leben weniger");
		       stopTimer();
		       repaint();
		   }

		   // Ball ist ganz oben
		   //		 ball in andere Richtung
		   if (ballY<0) {
		       ballY=0;
		       ballSchrittweiteY*=-1; 
		   }
		   // Ball ist ganz unten
		   //		 ball in andere Richtung
		   else if (ballY>spielfeld_hoehe-ballHoehe/2) {
		       ballY=spielfeld_hoehe-ballHoehe;
		       ballSchrittweiteY*=-1; 
		   }

		   // Ball hat brett erreicht
		   //			 ball in andere X-Richtung
		   
		   if (ballX>spielfeld_breite-brettBreite) {
		       if ((ballY>brettY)&&(ballY<brettY+brettHoehe)) {
		           ballSchrittweiteX *=-1;
		           int ang=(ballY-brettY)/3;
		           ballSchrittweiteY=ang-3;
		           }
		       }
		   }	
	
	
	
	public void stopTimer()
	{
		if (spiel_timer!=null)
			spiel_timer.stop();
		
		spiel_timer=null;
	}
	

	public void paint(Graphics g) {
		super.paint(g);		

		spielfeld.setColor(java.awt.Color.black);
		
		// Ball zeichnen
		spielfeld.fillRect(ballX, ballY, ballBreite, ballHoehe);
		
		// Brett zeichnen
		
		spielfeld.fillRect(brettX, brettY, brettBreite, brettHoehe);
		
		
	   }
		
	private void initGame(){
		// Ball positionieren
		ballBreite= 5;
		ballHoehe=5;
		ballX= spielfeld_breite/2;
		ballY= spielfeld_hoehe/2;
		   
		// Brett positionieren
		brettBreite= 5;
		brettHoehe=60;

		brettX= spielfeld_breite -brettBreite;
		brettY= spielfeld_hoehe / 2;
		
		// Ball richtung festlegen
		ballSchrittweiteX= -2; // 2 nach links
		ballSchrittweiteY= 0; //  waagrecht
		
		
		// delay f�r TImer
		delay=40;
		

	}
	
	/**
	 * --------------------------------------------------
	 */
	  
	/**
	 * This method initializes jButtonStart	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonStart() {
		if (jButtonStart == null) {
			jButtonStart = new JButton();
			jButtonStart.setBounds(new Rectangle(14, 16, 88, 32));
			jButtonStart.setText("start");
			jButtonStart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {

					initGame();
					
					// los gehts
					startTimer();
					   
					// Spielfeld zeichnen 
					// repaint() ruft update() ruft paint() auf
					repaint();

				}
			});
			jButtonStart.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyPressed(java.awt.event.KeyEvent e) {
					System.out.println("keyPressed()"); // TODO Auto-generated Event stub keyPressed()
					switch (e.getKeyCode()) {
						case java.awt.event.KeyEvent.VK_UP: 
							brettRichtung=-1;  // rauf
							break;
						case java.awt.event.KeyEvent.VK_DOWN: 
							brettRichtung=1;   //runter
				            break;

						case java.awt.event.KeyEvent.VK_RIGHT: 
							if (delay>=5)delay -=5;
							spiel_timer.setDelay(delay);
				      		break;
				                     
						case java.awt.event.KeyEvent.VK_LEFT: 
							delay +=5;
							spiel_timer.setDelay(delay);
							break;
				                     
				      }
				}
			});
		}
		return jButtonStart;
	}

	/**
	 * This method initializes jButtonStop	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonStop() {
		if (jButtonStop == null) {
			jButtonStop = new JButton();
			jButtonStop.setBounds(new Rectangle(107, 16, 88, 32));
			jButtonStop.setText("stop");
			jButtonStop.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.out.println("actionPerformed()"); // TODO Auto-generated Event stub actionPerformed()
					spiel_timer.stop();
				}
			});
		}
		return jButtonStop;
	}

	/**
	 * This method initializes jButtonEnd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonEnd() {
		if (jButtonEnd == null) {
			jButtonEnd = new JButton();
			jButtonEnd.setBounds(new Rectangle(200, 16, 88, 32));
			jButtonEnd.setText("ende");
			jButtonEnd.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0);
					
				}
			});
		}
		return jButtonEnd;
	}

	/**
	 * This method initializes jPanelSpiel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelSpiel() {
		if (jPanelSpiel == null) {
			jPanelSpiel = new JPanel();
			jPanelSpiel.setLayout(new GridBagLayout());
			jPanelSpiel.setBounds(new Rectangle(15, 111, 452, 318));
			jPanelSpiel.setBackground(Color.magenta);
		}
		return jPanelSpiel;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SpielFirstGame thisClass = new SpielFirstGame();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public SpielFirstGame() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(491, 480);
		this.setContentPane(getJContentPane());
		this.setTitle("FirstGame");
		this.addWindowListener(new java.awt.event.WindowAdapter() {   
			public void windowOpened(java.awt.event.WindowEvent e) {
				
				spielfeld= jPanelSpiel.getGraphics();
				spielfeld_breite= jPanelSpiel.getWidth();
				spielfeld_hoehe= jPanelSpiel.getHeight();
				
				initGame();
				
				
				// zeichne Spielbrett
				repaint();
				

			}
		
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel12 = new JLabel();
			jLabel12.setBounds(new Rectangle(219, 59, 68, 39));
			jLabel12.setIcon(new ImageIcon(getClass().getResource("/button_right.gif")));
			jLabel12.setText("schneller");
			jLabel11 = new JLabel();
			jLabel11.setBounds(new Rectangle(151, 59, 55, 39));
			jLabel11.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
			jLabel11.setIcon(new ImageIcon(getClass().getResource("/button_down.gif")));
			jLabel11.setText("runter");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(101, 59, 45, 39));
			jLabel1.setIcon(new ImageIcon(getClass().getResource("/button_up.gif")));
			jLabel1.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
			jLabel1.setText("rauf");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(15, 59, 68, 39));
			jLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
			jLabel.setIcon(new ImageIcon(getClass().getResource("/button_left.gif")));
			jLabel.setText("langsamer");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJButtonStart(), null);
			jContentPane.add(getJButtonStop(), null);
			jContentPane.add(getJButtonEnd(), null);
			jContentPane.add(getJPanelSpiel(), null);
			jContentPane.add(jLabel, null);
			jContentPane.add(jLabel1, null);
			jContentPane.add(jLabel11, null);
			jContentPane.add(jLabel12, null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"

/*
 * import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.util.*;

public class FirstGame extends MIDlet {

   private Display display;
   private Gamespielfeld spielfeld;
   private Timer tm;
   private PlayTimer pt;

public FirstGame() {

   display=Display.getDisplay(this);
   spielfeld=new Gamespielfeld(this);
   }

public void startApp() {

   display.setCurrent(spielfeld);
   }

public void pauseApp() {
   }

public void destroyApp(boolean unconditional) {
   }

public void exitMIDlet() {

       destroyApp(true);
       notifyDestroyed();
   }

public void startTimer() {

   tm=new Timer();
   pt=new PlayTimer(spielfeld);
   tm.schedule(pt,0,65);
   }

public void stopTimer() {

   if (tm!=null)
       tm.cancel();
   tm=null;
   }
}

class PlayTimer extends TimerTask {

  private Gamespielfeld spielfeld;

public PlayTimer (Gamespielfeld spielfeld) {

   this.spielfeld=spielfeld;
   }

public final void run() {

   spielfeld.actionGame();
   spielfeld.repaint();
   }
}

class Gamespielfeld extends spielfeld implements CommandListener {

  private Command cmExit;
  private Command cmStart;
  private Command cmStop;
  private String text;
  private FirstGame midlet;
  private int gameState;

  private int playerPos;
  private int ballX,ballY;
  private int deltaX,deltaY;
  private int move;

public Gamespielfeld(FirstGame midlet) {

   this.midlet=midlet;
   gameState=0;
   cmExit=new Command("Exit",Command.EXIT, 1);
   cmStart=new Command("Start",Command.SCREEN, 1);
   cmStop=new Command("Stop",Command.SCREEN, 2);
   addCommand(cmExit);
   addCommand(cmStart);
   addCommand(cmStop);
   setCommandListener(this);
   }

protected void paint(Graphics g) {

   g.setColor(255,255,255);
   g.fillRect(0,0,getWidth(),getHeight());
   g.setColor(0,0,0);

   switch (gameState) {
      case 0: g.drawString("press start!",getWidth()/2,getHeight()/2,Graphics.BASELINE|Graphics.HCENTER);
              break;
      case 1: g.fillRect(getWidth()-5,playerPos,3,20);
              g.fillRect(ballX,ballY,2,2);
              break;
      case 3: g.drawString("game over",getWidth()/2,getHeight()/2,Graphics.BASELINE|Graphics.HCENTER);
              break;
      }
   }

public void actionGame() {

   ballX+=deltaX;
   ballY+=deltaY;

   playerPos+=move;

   if (playerPos<0) {
       playerPos=0;
       move=0;
       }
   if (playerPos>getHeight()-20) {
       playerPos=getHeight()-20;
       move=0;
       }
   if (ballX<0) {
       ballX=0;
       deltaX*=-1;
       }
   else if (ballX>getWidth()-1) {
       gameState=3;
       midlet.stopTimer();
       repaint();
       }
   if (ballY<0) {
       ballY=0;
       deltaY*=-1;
       }
   else if (ballY>getHeight()-1) {
       ballY=getHeight()-1;
       deltaY*=-1;
       }

   if ((ballX>getWidth()-7)&&(ballX<=getWidth()-4)) {
       if ((ballY>playerPos)&&(ballY<playerPos+20)) {
           deltaX*=-1;
           int ang=(ballY-playerPos)/3;
           deltaY=ang-3;
           }
       }
   }

private void startGame() {

   ballX=getWidth()-5;
   ballY=getHeight()/2;
   playerPos=(getHeight()-20)/2;
   deltaX=-2;
   deltaY=0;
   move=0;
   gameState=1;
   midlet.startTimer();
   }

private void stopGame() {

   midlet.stopTimer();
   gameState=0;
   repaint();
   }

protected void keyPressed(int keyCode) {

   switch (keyCode) {
      case KEY_NUM2: move=-2;
                     break;
      case KEY_NUM8: move=2;
                     break;
      }
  }

protected void keyReleased(int keyCode) {

   switch (keyCode) {
      case KEY_NUM2: move=0;
                     break;
      case KEY_NUM8: move=0;
                     break;
      }
  }

public void commandAction(Command c, Displayable d) {

   if (c==cmExit)
       midlet.exitMIDlet();
   else if (c==cmStart)
       startGame();
  else if (c==cmStop)
       stopGame();
   }
} 
 */
