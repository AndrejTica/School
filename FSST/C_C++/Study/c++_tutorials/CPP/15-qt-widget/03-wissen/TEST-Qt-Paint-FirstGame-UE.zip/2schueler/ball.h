#ifndef BALL_H
#define BALL_H

#include <QPainter>
#include <QBrush>

#include "widget.h"

class Widget;


class Ball
{
public:
    Ball(int x, int y, int breite, int dx, int dy, Widget* w);

    void move();

   // void andereRichtung(){ dx-=dx;}

    int getX(){return x;}
    int getY(){return y;}
    void setX(int x){ this->x=x;}
    void setY(int y){this->y=y;}

    int getBreite(){return breite;}

    void setDX(int dx){ this->dx=dx;}

    void repaint(QPainter* p);

private:
    int x,y;
    int breite;
    int dx,dy;  // wird bei bewegung zu x und y dazugezählt

    Widget* w;
};

#endif // BALL_H
