#ifndef BRETT_H
#define BRETT_H

#include <QPainter>
#include "widget.h"

class Widget;

class Brett
{
public:
    Brett(int x, int y , int breite, int hoehe, int dy,  Widget* w);

    void move();
    int getBreite(){return breite; }
    int getHoehe(){return hoehe; }
    void andereRichtung(){ dy= -dy; }

    int getY(){return y;}

    void repaint(QPainter* p);

private:
    int x,y;
    int breite,hoehe;
    int dy; // runter, rauf

    Widget* w;

};

#endif // BRETT_H
