﻿TODO: Paint-FirstGame
	+ Neues GUI-Projekt erstellen
	
	Gegeben:			Gesucht:
		+ brett.h		+ brett.cpp
		+ ball.h		+ ball.cpp		s. Hinweis
		+ widget.h
		+ widget.cpp	+ ????? ersetzen


Hinweis: void Ball::move(){
    x+=dx;
    y+=dy;

    // ganz links, dann umdrehen
    if (x < 0){
		x=0;
		dx= -dx; // andere richtung;
    }
    // ganz oben
    else if (y < 0){
		?????????
	}
    // ganz unten
    else if (y > w->height()-breite){
		???????????
	}
}

