#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::Widget)
{
    ui->setupUi(this);

    //blauer Hintergrund
    setPalette(QPalette(Qt::blue));

    //brett und ball erzeugen und psoitionieren
    brett= new Brett(width() - BRETTBREITE, height()/2 -BRETTHOEHE/2,  BRETTBREITE, BRETTHOEHE, 1, ?????????);
    ball= new Ball(50,50,BALLBREITE,1,1, ???????);

    // timer
    timer= new QTimer();
    timer->setInterval(DELAY);
    QObject::?????????????(timer, SIGNAL(timeout()),
		     this, ????????????(on_timer_timeout()));
    ticks=0;
    timer->start();
}

// Slot für timeout
void Widget::on_timer_timeout(){
    ticks++;
    actionGame(); // Spiel das Spiel
    repaint(); // neu zeichnen
}

void Widget::actionGame(){
    // Ball bewegen
    ball->move();

    // Brett bewegen
    brett->move();

    // Ball ist ganz rechts
    // d.h. ball ist raus ENDE
    if (?????????????? > width()) {
	timer->stop();
	QMessageBox m;
	m.setText(QString("Schade: Ein Leben weniger. Dauer: %1 ms").arg(ticks*DELAY));
	m.exec();

	// neues Spiel
	ticks=0;
	ball->setX(50);
	ball->setY(50);
	timer->start();
    }

    // Ball hat brett erreicht
    // ball in andere X-Richtung
    if (ball->getX()+ball->getBreite() >= width() - brett->getBreite()) {   // X-koordinate
	if ((ball->getY()  > brett->getY()) &&
	    (ball->getY() < brett->getY() + brett->getHoehe())) {  // y-koordinate

	    ball->setDX(-2);
	}
    }
}

??????????????????????????????????{
    QPainter painter(this);

    QPen p(Qt::white);
    painter.setPen(p);
    painter.drawText(10,10, QString("zeit: %1 ms").arg(ticks*DELAY) );

    ball->repaint(??????????);
    brett->repaint(??????????);
}


void Widget::keyPressEvent(QKeyEvent *e){
    if (e->key() == Qt::Key_Up )
	brett->andereRichtung();
    else if (e->key() == Qt::Key_Down)
	brett->andereRichtung();
}


Widget::~Widget(){
    delete ui;
	????????????
}
