#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QMessageBox>
#include <QKeyEvent>
#include <iostream>
using namespace std;



#include "ball.h"
#include "brett.h"

class Ball;
class Brett;

#define BRETTBREITE 10
#define BRETTHOEHE 80
#define BALLBREITE 30
#define DELAY 10


namespace Ui {
    class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    ???????????????????????????????
    
    void keyPressEvent(QKeyEvent *);

    void actionGame();

private slots:
    void on_timer_timeout();

private:
    Ui::Widget *ui;

    //USER
    Ball* ball;
    Brett* brett;

    QTimer* timer;
    int ticks;
};

#endif // WIDGET_H
