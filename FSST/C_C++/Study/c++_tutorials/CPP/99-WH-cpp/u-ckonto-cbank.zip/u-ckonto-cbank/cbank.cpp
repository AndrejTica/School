// a.hofmann 10.06
// cbank.cpp
// demo: klasse und objekt

#include "ckonto.h"
#include "cbank.h"

#include <iostream>
#include <string>
using namespace std;

// Konstruktoren
CBank::CBank(string pname){
	m_name= pname;
	m_konten_idx= -1;
}

// Methoden
void CBank::add(const CKonto& pkonto){
	if (m_konten_idx < 1024 - 1) {
		m_konten_idx++;
		m_konten[m_konten_idx]= pkonto;
	}
}


void CBank::display()const{
	double gesamt=0.0;

	for (int i=0; i <= m_konten_idx; i++)
		gesamt += m_konten[i].getBetrag();

	cout << "\nBank: \"" << m_name << "\" hat " << m_konten_idx +1 << " Konten mit ";
	cout << " einem Betrag von insgesamt " << gesamt << " Euro."<< endl;
}

// Destruktor
CBank::~CBank(){
	//nothing todo
}

// friends
ostream& operator<<(ostream& o, const CBank& e) {
	double gesamt=0.0;

    for (int i=0; i <= e.m_konten_idx; i++)
	    gesamt += e.m_konten[i].getBetrag();
	
	o<< "*** BANK " << e.m_name << " ***" << endl;
	o<< "*** hat " << e.m_konten_idx +1 << " Konten ";
	o<< "mit einem Gesamtbetrag von " << gesamt << " Euro." << endl;

	o<< "Hier nun eine Liste der einzelnen Konten:" <<endl;
	for (int i=0; i <= e.m_konten_idx; i++)
		o<< e.m_konten[i];	//Hier wird genutzt, dass CKonto den operator << überschrieben hat

	return o;
}
