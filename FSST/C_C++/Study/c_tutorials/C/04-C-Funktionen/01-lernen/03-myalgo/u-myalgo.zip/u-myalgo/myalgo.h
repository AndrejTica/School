/** Die Funktionsdeklarationen von Myalgo
 *   
 *  @author Anton Hofmann
 *  @date 2.7.2004 
 *  @file myalgo.h
 * 
 *  @version 0.2 
 *  Alten Code entfernt. 
 * 
 *  @version 0.1 
 *  Kommentare hinzugef�gt (Doxygen). 
 * 
 *  @see Das kann man auch sehen
 * 
 *  @todo Fertig auf doxygen umstellen
 * 
 *  @bug Das ist ein bug
 * 
 *  @warning warnung!!!!
 * 
 *  @test Das ist ein test
 */

#ifndef MYALGO_H_
#define MYALGO_H_


  /** Gibt ein Logo aus
   *  @param [in] void, keine
   *  @return void, nichts 
   *  @see void logo(void);
   */
void logo(void);


  /** Array ausgeben
   *  @param [in] a das Array
   *  @param [in] len die Anzahl der Arrayelemente
   *  @return void, nichts 
   *  @see void display(int a[], int len);
   */
void display(int a[], int len);


/** schreibt Zufallszahlen zw. 1...45 ins array
   *  @param [out] a das Array
   *  @param [in]  len die Anzahl der Arrayelemente
   *  @return void, nichts 
   *  @see void mischen(int a[], int len);
   */
void mischen(int a[], int len);



/** liefert das Maximum im Array
   *  @param [in] a das Array
   *  @param [in] len die Anzahl der Arrayelemente
   *  @return Das Maximum
   *  @see int find_max(int a[], int len);
   */
int find_max(int a[], int len);


/** liefert das Minimum im Array
   *  @param[in] a das Array
   *  @param[in] len die Anzahl der Arrayelemente
   *  @return Das Minimum 
   *  @see int find_min(int a[], int len);
   */
int find_min(int a[], int len);


/** sortiert ein Integer-Array
   *  @param[out] a das Array
   *  @param[in]  len die Anzahl der Arrayelemente
   *  @return nichts
   *  @see void mysort(int a[], int len);
   */
void mysort(int a[], int len);



/** sucht das Vorhandensein von key im Array a
   *  @param[in] key, der Wert nach dem im Array gesucht werden soll
   *  @param[in] a das Array
   *  @param[in] len die Anzahl der Arrayelemente
   *  @return index (0 ... len-1) wenn key im array vorkommt.
   *  @return -1 wenn key im array nicht vorkommt
   *  @see int mysearch (int key, int a[], int len);
   */
int mysearch (int key, int a[], int len);



/** sucht das Vorhandensein von key im sortierten Array a
   *  @warning Das Array MUSS sortiert sein
   *  @param [in] key, der Wert nach dem im Array gesucht werden soll
   *  @param [in] a das Array
   *  @param [in] len die Anzahl der Arrayelemente
   *  @return index (0 ... len-1) wenn key im array vorkommt.
   *  @return -1 wenn key im array nicht vorkommt
   *  @see int mybsearch (int key, int a[], int len);
   */
int mybsearch (int key, int a[], int len);



  /** Array ausgeben: wie display gibt aber nur die Primzahlen aus
   *  @warning: Gibt NUR Primzahlen aus
   *  @param[in] a das Array
   *  @param[in] len die Anzahl der Arrayelemente
   *  @return void, nichts 
   *  @see void display_prim(int a[], int len);
   */
void display_prim(int a[], int len);


  /** ueberprueft, ob zahl eine Primzahl ist
   *  @param[in] zahl die zu testende Zahl
   *  @return 0 .... zahl ist keine Primzahl
   *  @return 1 .... zahl ist eine Primzahl
   *  @see int istPrim(int zahl);
   */
int istPrim(int zahl); 


// gibt den Mittelwert zurueck
double mittelwert(int a[], int len);


#endif