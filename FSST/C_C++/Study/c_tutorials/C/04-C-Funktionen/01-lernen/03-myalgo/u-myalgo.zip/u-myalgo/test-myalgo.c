/** Ein Testprogramm für Myalgo
 *   
 *  @author Anton Hofmann
 *  @date 2010
 *  @file
 * 
 *  @version 0.2 
 *  Alten Code entfernt. 
 * 
 *  @version 0.1 
 *  Kommentare hinzugefügt (Doxygen). 
 * 
 *  @see gcc test-myalgo.c myalgo.o -o test-myalgo.exe
 * 
 *  @todo Für Linux und Windows lauffähig machen
 * 
 *  @bug Keine bekannt
 * 
 *  @warning Lernstoff
 * 
 *  @test Kann zum Test kommen
 */


#include <stdio.h>
#include <stdlib.h>

#include "myalgo.h"

#define MAXVALUES 10

// Linux
//#define PAUSE printf("\nEnter ... ");fgetc(stdin);
//#define CLS system("clear")

// windows
#define PAUSE system("pause")
#define CLS system("cls")


int main(){
    int values[MAXVALUES];
    int i;
    int gefunden;
    int suche;
    int ende;
    char ch;
    int maxi, mini;

    ende=0;
    while (ende==0){
          CLS;
          logo();

          //Menu
          printf("   1) Mischen\n");
          printf("   2) Anzeigen\n");
          printf("   3) Maximum\n");
          printf("   4) Minimum\n");
          printf("   5) Sortieren\n");
          printf("   6) Sequentielles Suchen\n");
          printf("   +7) Binaeres Suchen\n");
          printf("   +8) Mittelwert\n");
          printf("   +9) Primzahlen\n");
          printf("   0) Ende\n");

          ch= fgetc(stdin);
          fgetc(stdin); //ENTER aus dem tastaturbuffer löschen

          switch(ch){
            case '0':   ende=1;
                        break;

            case '1':   printf("\n------> mischen\n");
                        mischen(values, MAXVALUES);
                        PAUSE;
                        break;
                        
            case '2':   printf("\n------> anzeigen\n");
                        display(values, MAXVALUES);
                        PAUSE;
                        break;
                        
            case '3':   printf("\n------> maximum\n");
                        maxi= find_max(values, MAXVALUES);
                        printf("\nMaximum= %d\n", maxi);
                        PAUSE;
                        break;

            case '4':   printf("\n------> minimum\n");
                        mini= find_min(values, MAXVALUES);
                        printf("\nMinimum= %d\n", mini);
                        PAUSE;
                        break;

            case '5':   printf("\n------> sortieren\n");
						mysort(values, MAXVALUES);
                        PAUSE;
                        break;

            case '6':   printf("\n------> Sequentielles Suchen\n");
                        printf("\nGeben Sie den zu suchenden Wert ein: ");
                        scanf("%d", &suche);
                        fgetc(stdin); //ENTER
                        
                        gefunden= mysearch(suche, values, MAXVALUES);

                        if (gefunden == -1){
                            printf("\n%d im Array nicht gefunden\n", suche);
                        }
                        else {
                            printf("\n%d im Array an der Stelle %d gefunden (%d)\n", suche, gefunden, values[gefunden]);
                        }
                        PAUSE;
                        break;


            case '7':   printf("\n------> Binaeres Suchen\n");
                        printf("\nGeben Sie den zu suchenden Wert ein: ");
                        scanf("%d", &suche);
                        fgetc(stdin); //ENTER
                        gefunden= mybsearch(suche, values, MAXVALUES);

                        if (gefunden == -1){
                            printf("\n%d im Array nicht gefunden\n", suche);
                        }
                        else {
                            printf("\n%d im Array an der Stelle %d gefunden (%d)\n", suche, gefunden, values[gefunden]);
                        }
                        PAUSE;
                        break;


            case '9':   printf("\n------> NUR Array-Werte anzeigen, die Primzahlen sind\n");
                        display_prim(values, MAXVALUES);
                        PAUSE;
                        break;


            default:    printf("\n**** Falsche Eingabe .... ");
                        PAUSE;

            } //end switch

    } // while

    return 0;
}//end main
