/** 
 * @brief Function prototypes for module doubleStack.
 *
 * This contains the prototypes for the implementation
 * of a simple Stack for double values.
 *
 * @file doubleStack.h
 * @author Anton Hofmann 
 * @date 12 Feb 2017
 */


/**
 * @brief to init the internal values of Module Stack
 *
 * deletes all stack elements and sets stackpointer to 0.
 *
 * @param void
 * @return void
 */
void init(void);

/**
 * @brief puts a value on top of stack
 *
 * if stack is already full an error message is written to stderr
 *
 * @param value The value to be pushed on top of stack
 * @return void
 */
void push(double value);

/**
 * @brief return the element on top of stack
 *
 * if stack is empty an error message is written to stderr
 *
 * @param void 
 * @return the element on top of stack
 */
double  top(void);


/**
 * @brief delete the element on top of stack
 *
 * if stack is already empty an error message is written to stderr
 *
 * @param void 
 * @return void
 */
void  pop(void);

