/** 
 * @brief A calculator using postfix notation and a stack
 * 
 * A stack module (doubleStack.h, doubleStack.c) is 
 * implemented to help to caculate the result.
 *
 * @file test_taschenrechner.c
 * @author Anton Hofmann 
 * @date 12 Feb 2017
 */


#include <stdio.h>
#include <ctype.h>		// wegen isdigit()
#include <stdlib.h>		// wegen atof()

#include "????????????????.h"   // den Modul doubleStack inkludieren

#define IL_MAX   20
#define END_CHAR '='


/*
 * @brief read a value (number or operator) from stdin
 *
 * @param str a char array holding the input
 * @param len holds the max. length of the input array
 * @return '0' if the input was a number
 * @return str[0] if the input was no number but an operator +,-,...
 */
char mygetline(char str[], int len){
	scanf ("%s", str);
	if (isdigit(str[0]))
		return('0');
	else
		return(str[0]);
}

// ------------------------------------------------------------------------
int  main(){
	double  op1,op2;			// hold an operand of an expression
	char input_line[IL_MAX+1]; // input line
	char ch; 				// hold return value of mygetline()

	init(); ///< init the stack

	printf("\nTaschenrechner:");
	printf("\nGeben Sie Zahlen in umgekehrter polnischer Notation ein.");
	printf("\nBeispiel: 12 2 * 4 + 2 / = ");
	printf("\n... dies entspricht: (12 * 2 + 4) / 2");
	printf("\nErgebnis=14.00\n\n");

	do {
		ch=mygetline(input_line,IL_MAX);

		switch(ch){
			case '+':
				op1= top(); pop();
				op2= top(); pop();	
				push(op1+op2);
				break;
			case '-':
				???????????????
				break;
			case '*':
				???????????????
				break;
			case '/':
				op2 = top(); pop();
				if (op2 == 0.0){
					fprintf(stderr,"\nDivision durch 0 nicht definiert!\n");
					pop(); 	///< zweiten operanden v. stack, 
							///< d.h. / wurde nicht ausgefuehrt
				}
				else
					???????????????
				break;
			case '0': // a number was entered
				push(atof(input_line));
				break;
			case '=':
				printf("\nErgebnis = %.2lf \n\n",top());
			break;
		}
	} while (input_line[0]!='=');

	return 0;
} /* main() */

