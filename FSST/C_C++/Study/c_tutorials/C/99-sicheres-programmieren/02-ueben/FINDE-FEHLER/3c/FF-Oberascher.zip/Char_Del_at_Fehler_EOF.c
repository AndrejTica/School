/**
  Raphael Oberascher
  3cHELi	04.06.2012
  Loeschen eines Zeichen an eingegebener Stelle
  */


#include <stdio.h>

int main()
{
    char zeichenkette[1024];
    int stelle = 0;


    printf("Text\n");
    gets(zeichenkette);

    printf("Stelle eingeben!:\n");
    scanf("%d",&stelle);

    while (zeichenkette[stelle] != EOF)
    {
        zeichenkette[stelle] = zeichenkette[stelle+1];
        stelle++;
    }
    printf("Der Text lautet <%c>\n", zeichenkette);


    return 0;
}
