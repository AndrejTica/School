/** 
	Raphael Oberascher
	3cHELi	04.06.2012
	Ausgeben von 42 Zufallszahlen zwischen 6 und 45
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ANZ 42

int main(){
    int ausgabe[ANZ];
    int zaehler_1 = 0, zaehler_2 = 0;

    // mischen
    srand( time( NULL ) );
    for( zaehler_1 = 0; zaehler_1 < ANZ; zaehler_1++ );
    {
        ausgabe[zaehler_1] = rand() % 45 + 1; // 1...45
        for( zaehler_2 = 0; zaehler_2 < zaehler_1; zaehler_2++ )
        {
            if( ausgabe[zaehler_1] == ausgabe[zaehler_2] )
            {
                zaehler_1--;
                zaehler_2 = zaehler_1 -1;
            }
        }
    }

    // ausgeben
    for( zaehler_1 = 1; zaehler_1 <= ANZ; zaehler_1++ )
    {
        printf( "%i, ", ausgabe[zaehler_1-1] );
        if(ausgabe[zaehler_1-1] < 10)
            printf( " " );
        if(zaehler_1%6 == 0)
            printf( "\n" );
    }
    printf("\n");

    return 0;
}
