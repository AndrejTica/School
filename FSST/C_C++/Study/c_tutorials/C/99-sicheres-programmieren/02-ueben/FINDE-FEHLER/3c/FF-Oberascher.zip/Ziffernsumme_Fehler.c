/**
  Raphael Oberascher
  3cHELi    04.06.2012
  Ziffernsumme berechnen
  */

#include <stdio.h>
#include <string.h>

int main()
{

    char ziffer[100];
    int anzahl = 0;
    int ziffernsumme = 0;



    printf("Zahl eingeben!:\n");
    gets(ziffer);

    while ( anzahl <= strlen(z))
    {
        anzahl--;
        ziffernsumme = ziffernsumme + (ziffer[++anzahl] - '0');
        anzahl++;
    }
    printf("Die Summe der Ziffern %d\n", ziffernsumme);


    return 0;
}
