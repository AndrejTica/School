/*
 Georg Diechler / 3DHELI
 30.05.2012
 Finde den Fehler
 Bsp1
 */

#include <stdio.h>

int main(){
    int anz;

    printf("Anzahl = ");
    scanf("%i", anz);

    anz=anz*anz;

    printf("\nAnzahl^2 = %i\n", anz);

    return 0;
}
