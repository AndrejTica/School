/*
 Georg Diechler / 3DHELI
 30.05.2012
 Finde den Fehler
 Bsp2
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(int argv, char* argc[]){
    FILE* f_new;

    if((f_new = fopen(argv[1], "wt")) == NULL){
        fprintf(stderr, "Fehler beim erzeugen der Datei %s", argv[1]);
    }

    fclose(f_new);

    return 0;
}
