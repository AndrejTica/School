/*
 Georg Diechler / 3DHELI
 30.05.2012
 Finde den Fehler
 Bsp3
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* mystrdup(const char* );

int main(){
      char str[128];
      char* p;

      printf("\nstrdup-test: Bitte einen Text: ");
      gets(str);

      p= mystrdup(str);
      if (NULL==p){
              printf("Error");
              exit(1);
      }
      printf("\nmystrdup() lieferte: <%s>\n", p);
      free(p);
      return 0;
}

char* mystrdup(const char* s){
  int len;
  char* p;

  len=strlen(s);

  p=(char*) malloc(len*sizeof(char));
  if(NULL==p){
      return NULL;
  }

  strcpy(p, s);

  return p;
}



