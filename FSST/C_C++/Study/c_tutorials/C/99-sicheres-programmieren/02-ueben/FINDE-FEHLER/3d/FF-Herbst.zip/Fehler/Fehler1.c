/**
  Finde die Fehler!
  Herbst Michael
  **/


#include <stdio.h>;

int main(){
    int ch,gross=0,klein=0,alle=0,sonst=0;
    ch = fgetc(stdin);
    while(ch!=EOF){
        alle++;
        if(ch >="a"&ch<="z"){
            klein++;
        }
        else if (ch >="A"&ch<="Z"){
            gross++;
        }
        else{
            sonst++;
        }
        ch=fgetc(stdin);
    }
    printf("Grossbuchstaben: %i Kleinbuchstaben: %i Sonstige: %i Alle: %i \n",gross,klein,sonst,alle);
    return 0;
}
