/**
  Finde die Fehler!
  Herbst Michael
  **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char str1[10];
    char str2[10];
    int len;
    int b;

    printf("Eingabetext: \n");
    gets(str1);


    len = 0;
    while(str1[len] == '\0') {
        len++;
    }

   
    b = 1;
    for (int i = 0; i <= len & b = 1; ++i) {
        if(str1[i] == str2[i]){
            b = 1;
        }
        else{
            b = 0;
        }

    }

    return 1;
}
