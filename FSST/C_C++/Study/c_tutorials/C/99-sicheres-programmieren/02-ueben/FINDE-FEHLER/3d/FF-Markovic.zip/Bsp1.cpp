/*Andreas Markovic
  30.50.2012
  C-Fehler
  */


//Finde den Fehler Bsp 1
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
    char ch;

    ch = fgetc(stdin);

    printf("%s", ch);
}

