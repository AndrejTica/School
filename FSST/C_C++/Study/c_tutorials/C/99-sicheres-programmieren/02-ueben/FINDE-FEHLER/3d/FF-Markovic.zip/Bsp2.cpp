//Finde den Fehler Bsp 2
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
    FILE* fin;

    if(fin = fopen(argv[0], "rt") == NULL){
        fprintf(stderr, "Fehler beim �ffnen der Datei %s\n", argv[1]);
    }


    return 0;
}
