//Finde den Fehler Bsp 3
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
    int* ptr;
    int a[8] = {0,1,2,4,6,8,10,12};

    ptr = a;

    printf("Der Wert auf den ptr zeigt ist %p", *ptr);

    return 0;
}
