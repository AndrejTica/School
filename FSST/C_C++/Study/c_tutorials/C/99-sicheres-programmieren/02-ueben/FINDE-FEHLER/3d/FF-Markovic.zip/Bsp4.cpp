/*Andreas Markovic
  30.50.2012
  C-Fehler
  */

//Finde den Fehler Bsp 4
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(){
    char filename[128];
    char cmd[1024];
    char hilfe[32];
    char input[1024];
    FILE* fin;

    char* qs = getenv("QUERY_STRING");

    if(qs == NULL || strlen(qs)==0){
        printf("falsch");
    }else{
        char* p = strstr(qs, "=");

        if(p == NULL){
            printf("LEER");
        }else{
            sscanf(p+1, "%s", filename);

            sprintf(cmd, "c2html/c2html %s", filename);

            system(cmd);

            //hilfe = strcat(filename, ".html");

            sprintf(hilfe, "%s.html", filename);

            if((fin = fopen(hilfe, "rt")) == NULL){
                printf("Fehler %s\n", hilfe);
                return 1;
            }

            while(fgets(input, 1024, fin)){
                fputs(input, stdout);
            }

            fclose(fin);

        }
    }

    return 0;
}
