/*Andreas Markovic
  30.05.2012
  */

//Finde den Fehler
int main(){
    char string[10];

    printf("Eingabe...\n");

    gets(string);
    puts(string);

    return 0;
}

