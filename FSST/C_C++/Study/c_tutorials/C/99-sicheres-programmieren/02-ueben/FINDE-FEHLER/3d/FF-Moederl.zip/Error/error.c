/*
 * error.c
 *
 *  Created on: 30.05.2012
 *      Author: Jakob
 */


#include <stdio.h>

int mian(){
	int i;
	for(i=0; i<3;i++) {
		printf("Hello World#%d\n", i);
	}
	return 0;
}
