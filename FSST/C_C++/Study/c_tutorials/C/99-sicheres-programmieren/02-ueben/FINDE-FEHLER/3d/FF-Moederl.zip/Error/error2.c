#include <stdio.h>

int main(){
	char name[80];
	int alter;

	printf("bitte geben sie name und alter ein (<name> <alter>)\n");
	scanf("%s %i", name, alter);

	printf("wilkommen in der c welt, %s, sie sind %i jahre alt", name, alter);

	return 0;
}
