/*
 * error3.c
 *
 *  Created on: 30.05.2012
 *      Author: Jakob
 */


/*
 * error3.c
 *
 *  Created on: 30.05.2012
 *      Author: Jakob
 */

#include <stdio.h>
#include <string.h>


void mystrcat(char* str1, char* str2);

int main(){
	char a[128] = "hallo";
	mystrcat(a, " du");

	printf("%s", a);

	return 0;
}

void mystrcat(char* str1, char* str2){
	int i;
	int len;
	i=strlen(str1);
	len = strlen(str1);
	while(str2[i-len] != '\0'){
		str1[i] = str2[i-len];
		i++;
	}

}
