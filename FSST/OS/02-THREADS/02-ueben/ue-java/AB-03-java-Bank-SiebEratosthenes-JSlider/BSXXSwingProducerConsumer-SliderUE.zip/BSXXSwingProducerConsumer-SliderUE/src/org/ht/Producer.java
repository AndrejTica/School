package org.ht;

public class Producer extends ????????????????{
	SharedSlider sharedSlider;
	int iSleep=100;

	public Producer(SharedSlider s){
		sharedSlider= s;
		iSleep=100;
	}

	public void run(){
		int val=0;
		while(isInterrupted()== false){
			try {
				Thread.sleep(getSleep());
				sharedSlider.incr(); 
			} catch (InterruptedException e) {
				//??????????????????????
			}
		}
	}

	syn public void setSleep(int val){
		iSleep=val;
	}

	syn public int getSleep(){
		return iSleep;
	}


}
