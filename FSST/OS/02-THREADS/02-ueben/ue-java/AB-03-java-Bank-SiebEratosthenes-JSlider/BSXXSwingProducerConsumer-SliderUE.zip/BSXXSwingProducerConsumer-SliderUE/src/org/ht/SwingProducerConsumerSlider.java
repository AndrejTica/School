package org.ht;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JSlider;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class SwingProducerConsumerSlider extends JFrame {

	private JPanel contentPane;
	private JTextField txtPsleep;
	private JPanel panelProducer;
	private JPanel panel;
	private JSlider slider;
	private JLabel lblSlider;
	private JPanel panelConsumer;
	private JTextField txtCsleep;
	private JButton btnStart;
	private JButton btnInterrupt;

	
	// 
	Producer producer=null;
	Consumer consumer=null;
	SharedSlider sharedSlider=null;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingProducerConsumerSlider frame = new SwingProducerConsumerSlider();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SwingProducerConsumerSlider() {
		setTitle("Producer/Consumer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 735, 184);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getPanelConsumer());
		contentPane.add(getPanelProducer());
		contentPane.add(getPanel());
	}
	private JTextField getTxtPsleep() {
		if (txtPsleep == null) {
			txtPsleep = new JTextField();
			txtPsleep.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if (e.getKeyCode()== e.VK_ENTER){
						int val= Integer.parseInt(txtPsleep.getText());
						producer.setSleep(val);
					}

				}
			});
			txtPsleep.setBorder(new TitledBorder(null, "Sleep", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			txtPsleep.setText("100");
			txtPsleep.setColumns(10);
		}
		return txtPsleep;
	}
	private JPanel getPanelProducer() {
		if (panelProducer == null) {
			panelProducer = new JPanel();
			panelProducer.setBorder(new TitledBorder(null, "Producer", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelProducer.setBounds(12, 12, 180, 121);
			panelProducer.setLayout(new GridLayout(0, 1, 0, 0));
			panelProducer.add(getTxtPsleep());
		}
		return panelProducer;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBounds(204, 24, 324, 109);
			panel.setLayout(new GridLayout(0, 1, 0, 0));
			panel.add(getSlider());
			panel.add(getLblSlider());
			panel.add(getBtnStart());
			panel.add(getBtnInterrupt());
		}
		return panel;
	}
	private JSlider getSlider() {
		if (slider == null) {
			slider = new JSlider();
			slider.addChangeListener(new ChangeListener() {
				public void stateChanged(ChangeEvent arg0) {
					if (lblSlider != null)
						lblSlider.setText(String.valueOf(slider.getValue()));
				}
			});
			slider.setValue(0);
		}
		return slider;
	}
	private JLabel getLblSlider() {
		if (lblSlider == null) {
			lblSlider = new JLabel("0");
			lblSlider.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblSlider;
	}
	private JPanel getPanelConsumer() {
		if (panelConsumer == null) {
			panelConsumer = new JPanel();
			panelConsumer.setBorder(new TitledBorder(null, "Consumer", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelConsumer.setBounds(540, 12, 180, 121);
			panelConsumer.setLayout(new GridLayout(0, 1, 0, 0));
			panelConsumer.add(getTxtCsleep());
		}
		return panelConsumer;
	}
	private JTextField getTxtCsleep() {
		if (txtCsleep == null) {
			txtCsleep = new JTextField();
			txtCsleep.setBorder(new TitledBorder(null, "sleep", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			txtCsleep.addKeyListener(new KeyAdapter() {
				@Override
				public void keyPressed(KeyEvent e) {
					if (e.getKeyCode()== e.VK_ENTER){
						int val= Integer.parseInt(txtCsleep.getText());
						consumer.setSleep(val);
					}
				}
			});
			txtCsleep.setText("100");
			txtCsleep.setColumns(10);
		}
		return txtCsleep;
	}
	private JButton getBtnStart() {
		if (btnStart == null) {
			btnStart = new JButton("start");
			btnStart.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (sharedSlider==null){
						sharedSlider= new SharedSlider(slider);
					}
					
					if (producer==null){
						producer= new Producer(sharedSlider);
						producer.start();
					}
					
					if (consumer==null){
						consumer= new Consumer(sharedSlider);
						consumer.start();
					}
					
					btnStart.setEnabled(false);
					btnInterrupt.setEnabled(true);

					
					
					
					
				}
			});
		}
		return btnStart;
	}
	private JButton getBtnInterrupt() {
		if (btnInterrupt == null) {
			btnInterrupt = new JButton("interrupt");
			btnInterrupt.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					btnStart.setEnabled(true);
					btnInterrupt.setEnabled(false);
					
					producer.interrupt();
					producer=null;
					
					consumer.interrupt();
					consumer=null;
					
					sharedSlider=null;
				}
			});
		}
		return btnInterrupt;
	}
}
