﻿http://wiki.openstreetmap.org/wiki/Openlayers_POI_layer_example
