Projekt: ﻿WhereAreYou (way und mysql und php)
===============================================

Allgemeine Beschreibung:
-----------------------------------------------
Eine OpenStreetMap-Anwendung, um Personen - deren Geo-Positionen
in einer Datenbank gespeichert werden - auf einer Karte in einem
Web-Browser zu zeigen.



Aufgabe 1: Datenbank und User erstellen
-----------------------------------------------
1. (Als root) Erstellen Sie den User is_way@localhost/comein.
2. (Als root) Erstellen Sie die Datenbank is_way und
	geben Sie die user User is_way@localhost alle Rechte
	auf die Datenbank.
3. (Als user is_way) Erstellen Sie die unten angeführte Tabelle way
	und fügen Sie die Datensätze ein.

CREATE TABLE way (
	id INT NOT NULL AUTO_INCREMENT ,
	cr_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
	lat VARCHAR( 80 ) NOT NULL ,
	lng VARCHAR( 80 ) NOT NULL ,
	title VARCHAR( 80 ) NOT NULL ,
	description VARCHAR( 80 ) NOT NULL ,
	icon VARCHAR( 80 ) NOT NULL ,
	PRIMARY KEY ( id )
) ENGINE = innodb;

	
--
commit;
--

insert into way (lat,lng,title,description, icon)
values ('47.800038', '13.044499',
'Anton Hofmann', 
'<a href="http://www.htl-salzburg.ac.at">zur HTL</a>',
'hofa.jpg');

insert into way (lat,lng,title,description, icon)
values ('47.799583', '13.041857',
'Anton Hofmann', 
'<a href="http://www.htl-salzburg.ac.at">zur HTL</a>',
'hofa.jpg');

insert into way (lat,lng,title,description, icon)
values ('47.800661', '13.042792',
'Anton Hofmann', 
'<a href="http://www.htl-salzburg.ac.at">zur HTL</a>',
'hofa.jpg');


Aufgabe 2: way.html
-----------------------------------------------
1. Studieren Sie diese Datei, die die osm Karte anzeigt und
	zur Darstellung der Bilder textfile.php aufruft.


Aufgabe 3: textfile.php
-----------------------------------------------
1. holt die Daten aus der Datenbank 
	host=localhost, user=is_way, pwd=comein, db= is_way

2. Füllen Sie die Lücken in textfile.php


Aufgabe 4: insert-way.php
-----------------------------------------------
1. zeigt das Eingabe-Formular für 
	lat,lng,title,description,icon an und fügt die Daten in die DB ein.
	host=localhost, user=is_way, pwd=comein, db= is_way

2. Füllen Sie die Lücken bzw. vervollständigen Sie das Programm
3. Hinweis: siehe http://www.w3schools.com/html/

