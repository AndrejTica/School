<?php
/*
AUFGABE: 
* 	siehe AB-readme.txt
*/

if (!isset($_GET["lat"])){
	// Formular
?>
	<html>
	<body>
	<h1>OSM Daten insert</h1>
	
	<form action="insert-way.php" method="GET">
		lat: <input type="text" name="lat" value="47.809661" />
		lng: <input type="text" name="lng" value="13.049792" />
		title: <input type="text" name="title" value="Title..." />
		description: <input type="text" name="description" value="description..." />
		icon: <input type="text" name="icon" value="hofa.jpg" />

		<input type="submit" />
	</form>
	
	</body>
	</html> 
<?php

}else{
	// DB
	$host= "localhost";
	$user="is_way";
	$pwd="comein";
	$db="is_way";
	
	$conn= mysql_connect($host, $user,$pwd) or
		die("Verbindungsversuch fehlgeschlagen");
	
	mysql_select_db($db, $conn) or 
		die("Konnte die Datenbank nicht waehlen.");
	
	// escape variables for security
	$lat = _______________________($_GET['lat']);
	$lng = _______________________($_GET['lng']);
	$title = ___________________($_GET['title']);
	$description = _____________________($_GET['description']);
	$icon = ________________________($_GET['icon']);
	

	$sql="INSERT INTO way (lat,lng,title,description, icon)
		VALUES ('$lat', '$lng', '$title', '$description', '$icon')";

	$query  = mysql_query($sql) or die("Anfrage nicht erfolgreich");

echo "<p>sql= $sql</p>"	;
echo '<ul>';
echo '<li>weiter mit <a href="insert-way.php">Dateneingabe</a></li>';
echo '<li>weiter mit <a href="way.html">Kartenanzeige</a></li>';
echo '</ul>';
	
	mysql_close($conn);
}
?>
