<?php
/*
AUFGABE: 
* 	siehe AB-readme.txt
*/

$host= "localhost";
$user="is_way";
$pwd="comein";
$db="is_way";

$conn= _____________________________($host, $user,$pwd) or
        die("Verbindungsversuch fehlgeschlagen");

mysql_select_______________($db, $conn) or 
                die("Konnte die Datenbank nicht waehlen.");
                
$sql    = "SELECT lat,lng,title,description,icon FROM _______________";

$query  = mysql_____________(________________) or die("Anfrage nicht erfolgreich");

$anzahl = mysql_num_rows($query);
//echo "Anzahl der Datens�tze: $anzahl";

$pois="lat\tlon\ttitle\tdescription\ticon\ticonSize\ticonOffset\n";
echo $pois;
while ($row = mysql_fetch______________________(________________)){
	echo $row['lat'] . "\t";
	echo $row['lng'] . "\t";
	echo $row['title'] . "\t";
	echo $row['description'] . "\t";
	echo $row['icon'] . "\t";
	echo "44,44\t0,0\n";
}


_______________close($conn);

?>
