Beispiele u. Aufgaben zu OpenStreetMap/php/mysql
===================================================

Beispiel 1: Das Original Beispiel kennen lernen
---------------------------------------------------
1. Laden Sie in Ihrem Web-browser
   http://localhost/dbkurs/01-mysql-openstreetmap/00-original-beispiel/osm.html
2. Studieren Sie die Dateien
	a) osm.html
	b) testfile.txt


Beispiel 2: Die Stadt Salzburg (noch ohne mysql)
---------------------------------------------------
1. Laden Sie in Ihrem Web-browser
   http://localhost/dbkurs/01-mysql-openstreetmap/01-txt/osm.html
2. Studieren Sie die Dateien
	a) osm.html
	b) testfile.txt


Aufgabe 1: Die Stadt Salzburg und das Projekt way (WhereAreYou)
---------------------------------------------------
siehe 01-mysql-openstreetmap/02-way/AB-readme.txt
