package de.lmu.location2;

import android.app.Application;

public class Location2Application extends Application {
	int points = 0;
	PointOfInterest currentPoi = null;
}
