package de.lmu.location2;

import java.util.Vector;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity implements LocationListener {

	LocationManager locationManager = null;
	Vector<PointOfInterest> pois = new Vector<PointOfInterest>();
	TextView latitudeView;
	TextView longitudeView;
	TextView closestPoiView;
	TextView distanceToClosestPoiView;

	static int points = 0;
	TextView pointsView;
	
	static PointOfInterest currentPoi = null;

	public void onCreate(Bundle savedInstanceState) {
		Log.d("MainActivity", "onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		
		Location2Application app = (Location2Application)getApplication();
		Log.d("MainActivity", app.toString());
		app.currentPoi = currentPoi;
		app.points = points;

		PointOfInterest p = new PointOfInterest(48.143446, 11.647552, 5, "Target 1", R.drawable.location1);
		Quiz q = new Quiz("What is the most interesting fact about this street?");
		q.addAnswer("It is very new", 4);
		q.addAnswer("It is very old", -4);
		q.addAnswer("It is very wide", 40);
		p.quiz = q;
		pois.add(p);
		
		p = new PointOfInterest(48.14263, 11.647063, 5, "Target 2", R.drawable.location2);
		q = new Quiz("What is the most interesting fact about this building?");
		q.addAnswer("It was built before 1830", 4);
		q.addAnswer("It has a red roof", -4);
		q.addAnswer("200 people live in it", 40);
		p.quiz = q;
		pois.add(p);
		
		p = new PointOfInterest(48.143228, 11.64852, 5, "Target 3", R.drawable.location3);
		q = new Quiz("What is the shortest way from here?");
		q.addAnswer("Go straight ahead and then left, but then turn around and go back", 10);
		q.addAnswer("Right", 20);
		q.addAnswer("left", -10);
		p.quiz = q;
		pois.add(p);
		
		p = new PointOfInterest(48.14333, 11.649097, 5, "Target 4", R.drawable.location4);
		q = new Quiz("One more location question?");
		q.addAnswer("bla bla", -1);
		q.addAnswer("abc bac", 2);
		q.addAnswer("adsfadf adsfadsfdsf adfads asdfadsfds", -3);
		p.quiz = q;
		pois.add(p);
		
		p = new PointOfInterest(48.143133,11.649558, 5, "Target 5", R.drawable.location5);
		q = new Quiz("This is the last location question!!!");
		q.addAnswer("aa aa aaa a aa  aa aa", 4);
		q.addAnswer("kjhkljh  lkh lkjh lkj h lkjh ", -2);
		q.addAnswer("2344523 45438 4534 43", -2);
		p.quiz = q;
		pois.add(p);
		
		latitudeView = (TextView) findViewById(R.id.latitude);
		longitudeView = (TextView) findViewById(R.id.longitude);
		closestPoiView = (TextView) findViewById(R.id.closestPoi);
		distanceToClosestPoiView = (TextView) findViewById(R.id.distanceToPoi);
		pointsView = (TextView) findViewById(R.id.points);
	}

	protected void onResume() {
		super.onResume();
		locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5*1000, 0, this);
	}
	
	protected void onPause() {
		super.onPause();
		locationManager.removeUpdates(this);
	}

	public void onLocationChanged(Location location) {
		if (location != null) {
			double lat = location.getLatitude();
			double lon = location.getLongitude();

			latitudeView.setText(Double.toString(lat));
			longitudeView.setText(Double.toString(lon));
			
			float[] results = new float[1];

			float closestDistance = Float.MAX_VALUE;
			PointOfInterest closestPoi = null;

			for (PointOfInterest poi : pois) {
				Location.distanceBetween(lat, lon, poi.latitude, poi.longitude, results);
				float distance = results[0];
				if (distance < closestDistance || closestPoi == null) {
					closestDistance = distance;
					closestPoi = poi;
				}
			}
			
			if (closestPoi != null) {
				closestPoiView.setText(closestPoi.title);
				distanceToClosestPoiView.setText(Integer.toString((int)Math.round(closestDistance)) + "m");

				if (closestDistance < closestPoi.radius) {
					locationManager.removeUpdates(this);
					Intent intent = new Intent(this, ShowQuizActivity.class);
//					intent.putExtra("title", "Target 1");
//					intent.putExtra("image", R.drawable.location1);
//					intent.putExtra("poi", closestPoi);
					currentPoi = closestPoi;
					startActivityForResult(intent, 0);
				}
			}

		}
	}
	
	public void onProviderDisabled(String provider) {}
	
	public void onProviderEnabled(String provider) {}
	
	public void onStatusChanged(String provider, int status, Bundle extras) {}

	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, 0, 0, "target 1"); // group, id, order, title
		menu.add(0, 1, 1, "target 2");
		menu.add(0, 2, 2, "target 3");
		return true; // return true to enable menu
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		Intent intent = new Intent(this, ShowQuizActivity.class);
		// intent.putExtra("poi", pois.get(item.getItemId()));
		currentPoi = pois.get(item.getItemId());
		startActivityForResult(intent, 0);
		return true;
	}
	
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	points += resultCode;
    	pointsView.setText(Integer.toString(points));
    }

}
