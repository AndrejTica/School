package de.lmu.location2;

import java.io.Serializable;

public class PointOfInterest implements Serializable {

	double latitude;
	double longitude;
	double radius;
	String title;
	int imageId;
	Quiz quiz;

	public PointOfInterest(double lat, double lon, double rad, String t, int i) {
		latitude = lat;
		longitude = lon;
		radius = rad;
		title = t;
		imageId = i;
	}

}
