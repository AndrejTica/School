package de.lmu.location2;

import java.io.Serializable;
import java.util.Vector;

public class Quiz implements Serializable {
	
	private String question;
	private Vector<String> answers = new Vector<String>();
	private Vector<Integer> points = new Vector<Integer>();
	private int selectedAnswer = -1;
	
	public Quiz(String q) {
		question = q;
	}
	
	public void addAnswer(String a, int p) {
		answers.add(a);
		points.add(new Integer(p));
	}
	
	public String getQuestion() {
		return question;
	}
	
	public String getAnswer(int i) {
		return answers.get(i);
	}
	
	public int getPoints(int i) {
		return points.get(i).intValue();
	}
	
	public boolean done() {
		return selectedAnswer >= 0;
	}
	
	public void selectAnswer(int i) {
		selectedAnswer = i;
	}
	
	public int getSelectedAnswer() {
		return selectedAnswer;
	}
	
}
