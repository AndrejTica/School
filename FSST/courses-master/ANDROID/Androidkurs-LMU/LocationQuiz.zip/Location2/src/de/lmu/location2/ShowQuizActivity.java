package de.lmu.location2;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class ShowQuizActivity extends Activity implements OnClickListener {

	PointOfInterest poi;

	public void onCreate(Bundle savedInstanceState) {
		Log.d("ShowQuizActivity", "onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showquiz);
	}

	protected void onStart() {
		Log.d("ShowQuizActivity", "onStart");
		super.onStart();

		// poi = (PointOfInterest) getIntent().getSerializableExtra("poi");
		poi = MainActivity.currentPoi;

		TextView titleView = (TextView) findViewById(R.id.showQuestionTitle);
		titleView.setText(poi.title);

		ImageView imageView = (ImageView) findViewById(R.id.showQuestionImage);
		imageView.setImageResource(poi.imageId);

		TextView questionView = (TextView) findViewById(R.id.question);
		questionView.setText(poi.quiz.getQuestion());

		TextView answer = (TextView) findViewById(R.id.answer1);
		answer.setText(poi.quiz.getAnswer(0));

		answer = (TextView) findViewById(R.id.answer2);
		answer.setText(poi.quiz.getAnswer(1));

		answer = (TextView) findViewById(R.id.answer3);
		answer.setText(poi.quiz.getAnswer(2));

		Button b = (Button) findViewById(R.id.answerSubmitButton);
		b.setOnClickListener(this);

		boolean quizDone = poi.quiz.done();
		//		b.setEnabled(!MainActivity.currentPoi.quiz.done());
		b.setVisibility(quizDone ? View.GONE : View.VISIBLE);

		RadioGroup rg = (RadioGroup) findViewById(R.id.answersRadioGroup);
		int n = rg.getChildCount();
		int s = poi.quiz.getSelectedAnswer();
		Log.d("ShowQuizActivity", "selectedAnswer = " + s);
		if (s < 0) s = 0;
		for (int i = 0; i < n; i++) {
			RadioButton rb = (RadioButton)rg.getChildAt(i);
			rb.setEnabled(!quizDone);
			rb.setChecked(s == i);
		}
		
		Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		vibrator.vibrate(1000);
	}

	public void onClick(View v) {
		Log.d("ShowQuizActivity", "onClick");
		int points = 0;
		RadioGroup rg = (RadioGroup) findViewById(R.id.answersRadioGroup);
		switch (rg.getCheckedRadioButtonId()) {
		case R.id.answer1:
			points = poi.quiz.getPoints(0);
			poi.quiz.selectAnswer(0);
			break;
		case R.id.answer2:
			points = poi.quiz.getPoints(1);
			poi.quiz.selectAnswer(1);
			break;
		case R.id.answer3:
			points = poi.quiz.getPoints(2);
			poi.quiz.selectAnswer(2);
			break;
		}
		setResult(points);
		finish();
	}

}
