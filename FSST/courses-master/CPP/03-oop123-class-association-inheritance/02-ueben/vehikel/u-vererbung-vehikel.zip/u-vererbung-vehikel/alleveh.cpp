                 // Kapitel 7 - Programm 8 - ALLEVEH.CPP
#include <iostream.h>
#include "vehikel.h"
#include "auto.h"
#include "laster.h"

int main()
{
Vehikel Hochrad;

   Hochrad.Initialisiere(1, 5.7);
   cout << "Das Hochrad hat " <<
                        Hochrad.HoleRaeder() << " Rad.\n";
   cout << "Die Radlast des Hochrades betraegt " <<
                        Hochrad.Radlast() << " kg auf dem einzigen Rad.\n";
   cout << "Das Hochrad wiegt " <<
                        Hochrad.HoleGewicht() << " kg.\n\n";

Auto Sedan;

   Sedan.Initialisiere(4, 1600.0, 5);
   cout << "Der Sedan fuehrt " << Sedan.Passagiere() <<
                        " Passagiere mit sich.\n";
   cout << "Der Sedan wiegt " << Sedan.HoleGewicht() << " kg.\n";
   cout << "Die Radlast des Sedan ist " <<
                        Sedan.Radlast() << " kg pro Rad.\n\n";

Laster Sattelschlepper;

   Sattelschlepper.Initialisiere(18, 5700.0);
   Sattelschlepper.InitLaster(1, 15300.0);
   cout << "Der Sattelschlepper wiegt " << Sattelschlepper.HoleGewicht() << " kg.\n";
   cout << "Die Effizienz des Sattelschleppers ist " <<
                        100.0 * Sattelschlepper.Effizienz() << " Prozent.\n";

   return 0;
}


// Ergebnis beim Ausf�hren
//
// Das Hochrad hat 1 Rad.
// Die Radlast des Hochrades betraegt 5.7 kg auf den einzigen Rad.
// Das Hochrad wiegt 6.7 kg.
//
// Der Sedan fuehrt 5 Passagiere mit sich.
// Der Sedan wiegt 1600 kg.
// Die Radlast des Sedan ist 400 kg pro Rad.
//
// Der Sattelschlepper wiegt 5700 kg.
// Die Effizienz des Sattelschleppers ist 72.8571 Prozent.