				     // Kapitel 11 - Programm 5 - ANGEST.CPP
#include <iostream.h>
#include "person.h"
#include "aufshr.h"

Person *Belegschaft[10];

int main()
{
Aufseherin *AufsZg;
Programmiererin *ProgZg;
Sekretaer *SekrZg;

   cout << "Belegschaft XYZ -- Der Gehalt ist monatlich.\n\n";

   AufsZg = new Aufseherin;
   AufsZg->InitDaten("Hirraly", 7000, "Praesidentin");
   Belegschaft[0] = AufsZg;

   ProgZg = new Programmiererin;
   ProgZg->InitDaten("Jenny Hacker", 5000, "Testerin", "Pascal");
   Belegschaft[1] = ProgZg;

   ProgZg = new Programmiererin;
   ProgZg->InitDaten("OOP Genie", 9500, "Analysevorstand", "C++");
   Belegschaft[2] = ProgZg;

   SekrZg = new Sekretaer;
   SekrZg->InitDaten("Till Tipper", 1300, 1, 85);
   Belegschaft[3] = SekrZg;

   AufsZg = new Aufseherin;
   AufsZg->InitDaten("Elli Wichtig", 4350, "Verkaufsvorstand");
   Belegschaft[4] = AufsZg;

   ProgZg = new Programmiererin;
   ProgZg->InitDaten("Elfriede Soundso", 4750, "Code Warterin",
								"Assemblersprache");
   Belegschaft[5] = ProgZg;

   for (int Index = 0 ; Index < 6 ; Index++ )
   {
	Belegschaft[Index]->Zeige();
   }

   cout << "Ende der Belegschaftsliste.\n";

   return 0;
}


// Ergebnis beim Ausf�hren
//
// Belegschaft XYZ -- Der Gehalt ist monatlich.
//
// Aufseherin --> Hirralys Gehalt ist 7000 und Hirralys ist Praesidentin.
//
// Programmiererin --> Jenny Hackers Gehalt ist 5000 und Jenny Hacker ist Testerin.
//			Jenny Hackers Spezialitaet ist Pascal.
//
// Programmiererin --> OOP Genies Gehalt ist 9500 und OOP Genie ist Analysevorstand.
//			OOP Genies Spezialitaet ist C++.
//
// Sekretaer ---> Till Tippers Gehalt ist 1300.
//			Till Tipper tippt 85 pro minute und beherrscht Kurzschrift.
//
// Aufseherin --> Elli Wichtigs Gehalt ist 4350 und Elli Wichtig ist Verkaufsvorstand.
//
// Programmiererin --> Elfriede Soundsos Gehalt ist 4750 und Elfriede Soundso ist Code Warterin.
//			Elfriede Soundsos Spezialitaet ist Assemblersprache.
//
// Ende der Belegschaftsliste.