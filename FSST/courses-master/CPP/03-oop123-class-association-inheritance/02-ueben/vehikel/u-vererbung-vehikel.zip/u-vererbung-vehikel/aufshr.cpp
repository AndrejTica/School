				     // Kapitel 11 - Programm 4 - AUFSHR.CPP
#include "aufshr.h"
#include <iostream.h>
#include <string.h>

// �berall weist InitDaten den Klassenvariablen Werte zu und Zeige
//  gibt die Werte auf dem Monitor aus.

void
Aufseherin::InitDaten(char EinName[], int EinGehalt, char EinTitel[])
{
   strcpy(Name,EinName);
   Gehalt = EinGehalt;
   strcpy(Titel, EinTitel);
}




void
Aufseherin::Zeige(void)
{
   cout << "Aufseherin --> " << Name << "s Gehalt ist " << Gehalt <<
				" und " << Name << " ist " << Titel << ".\n\n";
}




void
Programmiererin::InitDaten(char EinName[], int EinGehalt,
					   char EinTitel[], char EinSprache[])
{
   strcpy(Name,EinName);
   Gehalt = EinGehalt;
   strcpy(Titel, EinTitel);
   strcpy(Sprache, EinSprache);
}




void
Programmiererin::Zeige(void)
{
   cout << "Programmiererin --> " << Name << "s Gehalt ist " << Gehalt <<
				" und " << Name << " ist " << Titel << ".\n";
   cout << "               " << Name << "s Spezialitaet ist " <<
								 Sprache << ".\n\n";
}




void
Sekretaer::InitDaten(char EinName[], int EinGehalt,
				     char EinKurzschrift, char EinTippgeschwindigkeit)
{
   strcpy(Name,EinName);
   Gehalt = EinGehalt;
   Kurzschrift = EinKurzschrift;
   Tippgeschwindigkeit = EinTippgeschwindigkeit;
}




void
Sekretaer::Zeige(void)
{
   cout << "Sekretaer ---> " << Name << "s Gehalt ist " << Gehalt <<
										   ".\n";
   cout << "               " << Name << " tippt " << Tippgeschwindigkeit <<
		  " pro minute und beherrscht ";
   if (!Kurzschrift)
	cout << "keine ";
   cout << "Kurzschrift.\n\n";
}