					 // Kapitel 11 - Programm 3 - AUFSHR.H
#ifndef AUFSHR_H
#define AUFSHR_H

// Wir definieren drei Subklassen der Elternklasse Person. F�r die
//  verschiedenen Aufgaben speichern wir verschiedene Daten und zeigen
//  wie das geht.

#include "person.h"

class Aufseherin : public Person
{
   char Titel[25];
public:
   void InitDaten(char EinName[], int EinGehalt, char EinTitel[]);
   void Zeige(void);
};



class Programmiererin : public Person
{
   char Titel[25];
   char Sprache[25];
public:
   void InitDaten(char EinName[], int EinGehalt, char EinTitel[],
			char EinSprache[]);
   void Zeige(void);
};



class Sekretaer : public Person
{
   char Kurzschrift;
   int Tippgeschwindigkeit;
public:
   void InitDaten(char EinName[], int EinGehalt,
			char EinKurzschrift, char EinTippgeschwindigkeit);
   void Zeige(void);
};

#endif