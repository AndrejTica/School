                            // Kapitel 7 - Programm 5 - AUTO.CPP
#include "auto.h"

void Auto::Initialisiere(int EinRaeder, float EinGewicht, int Leute)
{
   Passagieranzahl = Leute;
   Raeder = EinRaeder;
   Gewicht = EinGewicht;
}

int Auto::Passagiere(void)
{
   return Passagieranzahl;
}


// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden)