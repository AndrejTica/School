						 // Kapitel 7 - Programm 4 - AUTO.H
#ifndef AUTO_H
#define AUTO_H
#include "vehikel.h"
class Auto : public Vehikel
{
   int Passagieranzahl;
public:
   void Initialisiere(int EinRaeder, float EinGewicht, int Leute = 4);
   int Passagiere(void);
};
#endif

// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden)