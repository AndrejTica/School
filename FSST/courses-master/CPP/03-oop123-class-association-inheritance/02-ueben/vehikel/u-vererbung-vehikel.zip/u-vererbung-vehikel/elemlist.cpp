				     // Kapitel 11 - Programm 7 - ELEMLIST.CPP
#include <stdlib.h>
#include "elemlist.h"


void
AngestelltenListe::PersonHinzu(Person *NeueAngestellte)
{
AngestelltenElement *Temp;

   Temp = new AngestelltenElement(NeueAngestellte);
   if (Temp == NULL)
   {
	exit (1);
   }
   if (Start == NULL)
   {
	Start = EndeDerListe = Temp;
   }
   else
   {
	EndeDerListe->NaechsteAngestellte = Temp;
	EndeDerListe = Temp;
   }
}




void
AngestelltenListe::ZeigeListe(void)
{
AngestelltenElement *Temp;

   Temp = Start;
   do
   {
	Temp->AngestelltenDaten->Zeige();
	Temp = Temp->NaechsteAngestellte;
   } while (Temp != NULL);
}