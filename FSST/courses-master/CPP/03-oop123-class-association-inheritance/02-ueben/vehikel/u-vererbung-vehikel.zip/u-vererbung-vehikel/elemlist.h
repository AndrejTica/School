					 // Kapitel 11 - Programm 6 - ELEMLIST.H
#ifndef ELEMLIST_H
#define ELEMLIST_H

#define NULL 0
#include "person.h"

class AngestelltenListe;		    // Partielle Deklaration

class AngestelltenElement		    // Ein Element der verbundenen Liste
{
   Person *AngestelltenDaten;
   AngestelltenElement *NaechsteAngestellte;
public:
   AngestelltenElement(Person *NeueAngestellte)
			 {NaechsteAngestellte = NULL;
			  AngestelltenDaten = NeueAngestellte;};
   friend class AngestelltenListe;
};



class AngestelltenListe                  // Die verbundene Liste
{
   AngestelltenElement *Start;
   AngestelltenElement *EndeDerListe;
public:
   AngestelltenListe() {Start = NULL;}
   void PersonHinzu(Person *NeueAngestellte);
   void ZeigeListe(void);
};

#endif