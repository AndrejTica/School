					   // Kapitel 7 - Programm 7 - LASTER.CPP
#include "laster.h"

void Laster::InitLaster(int WieViele, float MaxLadung)
{
   Passagieranzahl = WieViele;
   Ladung = MaxLadung;
}

float Laster::Effizienz(void)
{
   return Ladung / (Ladung + Gewicht);
}

int Laster::Passagiere(void)
{
   return Passagieranzahl;
}


// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden)