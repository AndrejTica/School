					     // Kapitel 7 - Programm 6 - LASTER.H
#ifndef LASTER_H
#define LASTER_H

#include "vehikel.h"

class Laster : public Vehikel
{
   int Passagieranzahl;
   float Ladung;
public:
   void InitLaster(int WieViele = 2, float MaxLadung = 10000.0);
   float Effizienz(void);
   int Passagiere(void);
};

#endif


// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden)