					 // Kapitel 11 - Programm 2 - PERSON.CPP
#include <iostream.h>
#include "person.h"

		// Diese Methode sollte nie aufgerufen werden. Sollte
		// dies passiert, betrachten wir das als Fehler.
void
Person::Zeige(void)
{
   cout << "Person::Zeige - fehlende Methode in der Subklasse\n";
}