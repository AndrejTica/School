					   // Kapitel 11 - Programm 1 - PERSON.H
#ifndef PERSON_H
#define PERSON_H

class Person
{
protected:	  // Diese Variablen sind in Subklassen verf�gbar
   char Name[25];
   int Gehalt;
public:
   virtual void Zeige(void);
};

#endif