					 // Kapitel 7 - Programm 2 - VEHIKEL.CPP
#include "vehikel.h"

		  // Initialisiere mit den Paramtern
void Vehikel::Initialisiere(int EinRaeder, float EinGewicht)
{
   Raeder = EinRaeder;
   Gewicht = EinGewicht;
}

		  // Gib die Anzahl der R�der zur�ck
int Vehikel::HoleRaeder()
{
   return Raeder;
}

		  // Gib das Gewicht zur�ck
float Vehikel::HoleGewicht()
{
   return Gewicht;
}

		  // Gib das Gewicht pro Rad zur�ck
float Vehikel::Radlast()
{
   return Gewicht/Raeder;
}


// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden)