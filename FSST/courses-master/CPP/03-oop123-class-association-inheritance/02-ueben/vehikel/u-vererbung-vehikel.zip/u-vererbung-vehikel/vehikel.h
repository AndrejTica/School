					   // Kapitel 7 - Programm 1 - VEHIKEL.H
// header-Datei f�r Vehikel
#ifndef VEHIKEL_H
#define VEHIKEL_H
class Vehikel
{
protected:
   int Raeder;
   float Gewicht;
public:
   void Initialisiere(int EinRaeder, float EinGewicht);
   int HoleRaeder(void);
   float HoleGewicht(void);
   float Radlast(void);
};
#endif

// Ergebnis beim Ausf�hren
//
// (Diese Datei kann nicht ausgef�hrt werden.)