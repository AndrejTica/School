					// Kapitel 8 - Programm 4 - VERERB4.CPP
#include <iostream.h>

class Vehikel
{
protected:
   int Raeder;
   double Gewicht;
public:
   Vehikel(void)			{Raeder = 7;
					 Gewicht = 5050.0;}
   void Initialisiere(int EinRaeder, double EinGewicht);
   int HoleRaeder(void)       {return Raeder;}
   double HoleGewicht(void)	{return Gewicht;}
   double Radlast(void)       {return Gewicht/Raeder;}
};



class Auto : public Vehikel
{
   int Passagieranzahl;
public:
   Auto(void)			{Passagieranzahl = 4;}
   void Initialisiere(int EinRaeder, double EinGewicht, int Leute = 4);
   int Passagiere(void)       {return Passagieranzahl;}
};



class Laster : public Vehikel
{
   int Passagieranzahl;
   double Ladung;
public:
   Laster(void)			{Passagieranzahl = 3;
					 Ladung = 10100.0;}
   void InitLaster(int WieViele = 2, double MaxLadung = 10000.0);
   double Effizienz(void);
   int Passagiere(void)       {return Passagieranzahl;}
};



int main()
{
Vehikel Hochrad;

// Hochrad.Initialisiere(1, 5.7);
   cout << "Das Hochrad hat " <<
					  Hochrad.HoleRaeder() << " Rad.\n";
   cout << "Die Radlast des Hochrades betraegt " <<
	   Hochrad.Radlast() << " kg auf dem einzigen Rad.\n";
   cout << "Das Hochrad wiegt " <<
				     Hochrad.HoleGewicht() << " kg.\n\n";

Auto Sedan;

// Sedan.Initialisiere(4, 1600.0, 5);
   cout << "Der Sedan fuehrt " << Sedan.Passagiere() <<
							" Passagiere mit sich.\n";
   cout << "Der Sedan wiegt " << Sedan.HoleGewicht() << " kg.\n";
   cout << "Die Radlast des Sedan ist " <<
			  Sedan.Radlast() << " kg pro Rad.\n\n";

Laster Sattelschlepper;

// Sattelschlepper.Initialisiere(18, 5700.0);
// Sattelschlepper.InitLaster(1, 15300.0);
   cout << "Der Sattelschlepper wiegt " << Sattelschlepper.HoleGewicht() << " kg.\n";
   cout << "Die Effizienz des Sattelschleppers ist " <<
			  100.0 * Sattelschlepper.Effizienz() << " Prozent.\n";

   return 0;
}



		  // Initialisiere mit den Paramtern
void Vehikel::Initialisiere(int EinRaeder, double EinGewicht)
{
   Raeder = EinRaeder;
   Gewicht = EinGewicht;
}



void Auto::Initialisiere(int EinRaeder, double EinGewicht, int Leute)
{
   Passagieranzahl = Leute;
   Raeder = EinRaeder;
   Gewicht = EinGewicht;
}



void Laster::InitLaster(int WieViele, double MaxLadung)
{
   Passagieranzahl = WieViele;
   Ladung = MaxLadung;
}



double Laster::Effizienz(void)
{
   return Ladung / (Ladung + Gewicht);
}


// Ergebnis beim Ausf�hren
//
// Das Hochrad hat 7 Rad.
// Die Radlast des Hochrades betraegt 721.429 kg auf den einzigen Rad.
// Das Hochrad wiegt 5050 kg.
//
// Der Sedan fuehrt 4 Passagiere mit sich.
// Der Sedan wiegt 5050 kg.
// Die Radlast des Sedan ist 721.429 kg pro Rad.
//
// Der Sattelschlepper wiegt 5050 kg.
// Die Effizienz des Sattelschleppers ist 66.6667 Prozent.