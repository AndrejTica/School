//frage: aendere das prograqmm derart, dass folg ausgabe m�glich ist:
// Ergebnis beim Ausf�hren
//
// Nachricht vom Vehikel
// Nachricht vom Auto
// Nachricht vom Vehikel
// Nachricht vom Boot

				     // Kapitel 10 - Programm 6 - VIRTL6.CPP
#include <iostream.h>

class Vehikel
{
   int Raeder;
   float Gewicht;
public:
   ...del ... void Nachricht(void) {cout << "Nachricht vom Vehikel\n";}
};


class Auto : public Vehikel
{
   int Passagieranzahl;
public:
   void Nachricht(void) {cout << "Nachricht vom Auto\n";}
};


class Laster : public Vehikel
{
   int Passagieranzahl;
   float Ladung;
public:
   int Passagiere(void) {return Passagieranzahl;}
};


class Boot : public Vehikel
{
   int Passagieranzahl;
public:
   int Passagiere(void) {return Passagieranzahl;}
   void Nachricht(void) {cout << "Nachricht vom Boot\n";}
};


int main()
{
Vehikel *Hochrad;

   Hochrad = new Vehikel;
   Hochrad->Nachricht();
   delete Hochrad;

   Hochrad = new Auto;
   Hochrad->Nachricht();
   delete Hochrad;

   Hochrad = new Laster;
   Hochrad->Nachricht();
   delete Hochrad;

   Hochrad = new Boot;
   Hochrad->Nachricht();
   delete Hochrad;

   return 0;
}


// Ergebnis beim Ausf�hren
//
// Nachricht vom Vehikel
// Nachricht vom Auto
// Nachricht vom Vehikel
// Nachricht vom Boot
