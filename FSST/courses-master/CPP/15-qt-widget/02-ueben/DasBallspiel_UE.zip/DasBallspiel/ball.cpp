#include "ball.h"


Ball::Ball(int x,int y,int dx,int dy,int w,int h, const QColor& q){
    this->x=x;
    this->y=y;
    this->dx=dx;
    this->dy=dy;

    this->w=w;
    this->h=h;

    this->q=q;

}

void Ball::moveTO(int x, int y){
    setX(x);
    setY(y);
}

void Ball::setX(int x){
    this->x=x;
}

void Ball::setY(int y){
    this->y=y;
}


void Ball::move(){
    setX(x+dx);
    setY(y+dy);
}


void Ball::repaint( QPainter& p){
    QBrush b1( q );  // blue filler
    p.setBrush(b1);

    p.drawEllipse( x, y, w,h );

}
