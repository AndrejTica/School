#ifndef BALL_H
#define BALL_H

#include <QPainter>
#include <Qcolor>

class Ball
{
public:
    Ball(int x,int y,int dx,int dy,int w,int h, const QColor& q);

    void moveTO(int x, int y);
    void move();
    void repaint( QPainter& p);

    void setX(int x);
    void setY(int y);

    int getX(){ return x;}
    int getY(){ return y;}

    int getW(){ return w;}
    int getH(){ return h;}



private:
    int x,y;
    int dx,dy;
    int w,h;
    QColor q;
};

#endif // BALL_H
