#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::Widget)
{
    ui->setupUi(this);


    // Bälle erzeugen
    ball1= new Ball(100,100,2,2,20,20, Qt::blue);
    ball2= new Ball(140,140,-2,2,20,20, Qt::red);


}

Widget::~Widget()
{
    delete ui;

    delete ball1;
    delete ball2;
}



void Widget::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);

    // Bälle zeichnen
    ball1->repaint(painter);
    ball2->repaint(painter);

}




// SLOTS
void Widget::on_pushButtonStart_clicked()
{
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));

    ui->horizontalSlider->setEnabled(true);
    ui->pushButtonStart->setEnabled(false);

    int delay= ui->horizontalSlider->value();
    timer->start(delay);
}

void Widget::update(){ // Timer hat getickt, d.h. ein signal ausgesendet

    //cout << "tick...";

    //bälle bewegen
    ball1->move();
    ball2->move();

    // sind bälle draussen
    int w= this->width();
    int h= this->height();

    //ball1
    int bx= ball1->getX();
    int by= ball1->getY();
    int bw= ball1->getW();
    int bh=ball1->getH();

    if (bx > w || by > h || bx <0 || by<0){
	int leben= ui->lcdNumber->value();
	leben--;
	ui->lcdNumber->display(leben);

	if (leben == 0){
	    QMessageBox m;
	    m.setText("Leider kein Leben mehr!!!");
	    m.exec();

	    exit(0);
	}
	else
	    ball1->moveTO(qrand()% w ,qrand()%h);
    }

    //ball2
    bx= ball2->getX();
    by= ball2->getY();
    bw= ball2->getW();
    bh= ball2->getH();

    if (bx > w || by > h || bx <0 || by<0){
	int leben= ui->lcdNumber->value();
	leben--;
	ui->lcdNumber->display(leben);

	if (leben == 0){
	    QMessageBox m;
	    m.setText("Leider kein Leben mehr!!!");
	    m.exec();

	    exit(0);
	}
	else
	    ball2->moveTO(qrand()% w ,qrand()%h);
    }



    ostringstream o;
    o << "w="  << w << "h=" << h << "-bx=" << bx << " by=" << by << endl;
    cout << o.str();



    repaint();
}

void Widget::on_horizontalSlider_valueChanged(int value)
{
    timer->setInterval(value);
}
