#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMessageBox>

#include <QPaintEvent>
#include <QPainter>

#include <QTimer>



#include "ball.h"

#include <iostream>
#include <sstream>

using namespace std;




namespace Ui {
    class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget *ui;

    Ball* ball1;
    Ball* ball2;

    QTimer *timer;

protected:
    void paintEvent(QPaintEvent *);


private slots:
    void on_horizontalSlider_valueChanged(int value);
    void on_pushButtonStart_clicked();

    void update(); // Timer hat getickt, d.h. ein signal ausgesendet
};

#endif // WIDGET_H
