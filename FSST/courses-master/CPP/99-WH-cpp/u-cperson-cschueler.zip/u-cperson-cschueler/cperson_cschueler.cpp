// a.hofmann 2006
// cperson_cschueler.cpp
// demo: Vererbung

#include <iostream>
#include <string>
using namespace std;

// 
// CPERSON ist die OBERKLASSE
//
class CPerson {
 	private:
		int m_alter;
		
	protected:
		string m_name;

	public:
		CPerson(string pname, int palter) {
			m_name= pname;
			m_alter= palter;
			cout << "\nKonstruktor der OBER-Klasse: CPERSON fertig....." << endl;
		}
			
		int getAlter()const{
			return m_alter;
		}
			
};


//
// CSCHUELER ist eine CPERSON  (isA-Beziehung: Vererbung)
//
class CSchueler : ???????????????? {
	private:
		string m_jahrgang;

	public:
		CSchueler(string pname, int palter, string pjahrgang) ???????????????{
			m_jahrgang= pjahrgang;
			cout << "\nKonstruktor der UNTER-Klasse: CSCHUELER   fertig...." << endl;
		}
		
		void display()const{
			cout<< "    SCHUELER_NAME: " << this->m_name << endl;
			cout<< "   SCHUELER_ALTER: " << getAlter() << endl;
			cout<< "SCHUELER_JAHRGANG: " << this->m_jahrgang << endl<<endl;
		}
};



int main(){
	CSchueler *ich= new CSchueler("Max Mustermann", 21, "3XHELI");
	//CSchueler du("Greti Hofmann", 17, "3BHELI");
	
	ich->display();
	//du.display();
	
	return 0;
}
