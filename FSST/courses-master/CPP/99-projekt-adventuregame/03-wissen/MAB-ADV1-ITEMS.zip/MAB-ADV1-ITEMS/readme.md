# Quiz: Adventure Game V1 (ADV1) with items(name,value)
---
File: MAB-ADV1-ITEMS.zip


## 1. install and run ADV1
----
You have:
* main.cpp
* CGame.cpp, CGame.h
* world.txt

Compile with: 
* `g++ main.cpp CGame.cpp -o main.exe`

Run with: 
* `./main.exe`


## 2. Aufgaben
---
1. Bringen Sie das Programm auf Ihrem System zum Laufen.  
Hinweis: Beachten Sie, ob die world.txt eine Windows/Linux Datei ist.

2. Die Räume im Spiel sollen noch sogenannte items enthalten.  
Studieren Sie die Datei world-items.txt

3. Passen Sie das Programm so an, dass bei der Usereingabe auch diese
items angezeigt werden.

4. Beachten Sie die folgenden Vorgaben:  
	a) Es muss die Klasse Item programmiert werden.  
	b) Ein Raum verwendet einen vector (STL), um die items zu speichern.



## 3. Fragen
---
1. Aus welchen Komponenten besteht die Klasse Raum?  
	a) Data member  
	b) Methoden

2. In welcher Klasse erfolgt die Verarbeitung der User-Eingabe?

3. Zeigen Sie den Programm-code, um die Informationen für einen
bestimmten Raum einzulesen.



