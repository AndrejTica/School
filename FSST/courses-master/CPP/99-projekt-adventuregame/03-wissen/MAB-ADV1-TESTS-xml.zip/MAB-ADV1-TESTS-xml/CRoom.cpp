// a.hofmann dez 2004
//CRoom.cpp

#include "CRoom.h"
#include <string>
#include <iostream>
using namespace std;

void CRoom::moveto( string& strRoom){
	if(strRoom == "None") {
		cout << "   Es gibt keinen Weg dorthin!" << endl;	
		return;									
	}
		
	readRoomInfo(strRoom);		
}

// suche den Raum  "<" + aRoom + ">" und lies die RaumInfo
void CRoom::readRoomInfo(string& aRoom){
	string strLine = "";
	string strTemp = "";
	string strRoom = "<" + aRoom + ">";

	// an den Dateianfang positionieren
	fin.seekg(ios::beg);
	fin.clear();

	// zeilenweise lesen
	while(getline(fin, strLine, '\n')){
		
		if(strLine == strRoom){
			getline(fin, strRoomDescription, '*');	

			strCurrentRoom = aRoom;
			fin >> strTemp >> strRoomNorth;				
			fin >> strTemp >> strRoomEast;				
			fin >> strTemp >> strRoomSouth;				
			fin >> strTemp >> strRoomWest;				

			return;									
		}
	}

}



void CRoom::display(void) const{
	cout << strRoomDescription << endl << endl;		
}
