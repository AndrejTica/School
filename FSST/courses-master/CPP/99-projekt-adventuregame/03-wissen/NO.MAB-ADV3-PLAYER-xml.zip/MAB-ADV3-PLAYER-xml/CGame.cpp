//a.hofmann dez 2004
//CGame.cpp

#include "CGame.h"
#include <iostream>
#include <string>
using namespace std;

#include <cstdlib>

// KONSTRUKTOR: RAUM und SPIELER erzeugen
CGame::CGame(const char* pFilename){

	fin.open(pFilename);

	if(fin.fail()){
	        cout << "   Fehler: Konnte " << pFilename << " nicht finden" << endl;
        	exit (1);
	}
	
	// 1. PLAYER erzeugen und Dateneinlesen
	m_Player= new CPlayer(fin);
	m_Player->display();


	// 2. RAUM erzeugen und Daten des StartRaumes laden
	m_Room= new CRoom(fin);
	
	// Name des Startraumes ermittlen
	// 1. Zeile in der Datenbasis: <start> name
	string startRoom;	
	fin>>startRoom>>startRoom;

	m_Room->readRoomInfo(startRoom);
//	m_Room->display();

}

void CGame::start(){
	string aRoom;
	string strInput ="";
	
	cout  << "   -//--//--//--//--//-                                      -//--//--//--//--//- " << endl;
	cout  << "   -//--//--//--//--//-    A D V E N T U R E      G A M E    -//--//--//--//--//- " << endl;
	cout  << "   -//--//--//--//--//-                                      -//--//--//--//--//- " << endl;
	cout  << endl;
	cout  << "   Befehle: status, schau, nord, sued, west, ost, hilfe, ?, ende, zeige ObjektName" << endl;

	while(1){
		// Prompt ausgeben
		cout  << endl << m_Room->getCurrentRoom() <<":> ";

		//Benutzereingabe lesen
		cin >> strInput;

		if(strInput == "schau"){
			m_Room->display();			
		}
		else if(strInput == "nord"){
			aRoom=m_Room->getRoomNorth();
			m_Room->moveto(aRoom);	
			m_Room->display();			
		}
		else if(strInput == "ost"){
			aRoom=m_Room->getRoomEast();		
			m_Room->moveto(aRoom);	
			m_Room->display();			
		}
		else if(strInput == "sued"){
			aRoom=m_Room->getRoomSouth();
			m_Room->moveto(aRoom);	
			m_Room->display();			
		}
		else if(strInput == "west"){
			aRoom=m_Room->getRoomWest();		
			m_Room->moveto(aRoom);	
			m_Room->display();			
		}
		else if(strInput == "ende"){
			return ;			
		}
		else if(strInput == "hilfe" || strInput == "?"){												
			cout << endl << "   Befehle: status, schau, nord, sued, west, ost, hilfe, ?, ende, zeige ObjektName" << endl;
		}
		// 2
		else if(strInput == "zeige"){
			//lies, was gezeigt werden soll
			cin >> strInput;
			if (m_Room->containsZeigeObjekt(strInput)){
				//suche in der datenbank nach der Beschreibung
				// Format::= <RAUM|OBJEKT>
				strInput= "<" + m_Room->getCurrentRoom() + "|" +strInput + ">";
				m_Room->readZeigeInfo(strInput);
				m_Room->displayZeigeDescription();
			}
			else {
				cout << "   FEHLER: " << strInput<<" nicht gefunden!" <<endl;	
			}
		}
//3
		else if(strInput == "status"){
			m_Player->display();
		}

		else{
			cout << endl << "   Befehl unbekannt ???" << endl;
			cout << endl << "   Befehle: status, schau, nord, sued, west, ost, hilfe, ?, ende, zeige Objektname" << endl;
		}



		// This function is called to handle the battle scenes.  If there is
		// a monster in the current room, this function will loop continuously
		// until either the player or monster are dead.  If you die, the game is over,
		// otherwise you keep on truckin'.

		if(m_Room->attackPlayer(m_Player) == PLAYER_IS_DEAD)
			break;

	
	}//while

	//SPIELENDE
}

CGame::~CGame(){
	fin.close();
	delete m_Room;
}

