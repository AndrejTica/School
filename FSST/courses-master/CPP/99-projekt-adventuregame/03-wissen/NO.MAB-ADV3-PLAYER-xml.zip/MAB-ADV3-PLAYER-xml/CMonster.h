// This is our monster class.  An instance of this class is created in our tRoom,
// structure.  We created a bunch of data access functions to set and query the 
// monster's data.  The functions should be very straightforward to what they do.  
// Though there isn't must in the player class now, you will add more functions 
// for the monster's AI, inventory, etc...

#ifndef CMonster_h
#define CMonster_h CMonster_h

class CMonster {
public:
	void SetName(string strMonsterName)		{ m_strName = strMonsterName; }
	void SetAttackMessage(string strMessage)	{ m_strAttackMessage = strMessage; }
	void SetHealth(int monsterHealth)		{ m_health = monsterHealth; }
	void SetDamage(int monsterDamage)		{ m_damage = monsterDamage; }

	string GetName()	const			{ return m_strName;	}
	string GetAttackMessage()	const		{ return m_strAttackMessage; }
	
	int GetHealth()		const			{ return m_health;	}
	int GetDamage()		const			{ return m_damage;	}
	
private:								
	string m_strName;			// This stores the monster's name
	string m_strAttackMessage;		// This stores the monster's attatcking message
	int m_health;				// This stores the monster's health
	int m_damage;				// This stores the damage the monster's weapon inflicts
};
#endif
