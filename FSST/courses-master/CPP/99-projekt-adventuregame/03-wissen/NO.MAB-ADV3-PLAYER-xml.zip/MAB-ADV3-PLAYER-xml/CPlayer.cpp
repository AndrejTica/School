// CPlayer.cpp
// a.hofmann 2006
//

#include <string>
#include <iostream>
using namespace std;

#include "CPlayer.h"

CPlayer::CPlayer(ifstream& fin){

	// Lies die Daten aus der Datei
	string strWord;
	int data = 0;

	// Hier brauchen wir nicht nach den Daaten in der Datei zu suchen,
	// denn sie befinden sich am Dateianfang
	// <name>   Priska	
	// <gesundheit> 275	
	// <waffe> geschicklichkeit
	// <schaden> 21
	//
		
	// Zum Dateibegin und EOF-Flag löschen
	fin.seekg(ios::beg);
	fin.clear();
	fin.seekg(ios::beg);
	fin.clear();

	// Der Name des Spielers
	fin >> strWord >> strWord;
	m_strName= strWord;

	// Lies das wort <gesundheit> und lies dann den int-Wert
	fin >> strWord >> data;
	m_health= data;

	// Waffe
	fin >> strWord >> strWord;
	m_strWeapon= strWord;

	// Schaden
	fin >> strWord >> data;
	m_damage= data;
}

void CPlayer::display(void) const {
	cout << "\n   ===> AKTUELLER ZUSTAND DES SPIELERS"<<endl;
	cout << "   ===> Name: "       << m_strName   << endl;
	cout << "   ===> Gesundheit: " << m_health << endl;
	cout << "   ===> Waffe: "      << m_strWeapon << endl;
	cout << "   ===> Schaden: "    << m_damage << endl;
}
