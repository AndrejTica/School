// This is our player class.  An instance of this class is created in CGame.

#ifndef CPlayer_h
#define CPlayer_h CPlayer_h

#include <string>
#include <fstream>
using namespace std;

class CPlayer {
public:
	CPlayer(ifstream& fin); 

	void SetName(string strPlayerName)	{ m_strName = strPlayerName; }
	void SetHealth(int playerHealth)	{ m_health = playerHealth; }
	void SetWeapon(string strPlayerWeapon)	{ m_strWeapon = strPlayerWeapon; }
	void SetDamage(int playerDamage)	{ m_damage = playerDamage; }
	
	string GetName()	const		{ return m_strName; } 
	string GetWeapon()	const		{ return m_strWeapon; }
	
	int GetDamage()		const		{ return m_damage; }
	int GetHealth()		const		{ return m_health; }

	void display(void) 	const;
	
private:	
	string m_strName;		// This stores the player's name
	int m_health;			// This stores the player's health
	string m_strWeapon;		// This stores the name of the player's weapon
	int m_damage;			// This stores the damage the player's weapon inflicts
};
#endif
