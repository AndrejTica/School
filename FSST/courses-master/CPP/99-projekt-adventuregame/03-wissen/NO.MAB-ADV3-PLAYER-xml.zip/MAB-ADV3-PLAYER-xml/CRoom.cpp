// a.hofmann dez 2004
//CRoom.cpp

#include "CRoom.h"
#include <unistd.h>
#include <string>
#include <cstdlib>
#include <iostream>
using namespace std;

void CRoom::moveto( string& strRoom){
	if(strRoom == "None") {
		cout << "   Es gibt keinen Weg dorthin!" << endl;	
		return;	
	}
//	cout << "DEBUG: MOVETO" << strRoom <<endl;	
	readRoomInfo(strRoom);		
	//display();
}

// suche den Raum  "<" + aRoom + ">" und lies die RaumInfo
void CRoom::readRoomInfo(string& aRoom){
	string strLine = "";
	string strTemp = "";
	string strRoom = "<" + aRoom + ">";

	// an den Dateianfang positionieren
	fin.seekg(ios::beg);
	fin.clear();
fin.seekg(ios::beg);
fin.clear();

	// zeilenweise lesen
	while(getline(fin, strLine, '\n')){
		//cout << "gelesen:="<<strLine<<"=" << endl;
		//cout << "DEBUG: readRoomInfo: gesucht:="<<strRoom<<"=" << endl;
		
		if(strLine == strRoom){
			getline(fin, strRoomDescription, '*');	

			strCurrentRoom = aRoom;
			fin >> strTemp >> strRoomNorth;				
			fin >> strTemp >> strRoomEast;				
			fin >> strTemp >> strRoomSouth;				
			fin >> strTemp >> strRoomWest;				
			
			//Objekte , Monster vorhanden
			m_zeige_anz=0;
			fin >>strTemp;
			if (strTemp=="<zeige>"){
				int i;
				fin >>m_zeige_anz;
				for (i=0; i<m_zeige_anz;i++)
					fin>>m_zeigeArray[i];
				//Kontrolle
				//for (i=0; i<m_zeige_anz;i++)
				//	cout <<"ZEIGE "<<m_zeigeArray[i];
				
			}

			//MonsterInfo vorhanden
			m_bMonsterInRoom=false;
			fin >>strTemp;
			if (strTemp=="<monster>"){
				fin >> strTemp;	//lies monstername
				//Kontrolle
				cout << "MONSTER: " << strTemp << endl;
				if (strTemp != "None") {
					m_bMonsterInRoom=true;
					this->readMonsterInfo(strTemp);
				}
			}
			
			return;	
		}//if
	}//while

}

void CRoom::display(void) const{
	cout << strRoomDescription << endl << endl;
//2
	cout <<"   ===> Vorhandene Objekte (zeige Objektname): ";
	for (int i=0; i<m_zeige_anz; i++)
		cout << "<" <<m_zeigeArray[i] << "> ";	
	cout <<endl;
//3
	if (m_bMonsterInRoom==true){
		cout << "   ===> Vorhandenes Monster: ";
		cout << "<" << m_monster.GetName() << "> ";
	}
	else
		cout << "   ===> (Noch) Kein Monster vorhanden!";

}



//2
bool CRoom::containsZeigeObjekt(string& pStrZeige) const{
	for (int i=0; i <m_zeige_anz; i++)
		if (m_zeigeArray[i]==pStrZeige)
			return true;
	return false;
}

bool CRoom::readZeigeInfo(string& pStrZeige){
	string strLine;
	// an den Dateianfang positionieren
	fin.seekg(ios::beg);
	fin.clear();
fin.seekg(ios::beg);
fin.clear();

	// zeilenweise lesen
	while(getline(fin, strLine, '\n')){
		//cout << "gelesen:="<<strLine<<"=" << endl;
		//cout << "gesucht:="<<strRoom<<"=" << endl;
		
		if(strLine == pStrZeige){
			getline(fin, m_strZeigeDescription, '*');	
		}
	}
}

void CRoom::displayZeigeDescription(void) const {
	cout << m_strZeigeDescription <<endl;
}


//3
void CRoom::readMonsterInfo(string strMonsterName) {
	// enthaelt die jeweils gelesene Zeile aus der datenbasis
	string strLine = "";								

	// zum Dateianfang
	fin.seekg(ios::beg);						
	fin.clear();
	fin.seekg(ios::beg);						
	fin.clear();

	// setze den Namen des Monsters
	m_monster.SetName(strMonsterName);

	// Lies Zeile für Zeile
	while(getline(fin, strLine, '\n'))	
	{
		// Such nach folg. Muster in der Datenbasis
		// "<" + Raumname + "|" + MonsterName + ">" = 
		// "<room.strCurrentRoom|strMonsterName>" = 
		// "<schlafzimmer|dracula>"
		//
		
		// ist die aktuell gelesene Zeile schon unsere gesuchte Zeile?
		if(strLine == "<" + strCurrentRoom + "|" + strMonsterName + ">")
		{
			// One of the differences from getting the monster info and getting the look
			// descriptions is that the monsters have 3 blocks of information.
			// Let's look at a full monster block:
			//
			// <schlafzimmer|dracula> 
			// <gesundheit> 125
			// <schaden> 12
			// <attacke> Whooooh, ein kleiner biss und die Nacht wird zum Tag.* 

			// Ein int um die gesaundheit und den schaden Wert zu speichern
			int data = 0;

			// gesundheit
			fin >> strLine >> data;
			m_monster.SetHealth(data);

			// schaden
			fin >> strLine >> data;
			m_monster.SetDamage(data);

			// Überlies das "<attacke>" Wort
			fin >> strLine;

			// Lies die attacke Beschreibung
			getline(fin, strLine, '*');
			m_monster.SetAttackMessage(strLine);

			return;
		}
	}
}

//3
int CRoom::attackPlayer(CPlayer* player) {
	// This is probably the most important and complicated function in this tutorial.
	// In order to simplify the tutorial so no one will get lost, the battle sequence 
	// is NOT random and does NOT take off random damages.  Though this would have been 
	// pretty easy to add, I chose to leave it out.  It will give you something to do 
	// yourself that isn't too hard.  Let's go over the algorithm that is used for battle:

	// while(there is a monster in the room)
	// { 
	//    - The monster attacks first and subtracts their damage from the player's health
	//    - The player then attacks and subtracts his/her damage from the monster's health
	//  
	//	  - Now we check: if(the player is dead), we return PLAYER_IS DEAD and the game is over
	//    - Otherise, we check:  if(the monster is dead), display a victory message and stop
	//    - If the player and monster are still alive, we want to loop again from the top
	// }
	//
	// Pretty simple huh?  It doesn't get any easier than that.  It should be fun to see what
	// you guys come up with for your fighting sequences.
	//

	// Check if there is a monster in the room
	while(m_bMonsterInRoom)
	{
		system("clear");
		cout << endl << strCurrentRoom << "> Das Monster <" << m_monster.GetName()<<"> ist im Raum." <<endl;
 		cout << "   ===> in 10 Sekunden greift es dich an ";
		cout.flush();
		for (int i=1 ; i <= 10 ; i++) {
			sleep(1);	//2 Sekungen
			cout << ".";
			cout.flush();
		}
		cout << endl;
		cout.flush();

		// Display the attack message of the monster, right before it attacks us
		cout << m_monster.GetAttackMessage() << endl<<endl;

		// Subtract the monster's damage from our health because we just got hit.
		// The result of "player.GetHealth() - room.monster.GetDamage()" will be then
		// passed into SetHealth(), which will change the players health to a lower number.
		player->SetHealth(player->GetHealth() - m_monster.GetDamage());
		
		// Display our current health
		cout << "   ===> SPIELER: " << player->GetHealth() << " PUNKTE." << endl;
		// Displa the monsters status
		cout << "   ===> MONSTER: " << m_monster.GetHealth() << " PUNKTE" << endl;

		// Display our attack message before we pound the enemy
		cout << "        ";
		cout << player->GetName() << ", du greifst das Monster <"  << m_monster.GetName() 
		<< ">\n        mit deiner Waffe <"      << player->GetWeapon() << "> mit <" 
			 << player->GetDamage() << " Schadenspunkten> an!"     << endl;

		// Subtract our damage from the monster's health
		m_monster.SetHealth(m_monster.GetHealth() - player->GetDamage());


		// We our health is less than 0 (we died)...
		if(player->GetHealth() <= 0)
		{
			// Display a defeating message and quit the game
			cout << "   ===> DU bist leider tot!" << endl;
			return PLAYER_IS_DEAD;
		}
		// Else if the monster is dead...
		else if(m_monster.GetHealth() <= 0)
		{
			// Display our victory and set the monster flag to false (no more monster)
			cout << "   ===> DU hast das Monster (" << m_monster.GetName() << ") besiegt!" << endl;
			m_bMonsterInRoom = false;		
		}

		if (m_bMonsterInRoom) {
			// Put in a delay between each round
			cout << "\n   ===>  .......... Kampf ";
			cout.flush();
			for (int i=1 ; i <= 10 ; i++) {
				sleep(1);	//2 Sekungen
				cout << ".";
				cout.flush();
			}
			cout << endl;
			cout.flush();
		}
	}

	// The monster didn't stand a chance, so we return a flag that says we are still alive
	return PLAYER_STILL_ALIVE;
}
