//CRoom.h
//a.hofmann dec 2004

#ifndef CRoom_h
#define CRoom_h CRoom_h

#include <string>
#include <fstream>
using namespace std;
#define MAXANZ 10

#include "CMonster.h"
#include "CPlayer.h"

#define PLAYER_IS_DEAD  0
#define PLAYER_STILL_ALIVE  1

class CRoom{
private:
	string strCurrentRoom;				// speichert den Namen des aktuellen Raumes
	string strRoomDescription;			// Raum-Beschreibung (s.u.: endet mit *)
	string strRoomNorth;				// Name des Raumes, der im Norden ist
	string strRoomEast;				// -"-			
	string strRoomSouth;				// -"-
	string strRoomWest;				// -"-
	
	ifstream& fin;					//Merke FileStream zur Datenbasis
	//2
	string m_zeigeArray[MAXANZ];			//zeige objektnamen 
	int m_zeige_anz;
	string m_strZeigeDescription;

	//3
	CMonster m_monster;				// Unsere Monster Daten für diesen Raum
	bool m_bMonsterInRoom;				// .. sagt uns, ob ein Monster im Raum ist
public:
	CRoom(ifstream& pfin): fin(pfin) {}		//Merke FileStream zur Datenbasis
	
	void moveto(string& aRoom);			//ruft readRoomInfo() auf
	void readRoomInfo(string& aRoom);
	
	string getCurrentRoom() const { return strCurrentRoom; }
	string getRoomNorth() const { return strRoomNorth; }
	string getRoomSouth() const { return strRoomSouth; }
	string getRoomWest() const { return strRoomWest; }
	string getRoomEast() const { return strRoomEast; }
	
	string toString(){ return strRoomDescription; };
	
	void display(void) const;
	//TODO: operator<<()

	//2
	bool containsZeigeObjekt(string& pStrZeige) const ;
	bool readZeigeInfo(string& pStrZeige);
	void displayZeigeDescription(void) const;

	//3
	void readMonsterInfo(string strMonsterName);
	int attackPlayer(CPlayer* player);
};
#endif
