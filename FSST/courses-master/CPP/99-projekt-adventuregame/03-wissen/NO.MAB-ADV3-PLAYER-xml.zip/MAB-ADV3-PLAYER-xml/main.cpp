// a.hofmann dec 2004
// main.cpp

#include <cstdlib>
#include "CGame.h"

#define CLS system("clear")

int main(){
    CGame meinSpiel("world.txt");

    CLS;
    meinSpiel.start();

	return 0;
}

