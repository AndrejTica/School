# Quiz: Adventure Game V3 (ADV3) with player.xml
---
File: MAB-ADV3-PLAYER-xml.zip


## 1. install and run ADV3
----
You have:
* main.cpp
* CGame.cpp, CGame.h
* CRoom.cpp, CRoom.h
* CMonster.h
* CPlayer.cpp, CPlayer.h
* world.txt

Compile with: 
* `	g++ -o main.exe main.cpp CGame.cpp CPlayer.cpp CRoom.cpp`

Run with: 
* `./main.exe`



## 2. Study XML and tinyxml
----
Unzip and study
* `unzip demo_adventuregame_fragen_tinyxml.zip`
* `cd demo_adventuregame_fragen_tinyxml`
* `g++ tinyxml2.cpp adv_questions.cpp -o adv_questions.exe`
* `./adv_questions.exe`

See File: **adv_questions.xml**
~~~
<?xml version="1.0" encoding="UTF-8"?>
<fragen>
<frage>
<fragentext>
BEISPIEL: SINGLE-CHOICE-Frage
Objekte, die nicht mehr benötigt werden, müssen gelöscht
werden. Dazu wird eine boolsche Variable remove verwendet. 
In welcher Klasse wird Sie definiert?
a) Sprite b) Rocket c) GamePanel d) Explosion
</fragentext>
<loesungstext>a</loesungstext>
<punkte>10</punkte>
</frage>

<frage>
<fragentext>
BEISPIEL: SINGLE-CHOICE-Frage
Das tatsächliche Löschen der Objekte erfolgt in
a) GamePanel.doLogic() b) Rocket.doLogic 
</fragentext>
<loesungstext>a</loesungstext>
<punkte>10</punkte>
</frage>


<frage>
<fragentext>
BEISPIEL: MULTIPLE-CHOICE: mit , trennen
Von Ihnen programmierte Klassen im Spiel:
a) GamePanel b) Rocket c) Image d) Movable
</fragentext>
<loesungstext>a,b</loesungstext>
<punkte>20</punkte>
</frage>


<frage>
<fragentext>
BEISPIEL: SINGLE-LÜCKEN-Frage: 
Was gehört statt ??? geschrieben.
public class GamePanel extends JPanel ??? Runnable{...}
</fragentext>
<loesungstext>implements</loesungstext>
<punkte>10</punkte>
</frage>


<frage>
<fragentext>
BEISPIEL: MULTIPLE_LÜCKEN-Frage: Antworten mit , trennen
Was gehört statt ??? geschrieben.
Thema: Threads erzeugen
public class GamePanel ... Runnable{
	...
	public void ??? (){ 
		// hier läuft der Thread
		...
	}
	...
	
	public void init(){
		Thread t= new Thread(???);
		t.start();
	}
}
</fragentext>
<loesungstext>run,this</loesungstext>
<punkte>20</punkte>
</frage>

<frage>
<fragentext>
BEISPIEL: WAHR od. FALSCH Frage: 
wahr bzw. falsch eingeben: 
Java unterstützt Mehrfachevererbung
</fragentext>
<loesungstext>falsch</loesungstext>
<punkte>10</punkte>
</frage>


</fragen>
~~~



## 3. ADV3 with player.xml
---
1. In File **world.txt** replace 
~~~
<name> Priska
<gesundheit> 300 
<waffe> Geschicklichkeit
<schaden> 10
~~~
with
~~~
<player> player.xml
~~~

2. create file **player.xml**
~~~
<?xml version="1.0" encoding="UTF-8"?>
<player>
<name>Maxi Mustermann</name>
<gesundheit>300</gesundheit> 
<waffe>Geschicklichkeit</waffe>
<schaden>10</schaden>
</player>
~~~

3. **change ADV3 to use the new configuration with xml**
	* Die Zeile `<player> player.xml` kann in einer beliebigen Zeile in der Datei world.txt sein.
	* Der Name der XML-Datei muss nicht unbedingt player.xml sein, d.h. Sie müssen erst den Namen der XML Datei aus der world.txt lesen, um die Spieler-Daten dann aus der entsprechenden XML-Datei zu lesen.
	* Auch die Zeile `<Start> Eingang` kann in einer beliebigen Zeile in der Datei world.txt sein.

4. **Den Prompt aendern**
	* der bestehende Prompt *Raumname:>* soll geändert werden zu *Playername-gesundheit@Raumname:>* (zB: Maxi Mustermann-300@Eingang:>)

Hinweis zum Einlesen:
~~~
#include <sstream>

string strLine, strWord;
getline(fin, strLine, '\n'); // liest eine Zeile
istringstream istr(strLine);
getline(istr, strWord, ' '); // liest 1. Wort von der zuvor gelesenen Zeile
istr>>strWord; // liest das 2. Wort von der zuvor gelesenen Zeile
~~~
