ARBEITEN MIT MSACCESS
======================

Leere DB anlegen: 
	ahofmann.mdb
Tabelle erzeugen: 
	ger�te (gnum, ...
	Prim�rschl�ssel
	Dateneingeben
Zweite tabelle: 
	service (snum)
	Dateneingeben
Verkn�pfung der tabellen
	Tabelle geraete Fremdschl�ssel (ger�te.snum) hinzuf�gen

Abfrage erstellen: ger�teservice (ger.name, ser.firma, ser.tel) ger�teliste mit servicetelefonnummer)
	Verkn�pfungseigenschaften
	sql-Ansicht

Abfrage mit Bedingung
	Neue Tabelle: reparatur (datum,kosten,grund, snum,gnum)
	Neue Abfrage: (datum,ger.name,ser.firma,ser.auftragswert) reparaturen�bersicht

Formular
	1.formular: ger�teliste bedienen  (formularassistent)
		keine schl�sselfelder ins formular


	Auswahlfeld einbauen
		Formular in Entwurfsansicht
		nach Verantwortlicher Platz schaffen
		Kominationsfeld hinzugeben
		Daten aus anderer Tabelle: service (snum, Firma)
			Wert speichern in Feld Snum

	Versch�nern
		Formular/Entwurfsansicht
		Fenstertitel mit re. Maus

AUFGABE:
--------
	Weitere Formulare f�r alle Tabellen (Service, Reparatur)


Bericht 
	Assistent
	Abfrage: Reparatur�bersicht

	Bericht mit einer Berechnung erg�nzen
		Entwurf
		Textfeld am Berichtsende 
		re. Maus-Eigenschaften 
		"=Summe(Auftragswert)"

	versch�nern
			
Men�(ist eigentlich ein formular)
	Formular (entwurfsansicht �ffnen)
	Button (formular �ffnen)
		Ger�teverwaltung

AUFGABE:
--------
	Jedem Formular sein Button (geraete, Service, Reparatur, reparaturBericht, Ende)

	Men�gestaltung (eigenschaftenfenster)

	Ende Button (Anwendung-Anwendung beenden)

AUFGABE:
--------
	Jedes Formular braucht einen ENDE-Button
		
	
Startmakro
	�ffnen des Hauptmen�s
	Makro neu
	�ffnen Formular
	MakroName: AutoExec


Verpacken
	Vorher sichern (mdb in unterverzeichnis kopieren)
	Extras->Start
		checkboxes uncheck all
	tipp: shift-taste dr�cken und *.mdb �ffnen
	
Absichern
	DB �ffnen im exklusiv-modus

	extras, sicherheit, passwort vergeben



Arbeitsblatt:
------------
is_uni
Prof verwalten
Assistenten verwalten
Vorlesungen verwalten
Studenten verwalten
------------------
Inskription
Pr�fung
------------------
H�rerliste
Notenlisten	