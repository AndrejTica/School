// doubleStack.h

void init(void);
	// l�scht d. Stack,d.h. stackpointer auf 0 setzen

void push(double value)      ;
	// legt value auf den Stack,
	// wenn dieser aber bereits voll ist, wird auf 
	// stderr Stack voll geschrieben und 
	// der Wert nicht auf den Stack gelegt.
double  pop(void);
	// gibt den obersten Wert des Stack zur�ck,
	// wenn dieser aber bereits leer ist, 
	// wird auf stderr
	// Stack leer geschrieben.
