// A.hofmann
// Taschenrechner   : umgekehrte polnische Notation
// testprogramm     : test_taschenrechner.c
// verwendete Module: doubleStack.c, doubleStack.h

#include <stdio.h>
#include <ctype.h>		// wegen isdigit()
#include <stdlib.h>		// wegen atof()

#include "????????????????.h"

#define IL_MAX   20
#define END_CHAR '='

char getline(char str[], int len){
	// ---------------------------------------------------------------
	// input     : char-Vektor , laenge des char-Vektors
	// output    : wenn eine zahl eingegeben wurde -> '0'
	//             wenn ein operator (+,-,...)     -> der jeweilige operator
	scanf ("%s", str);
	if (isdigit(str[0]))
		return('0');
	else
		return(str[0]);
}

	// ---------------------------------------------------------------------------
int  main(){
   double  op2;			// operand zum zwischenspeichern
   char input_line[IL_MAX]; 	//Eingabe
   char ch; 			//return wert v. getline()

   // --------- initialisiert den Stack
   init();

   printf("\nTaschenrechner: Geben Sie Zahlen in umgekehrter polnischer Notation ein.\n");
   printf("\npostfix: 12 2 * 4 + 2 / = \ndies entspricht: (12 * 2 + 4) / 2   Ergebnis=14.00\n\n");
   do {
      ch=getline(input_line,IL_MAX);

      switch(ch){
         case '+':
            push(pop()+pop());
            break;
         case '-':
         	???????????????
            break;
         case '*':
         	???????????????
            break;
         case '/':
            op2 = pop();
            if (op2 == 0){
               		fprintf(stderr,"\nDivision durch 0 nicht definiert!\n");
               		pop(); 	// zweiten operanden v. stack, d.h. / wurde nicht ausgefhrt
            }
            else
	         	???????????????
            break;
         case '0':
            push(atof(input_line));
            break;
         case END_CHAR:
            printf("\nErgebnis = %.2lf \n\n",pop());
            break;
         }
      } while (input_line[0]!=END_CHAR);
} /* main() */
