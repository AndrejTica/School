// company.cpp
// hofmann, 2015

#include "company.h"

#include <iostream>
#include <sstream>
using namespace std;

Company::Company (string name){
	this->name= name;
}

void Company::addEmployee(Person* p){
	employee.push_back(p);
}


void Company::removeEmployee(int age){
	vector<Person*>::iterator   it;
	
	for(it= employee.begin() ; it!= employee.end() ; it++){
		if ( (*it)->getAge() == age ){
			employee.erase(it);
			return;
		}
	}
}

double Company::getPayroll() const{
	double total=0.0;
	vector<Person*>::const_iterator   it;
	
	for(it= employee.begin() ; it!= employee.end() ; it++){
		total += (*it)->getWage();
	}
	
	return total;
}



string Company::toString() const{
	vector<Person*>::const_iterator   it;
	ostringstream o;
	
	o << "COMPANY: " << name << endl;
	for(it= employee.begin() ; it!= employee.end() ; it++){
		o << (*it)->toString() << endl;
	}
	
	return o.str();
}


