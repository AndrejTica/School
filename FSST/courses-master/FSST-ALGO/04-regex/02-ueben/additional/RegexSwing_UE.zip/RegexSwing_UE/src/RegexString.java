import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RegexString {

	String muster,text;
	Boolean tipp;
	
	Pattern p;
	Matcher m;
	Boolean matches;


	public RegexString(String m, String t, String t_f) {
		muster=m;
		text=t;
		if (t_f.equalsIgnoreCase("t") ||t_f.equalsIgnoreCase("true"))
			tipp=true;
		else 
			tipp=false;

		this.p= Pattern.compile(muster);
		this.m= p.matcher(text);
		
		this.matches= this.m.matches(); 

	}
	
	String getMuster(){
		return muster;
	}
	
	String getText(){
		return text;
	}
	
	void setTipp(Boolean v){
		tipp= v;
	}
	
	
	Boolean getMatch(){
		return matches;
	}
	
	String getFind(){
		String s="";
		
		while ( m.find() ) {
			s+= m.group() + " [" + m.start() + "," + m.end()+"]" +"\n";
		}
		
		return s;
		
	}

	
	String getReplaceAll(String replacement){
		
		return text.replaceAll(muster, replacement);
		
	}
		
}
