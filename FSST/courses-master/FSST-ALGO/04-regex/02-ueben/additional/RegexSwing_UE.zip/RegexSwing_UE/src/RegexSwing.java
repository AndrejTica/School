import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.border.EtchedBorder;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.JScrollPane;


public class RegexSwing extends JFrame {

	private JPanel contentPane;
	private JLabel labelNOK;
	private JLabel labelOK;
	private JTextPane textPaneMuster;
	private JTextPane textPaneString;
	private JTextArea textArea;
	private JButton btnMatch;
	private JButton btnFind;
	private JButton btnReplace;
	private JButton btnRichtig;
	private JButton btnFalsch;
	private JPanel panelProbe;
	private JPanel panelTipp;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	Vector<RegexString> vRegexString;
	Vector<Boolean> vRegexStringTipp;
	int iMuster=0;
	private JButton button;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private JScrollPane scrollPane_2;


	void showFrage(){
		textPaneMuster.setText(vRegexString.get(iMuster).getMuster());
		textPaneString.setText(vRegexString.get(iMuster).getText());
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegexSwing frame = new RegexSwing();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegexSwing() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent arg0) {
				// datei regex.csv einlesen

				vRegexString= new Vector<RegexString>();
				vRegexStringTipp= new Vector<Boolean>();


				try {
					BufferedReader fin= new BufferedReader(new InputStreamReader(new FileInputStream("regex.csv")));
					String line;

					while ((line=fin.readLine()) != null){
						//System.out.println(line);
						String[] h= line.split(";");

						vRegexString.add(new RegexString(h[0], h[1], h[2]));


					}

					fin.close();


					showFrage();

					System.out.println(vRegexString);


				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}




			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 588, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getScrollPane());
		contentPane.add(getScrollPane_1());
		contentPane.add(getScrollPane_2());
		contentPane.add(getPanelProbe());
		contentPane.add(getPanelTipp());
	}

	private JLabel getLabelNOK() {
		if (labelNOK == null) {
			labelNOK = new JLabel("0");
			labelNOK.setSize(new Dimension(50, 50));
			labelNOK.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "falsche Antworten", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			labelNOK.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
			labelNOK.setForeground(Color.RED);
		}
		return labelNOK;
	}
	private JLabel getLabelOK() {
		if (labelOK == null) {
			labelOK = new JLabel("0");
			labelOK.setSize(new Dimension(50, 50));
			labelOK.setPreferredSize(new Dimension(16, 16));
			labelOK.setMinimumSize(new Dimension(16, 16));
			labelOK.setHorizontalAlignment(SwingConstants.RIGHT);
			labelOK.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "richtige Antworten", TitledBorder.RIGHT, TitledBorder.TOP, null, new Color(0, 0, 0)));
			labelOK.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
			labelOK.setForeground(Color.GREEN);
		}
		return labelOK;
	}
	private JTextPane getTextPaneMuster() {
		if (textPaneMuster == null) {
			textPaneMuster = new JTextPane();
			textPaneMuster.setBackground(new Color(255, 0, 0));
			textPaneMuster.setBorder(new TitledBorder(null, "MUSTER/Pattern", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		}
		return textPaneMuster;
	}
	private JTextPane getTextPaneString() {
		if (textPaneString == null) {
			textPaneString = new JTextPane();
			textPaneString.setBackground(new Color(255, 255, 0));
			textPaneString.setBorder(new TitledBorder(null, "String/Text", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		}
		return textPaneString;
	}
	private JTextArea getTextArea() {
		if (textArea == null) {
			textArea = new JTextArea();
		}
		return textArea;
	}
	private JButton getBtnMatch() {
		if (btnMatch == null) {
			btnMatch = new JButton("match");
			btnMatch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					// REGEX
					????????? p= ??????.?????????(textPaneMuster.getText());
					Matcher m= ????????.???????(textPaneString.getText());

					textArea.setText(String.valueOf(m.????????()));
				}
			});
		}
		return btnMatch;
	}
	private JButton getBtnFind() {
		if (btnFind == null) {
			btnFind = new JButton("find");
			btnFind.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					// REGEX
					Pattern p= ??????????.????????(textPaneMuster.getText());
					?????????? m= ??????.??????????(textPaneString.getText());

					String s="";

					while ( m.??????????? ) {
						s+= m.????????????() + " [" + m.???????() + "," + m.?????()+"]" +"\n";
					}
					
					textArea.setText(s);
					
				}
			});
		}
		return btnFind;
	}
	private JButton getBtnReplace() {
		if (btnReplace == null) {
			btnReplace = new JButton("replace");
		}
		return btnReplace;
	}
	private JButton getBtnRichtig() {
		if (btnRichtig == null) {
			btnRichtig = new JButton("match");

			btnRichtig.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					vRegexString.get(iMuster).setTipp(true);

					RegexString rs= vRegexString.get(iMuster);
					if (rs.matches == true)
						labelOK.setText(String.valueOf(Integer.parseInt(labelOK.getText()) + 1));
					else
						labelNOK.setText(String.valueOf(Integer.parseInt(labelNOK.getText()) + 1));

					iMuster++;
					if (iMuster == vRegexString.size()){
						// zu Ende
						JOptionPane.showConfirmDialog(null, "ENDE");
						//System.exit(0);
						iMuster=0;
					}

					showFrage();


				}
			});





		}
		return btnRichtig;
	}
	private JButton getBtnFalsch() {
		if (btnFalsch == null) {
			btnFalsch = new JButton("NO match");

			btnFalsch.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					vRegexString.get(iMuster).setTipp(false);

					RegexString rs= vRegexString.get(iMuster);
					if (rs.matches == false)
						labelOK.setText(String.valueOf(Integer.parseInt(labelOK.getText()) + 1));
					else
						labelNOK.setText(String.valueOf(Integer.parseInt(labelNOK.getText()) + 1));

					iMuster++;
					if (iMuster == vRegexString.size()){
						// zu Ende
						JOptionPane.showConfirmDialog(null, "ENDE");
						//System.exit(0);
						iMuster=0;
					}

					showFrage();


				}
			});

		}
		return btnFalsch;
	}
	private JPanel getPanelProbe() {
		if (panelProbe == null) {
			panelProbe = new JPanel();
			panelProbe.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "ich weiss es nicht", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			panelProbe.setBounds(6, 413, 141, 151);
			panelProbe.add(getBtnReplace());
			panelProbe.add(getBtnFind());
			panelProbe.add(getBtnMatch());
		}
		return panelProbe;
	}
	private JPanel getPanelTipp() {
		if (panelTipp == null) {
			panelTipp = new JPanel();
			panelTipp.setBorder(new TitledBorder(null, "ich weiss es", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelTipp.setBounds(6, 236, 577, 166);
			panelTipp.setLayout(new GridLayout(0, 2, 0, 0));
			panelTipp.add(getBtnFalsch());
			panelTipp.add(getBtnRichtig());
			panelTipp.add(getLabelNOK());
			panelTipp.add(getLabelOK());
		}
		return panelTipp;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(6, 109, 577, 115);
			scrollPane.setViewportView(getTextPaneString());
		}
		return scrollPane;
	}
	private JScrollPane getScrollPane_1() {
		if (scrollPane_1 == null) {
			scrollPane_1 = new JScrollPane();
			scrollPane_1.setBounds(6, 6, 577, 91);
			scrollPane_1.setViewportView(getTextPaneMuster());
		}
		return scrollPane_1;
	}
	private JScrollPane getScrollPane_2() {
		if (scrollPane_2 == null) {
			scrollPane_2 = new JScrollPane();
			scrollPane_2.setBounds(159, 414, 413, 151);
			scrollPane_2.setViewportView(getTextArea());
		}
		return scrollPane_2;
	}
}
