#!/bin/bash
echo ""
echo "*** script-01.sh ***"
echo ""
date
cal
pwd
ls
ls -l
echo "hello, world"
echo $SHELL
echo $USER
