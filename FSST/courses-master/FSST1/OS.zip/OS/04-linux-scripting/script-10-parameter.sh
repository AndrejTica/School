#!/bin/bash
echo ""
echo "*** script-10-parameter.sh ***"
echo ""

echo $1 $2 $4
echo $#
echo $*
