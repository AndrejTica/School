/* 1. Beispiel: flaeche
	Lies laenge und breite ein und gib die Fläche aus.
*/
int main(){}