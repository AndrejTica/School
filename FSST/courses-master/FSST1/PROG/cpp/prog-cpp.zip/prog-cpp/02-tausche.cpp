/* 2. Beispiel: tausche
	Lies n und m ein und tausche deren Inhalt. Gib n und m aus.
*/
