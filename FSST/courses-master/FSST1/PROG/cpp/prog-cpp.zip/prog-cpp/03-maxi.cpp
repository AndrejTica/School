/* 3. Beispiel: maxi
	Lies 2 Zahlen ein (x, y) und gib die grössere Zahl aus.
*/
