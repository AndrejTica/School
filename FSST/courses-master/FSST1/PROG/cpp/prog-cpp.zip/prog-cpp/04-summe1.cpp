/* 4. Beispiel: summe1
	Lies n ein und gib die Summe der Zahlen von 1 bis n aus
*/
