/* 5. Beispiel: summe2
	Lies 2 Zahlen ein (start,ende).
	Berechne die Summe der Zahlen von start bis ende.

	Bsp: 
	start: 2 ende: 4
	=> ergebnis: 9
*/
