/* 6. Beispiel: pow
	Lies x und y ein. 
	Berechne/gib x hoch y aus.
*/
