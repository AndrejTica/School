/* 7. Beispiel: teiler1
	Lies n ein und gib alle Teiler von n aus.
	Hinweis: n%2 ….liefert 0 wenn n durch 2 teilbar ist
	Hinweis: Zum Vergleichen verwende ==
*/
