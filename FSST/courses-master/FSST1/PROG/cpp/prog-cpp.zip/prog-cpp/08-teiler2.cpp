/* 8. Beispiel: teiler2
	Lies 2 Zahlen ein (start,ende).
	Gib von jeder Zahl zwischen start und ende die Teiler aus.

	Bsp: start:3 ende:5
	Teiler von 3
	Teiler: 1
	Teiler: 3
	Teiler von 4
	Teiler: 1
	Teiler: 2
	Teiler: 4
	Teiler von 5
	Teiler: 1
	Teiler: 5
*/
