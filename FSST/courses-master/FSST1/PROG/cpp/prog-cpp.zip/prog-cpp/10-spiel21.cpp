/* 10. Beispiel: Spiel21
	Es liegen 21 Hölzer am Tisch. 
	2 Spieler nehmen abwechselnd zwischen 1 und 4  Hölzer.
	Der Spieler, welcher zuletzt Hölzer nimmt, hat verloren!!!!

	Erstellen Sie ein Struktogramm und Programm. 
	Der Computer verwaltet die Anzahl der Hölzer und fragt abwechselnd die 
	beiden Spieler (Spieler1 und Spieler2) .
*/
