/* 11. Primfaktorzerlegung

Beispiel für eine Ausgabe zu n = 100: 
        100 = 2 * 2 * 5 * 5 . 

Hinweis: Teste die Teiler d = 2, 3, ... 
         wenn d ein Teiler von n ist, dann: n= n / d   (mit n > 1)
         sonst: nimm den nächsten Teiler
*/
