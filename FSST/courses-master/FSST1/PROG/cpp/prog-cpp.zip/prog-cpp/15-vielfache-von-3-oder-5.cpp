/* +15. Beispiel: Vielfache von 3 oder 5
Berechne die Summe der Zahlen zwischen 1 und 10 (exkl.), die
Vielfache von 3 oder 5 sind.

Beispiel: zahl=10
Die Vielfachen von 3 oder 5 sind: 3,6,9,5
Die Summe ist 23

Aufgabe: Lies Zahl ein und berechne nach der obigen Angabe 
die Summe der Vielfachen von 3 und 5.
*/
