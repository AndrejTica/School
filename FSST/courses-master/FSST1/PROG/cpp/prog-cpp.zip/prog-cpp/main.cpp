#include <iostream>
using namespace std;

int main() {
  cout << "1. read 00-readme-struktogramme-pseudocode.pdf\n";
  cout << "2. prog examples in 00-readme-prog-cpp-aufgaben-basic.txt\n";
  cout << "3. use referenz-cpp.txt\n";
  
  return 0;
}
