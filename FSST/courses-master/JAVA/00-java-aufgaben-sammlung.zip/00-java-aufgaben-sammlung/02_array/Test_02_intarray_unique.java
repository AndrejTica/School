package main;

public class Test_02_intarray_unique {

	public static void main(String[] args) {
		/**
		 * 1. write random values (0-99) into an int-array with 10 elements
		 * 2. display the array
		 * 3. check if all array elements are unique (eindeutig)
		 * 4. output: array is unique or
		 * 4. output: array is not unique
		 * 
		 * 
		 * Bsp:
		 * 0,1,2,3,4,5,6,7,8,9   
		 * array is unique
		 * 
		 * 0,1,1,3,4,5,6,7,8,9
		 * array is not unique
		 * 
		 */

		// ENTER CODE

	}
}
