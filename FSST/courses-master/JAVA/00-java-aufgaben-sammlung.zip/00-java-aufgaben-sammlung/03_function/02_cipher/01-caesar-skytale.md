# mab-cipher

1. create java project: 03-JAVA-CIPHER
2. create package: cipher
3. in package cipher create class: Cipher
4. copy cotent of cipher/Cipher.java in your new class Cipher
5. create package: test
6. in package test create: JUNIT TEST CASE with name Test_cipher
7. copy cotent of test/Test_cipher.java in your new JUNIT TEST CASE.

## happy coding
