/*
Aufgabe: 2-dim intArray: sum_per_row
=====================================
1. definieren Sie ein 2 dim-integer Array namens matrix mit 5 Zeilen und je 6 Spalten.
2. Schreiben Sie Zufallszahlen in das Array arr. (Werteberich  der Zufallszahlen: 0-99 inkl.)
3. Geben Sie das Array matrix aus. 
4. Berechnen Sie die Summe der einzelnen Zeilen und speichern Sie diese Summen in einem 
   1-dim integer-Array namens sum_per_row.
5. Geben Sie das Array sum_per_row aus.
6. Ermitteln Sie den index_max im Array sum_per_row, der die Position des größten Wertes im Array
   speichert.
7. Geben Sie den index_max und den maximalen Wert im Array also sum_per_row[index_max] aus.
*/
package main;
package main;

public class Test_07_matrix_sum_per_row {

	public static void main(String[] args) {
	
	 // ENTER CODE
	 
	 
	}
}
