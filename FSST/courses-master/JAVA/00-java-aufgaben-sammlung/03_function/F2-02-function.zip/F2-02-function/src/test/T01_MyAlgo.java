package test;

import ___________________________;

public class T01_MyAlgo {

	public static void main(String[] args) {
		int[] arr= new int[10];
		int mini_index;
		int suche_index;
		
		MyAlgo.logo("Max Mustermann");
		
		
		System.out.println("... mischen() aufrufen ...");
		// --------------------------------------------------------------		
		MyAlgo.mischen(_______________);

		
		
		System.out.println("... display() aufrufen ...");
		// --------------------------------------------------------------		
		
		__________________________

		
		
		
		System.out.println("... getMin_idx() aufrufen ...");
		// --------------------------------------------------------------		

		mini_index= ________________________
		System.out.println("... Der kleinste Wert ist: " + ______________);
		

		
		
		System.out.println("... suche() aufrufen ...");
		// --------------------------------------------------------------		
		
		suche_index= suche(50, ____________);
		
		if (_________________) {
			System.out.println("... 50 gefunden!");
		}else {
			System.out.println("... 50 nicht gefunden!");
		}
		
		
		
		
		System.out.println("... sortiere() aufrufen ...");
		// --------------------------------------------------------------		
		MyAlgo.sortiere(arr);
		MyAlgo.display(arr);
		
		
		
		System.out.println("... printPrimes() aufrufen ...");
		// --------------------------------------------------------------		
		
		_____________________________
		
		
		
		System.out.println("... isLeapYear() aufrufen ...");
		// --------------------------------------------------------------		
		
		MyAlgo.isLeapYear(2020);
		
				
	}

}
