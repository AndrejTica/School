package test;

import oop.*;

public class TestADDSubstitution {
	
		public static void main(String[] args) {
			String plainText;
			int key;

			plainText = "Hello World!";
			key= 23;

			Cipher cipher = new ADDSubstitution();
			String cryptText = cipher.encrypt(plainText, key);


			// Die Bytes des verschlüsselten Textes werden auf der Konsole 
			// gezeigt. 
			// In der Regel kann dieser String nicht lesbar ausgegeben werden, 
			// weil bei der Verschlüsselung nichtdruckbare Zeichen entstehen.
			System.out.print( "[ ");
			for (int i=0; i< cryptText.length() -1; i++){
				System.out.print("" + (int) cryptText.charAt(i) + ",") ;
			}

			System.out.print("" + (int) cryptText.charAt(cryptText.length()-1) + ",") ;
			System.out.print( " ]");


			// Schließlich wird der Geheimtext wieder dechiffriert und zur 
			// Kontrolle mit dem ursprünglichen Klartext verglichen. 
			// Die Ausgabe müsste true lauten:

			String decoded = cipher.decrypt(cryptText, key);

			if (plainText.equals(decoded) )
				System.out.println("true");
			else
				System.out.println("false");
		}

		/*	
		Ausgabe: plainText= "Hello, world!"    key=23
			[95, 114, 123, 123, 120, 59, 55, 96, 120, 101, 123, 115, 54]
			true
		 */
	}
