package test;
import oop.*;

public class TestDiffie_Hellman{

	public static void main(String[] args){

		System.out.println("*** DIFFIE-HELLMAN *** ");
		int n=5;
		int g=23;


	 // Anschließend erzeugt das Programm zwei DHCipher-Objekte alice und bob, die
	 // mit den Daten initialisiert werden, die vom Trustcenter stammen würden:
	 
	 DHCipher alice = new DHCipher(n, g);
	 DHCipher bob = new DHCipher(n, g);


	 // Bobs öffentlicher Schlüssel wird an Alice übergeben, die damit den Klartext zu
	 // cryptText verschlüsselt:

	 cryptText = alice.encrypt(plainText, bob.getPublicKey());

	 System.out.print("[ ");;
	 for (int i=0; i< cryptText.length() -1; i++){
		  System.out.print((int) cryptText.charAt(i)  + ",") ;
	 }
	 System.out.print((int) cryptText.charAt(cryptText.length() -1));
	 System.out.println(" ]");


	 // Bob entschlüsselt cryptText mithilfe von Alices öffentlichem Schlüssel. Schließlich
	 // wird verifiziert, dass die ursprüngliche Nachricht korrekt zurückgewonnen wurde:

	 decoded = bob.decrypt(cryptText, alice.getPublicKey());

	 if (plainText.equals(decoded))
		  cout << "true" <<endl;
	 else
		  cout << "false" <<endl;

	 }
}

/*
Das Testprogramm gibt je nach zufällig gewählten Schlüsseln verschiedene Zahlenfolgen
aus, beispielsweise:

[50, -36, -105, -65, -60, -126, -78, -79, 76, -62, -72, -111, 42]
true
*/
