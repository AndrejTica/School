package test;
import oop.*;

public class TestStreamCipher {
	public static void main(String[] args) {
		String plainText;
		int key;

		plainText = "Hello World!";
		key= 23;

		Cipher cipher = new StreamCipher();
		String cryptText = cipher.encrypt(plainText, key);


		// Die Bytes des verschlüsselten Textes werden auf der Konsole 
		// gezeigt. 
		// In der Regel kann dieser String nicht lesbar ausgegeben werden, 
		// weil bei der Verschlüsselung nichtdruckbare Zeichen entstehen.
		System.out.print( "[ ");
		for (int i=0; i< cryptText.length() -1; i++){
			System.out.print("" + (int) cryptText.charAt(i) + ",") ;
		}

		System.out.print("" + (int) cryptText.charAt(cryptText.length()-1) + ",") ;
		System.out.print( " ]");


		// Schließlich wird der Geheimtext wieder dechiffriert und zur 
		// Kontrolle mit dem ursprünglichen Klartext verglichen. 
		// Die Ausgabe müsste true lauten:

		String decoded = cipher.decrypt(cryptText, key);

		if (plainText.equals(decoded) )
			System.out.println("true");
		else
			System.out.println("false");
	}

	/*	
			Ausgabe: plainText= "Hello, world!"    key=23
				[47, 124, 106, -109, -54, -37, 68, -101, -28, -60, -31, 74, 82]
				true
	 */
}
