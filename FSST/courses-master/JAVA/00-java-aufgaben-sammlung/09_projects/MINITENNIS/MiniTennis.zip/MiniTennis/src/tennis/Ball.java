package tennis;

import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Ball {
	private static final int _diameter = 30;
	private int _x = 0;
	private int _y = 0;
	private int _xa = 1;
	private int _ya = 1;
	private Game _game;

	public Ball(Game game) {
		_game= game;
	}

	void move() {
		boolean changeDirection = true;
		if (_x + _xa < 0)
			_xa = _game.speed;
		else if (_x + _xa > _game.getWidth() - _diameter)
			_xa = -_game.speed;
		else if (_y + _ya < 0)
			_ya = _game.speed;
		else if (_y + _ya > _game.getHeight() - _diameter)
			_game.gameOver();
		else if (collision()){
			_ya = -_game.speed;
			_y = _game.racquet.getTopY() - _diameter;
			_game.speed++;
		} else 
			changeDirection = false;
		
		if (changeDirection) 
			Sound.BALL.play();
		_x = _x + _xa;
		_y = _y + _ya;
	}

	private boolean collision() {
		return _game.racquet.getBounds().intersects(getBounds());
	}

	public void paint(Graphics2D g) {
		g.fillOval(_x, _y, _diameter, _diameter);
	}
	
	public Rectangle getBounds() {
		return new Rectangle(_x, _y, _diameter, _diameter);
	}
}