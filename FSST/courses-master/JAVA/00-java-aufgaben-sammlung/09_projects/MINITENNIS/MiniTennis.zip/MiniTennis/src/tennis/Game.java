/*
 * Johannes Schatteiner, 3AHEL
 * MiniTennis
 * 2016
 */

package tennis;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class Game extends JPanel {

	// Timer
	private Timer gameTimer;
	private double seconds = 0;
	String stringSeconds;
	
	Ball ball = new Ball(this);
	Racquet racquet = new Racquet(this);
	int speed = 1;

	private int getScore() {
		return speed - 1;
	}

	public Game() {
		addKeyListener(new KeyListener() {		//keylisteners for raquet
			@Override
			public void keyTyped(KeyEvent e) {
			}
			@Override
			public void keyPressed(KeyEvent e) {
				racquet.keyPressed(e);
			}
			@Override
			public void keyReleased(KeyEvent e) {
				racquet.keyReleased(e);
			}
		});
		setFocusable(true);
		Sound.BACK.loop();		//loop the sound playing while the game is running
		
		//game Timer does not count correct amount of time played
		gameTimer = new Timer(20, new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// display seconds
				seconds += 0.02;
				stringSeconds = String.format("%.2f", seconds);
				System.out.println(stringSeconds);
			}
		});

		gameTimer.start();
	}
	
	private void move() {
		ball.move();
		racquet.move();
	}

	@Override
	public void paint(Graphics g) {	
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		//paint the ball & racquet
		ball.paint(g2d);
		racquet.paint(g2d);	

		//paint the score
		g2d.setColor(Color.GRAY);
		g2d.setFont(new Font("Verdana", Font.BOLD, 30));
		g2d.drawString(String.valueOf(getScore()), 10, 30);
	}
	
	public void gameOver() {
		Sound.BACK.stop();
		Sound.GAMEOVER.play();
		JOptionPane.showMessageDialog(this, "Game Over" + "\n" + "You survived for " + stringSeconds + " seconds!", "Game Over", JOptionPane.YES_NO_OPTION);
		System.exit(ABORT);
	}

	public static void main(String[] args) throws InterruptedException {
		JFrame frame = new JFrame("Schattis Tennis, 2016");
		Game game = new Game();
		frame.add(game);
		frame.setSize(300, 400);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		while (true) {			//gameloop
			game.move();
			game.repaint();
			Thread.sleep(10);	//allows the game to process other threads
		}
	}
}