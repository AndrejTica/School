package tennis;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

public class Racquet {
	private static final int _y = 330;
	private static final int _width = 60;
	private static final int _height = 10;
	private int _x = 0;
	private int _xa = 0;
	private Game _game;

	public Racquet(Game game) {
		_game= game;
	}

	public void move() {
		if (_x + _xa > 0 && _x + _xa < _game.getWidth() - _width)
			_x += _xa;
	}

	public void paint(Graphics2D g) {
		g.fillRect(_x, _y, _width, _height);
	}

	public void keyReleased(KeyEvent e) {
		_xa = 0;
	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT){
			_xa = -_game.speed;
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT){
			_xa = _game.speed;
		}
	}
	
	public Rectangle getBounds() {
		return new Rectangle(_x, _y, _width, _height);
	}

	public int getTopY() {
		return _y - _height;
	}
}