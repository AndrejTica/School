# Ein Testmodul für das Spiel

- sqlite Datenbank verwenden

---

## Ablauf

1. Beim Start folg. eingeben
   - Spieler: ahofmann
   - Fragen_db: fragen-spiel-bauer.db

2. wenn der Helicopter getroffen wird
   - (nächste) Frage stellen
   - Antwort/Punkte speichern (bei falscher Antwort-> 0 Punkte)

3. wenn die Frage richtig beantwortet ist
   - weiterspielen

4. wenn die Frage falsch beantwortet ist
   - Spiel beenden
   - Spielbericht/Log erstellen

5. wenn alle Fragen richtig beantwortet sind
   - Spielbericht/Log erstellen

---

## Arten von Fragestellungen

- Single choice
- Multiple choice
- Single Lücke
- Multiple Lücke
- Wahr oder falsch

---

## Die Datenbank erstellen

- installieren Sie: sqlitebrowser
- Erstellen Sie
  - die Datenbank: fragen.db
  - die Tabelle: fragen

~~~ sql
CREATE TABLE "fragen" ( 
	"id" INTEGER, 
	"fragentext" TEXT NOT NULL, 
	"loesungstext" TEXT NOT NULL, 
	"punkte" INTEGER NOT NULL, 
	
	PRIMARY KEY("id" AUTOINCREMENT) 
	)
~~~

---

## Die Fragen in die Datenbank einspielen

~~~ sql
INSERT INTO "fragen" (fragentext,loesungstext,punkte) 
VALUES
("BEISPIEL: SINGLE-CHOICE-Frage
Objekte, die nicht mehr benötigt werden, müssen gelöscht
werden. Dazu wird eine boolsche Variable remove verwendet. 
In welcher Klasse wird Sie definiert?
a) Sprite b) Rocket c) GamePanel d) Explosion"
,"a",10),

("BEISPIEL: SINGLE-CHOICE-Frage
Das tatsächliche Löschen der Objekte erfolgt in
a) GamePanel.doLogic() b) Rocket.doLogic"
,"a",10),

("BEISPIEL: MULTIPLE-CHOICE: mit , trennen
Von Ihnen programmierte Klassen im Spiel:
a) GamePanel b) Rocket c) Image d) Movable"
,"a,b"
,20),

("BEISPIEL: SINGLE-LÜCKEN-Frage: 
Was gehört statt ??? geschrieben.
public class GamePanel extends JPanel ??? Runnable{...}"
,"implements",10),

("BEISPIEL: MULTIPLE_LÜCKEN-Frage: Antworten mit , trennen
Was gehört statt ??? geschrieben.
Thema: Threads erzeugen
public class GamePanel ... Runnable{
	...
	public void ??? (){ 
		// hier läuft der Thread
		...
	}
	...
	
	public void init(){
		Thread t= new Thread(???);
		t.start();
	}
}"
,"run,this",20),

("BEISPIEL: WAHR od. FALSCH Frage: 
wahr bzw. falsch eingeben: 
Java unterstützt Mehrfachevererbung"
,"falsch",10)
~~~

---

## Aufbau der Log-Datei

Die Log-Datei wird erzeugt,

- wenn alle Fragen beantwortet wurden oder
- wenn eine Frage falsch beantwortet wurde.

Aufbau des Log-Dateinamen:

- fragendateiname_ergebnis_name_datum_.txt

Inhalt der Log_Datei

  - NAME:
  - DATUM-start:
  - DATUM-end:
  - DAUER:
  - FRAGEN-DB:
  - Mögliche Gesamt-Punkte:
  - Erreichte Punkte:  .... (Prozentanteil)
  - Log: .... alle beantworteten Fragen und Antworten und Punkte

---

## Beispiel der Log-Datei

Dateiname:

- fragen-spiel-bauer.db_ergebnis_ahofmann_2020-12-24-08:02.txt

Inhalt:

~~~ bash
NAME: ahofmann
DATUM-start: 2020-12-24-08:02
DATUM-end: 2020-12-24-08:12
DAUER: 10sec
FRAGEN-DB: fragen-spiel-bauer.db
Mögliche Gesamt PUNKTE: 80
Erreichte PUNKTE: 20 (25.0 %)

---- LOG BEGIN ----

FRAGE:======================================================
BEISPIEL: SINGLE-CHOICE-Frage
Objekte, die nicht mehr benötigt werden, müssen gelöscht
werden. Dazu wird eine boolsche Variable remove verwendet. 
In welcher Klasse wird Sie definiert?
a) Sprite b) Rocket c) GamePanel d) Explosion
LÖSUNG: a
ANTWORT: a
PUNKTE: 10

FRAGE:======================================================
BEISPIEL: SINGLE-CHOICE-Frage
Das tatsächliche Löschen der Objekte erfolgt in
a) GamePanel.doLogic() b) Rocket.doLogic
LÖSUNG: a
ANTWORT: a
PUNKTE: 10

...


FRAGE:======================================================
Das tatsächliche Löschen der Objekte erfolgt in
a)GamePanel.doLogic() b) Rocket.doLogic
LÖSUNG: a
ANTWORT: b
PUNKTE: 0

---- LOG END ----
~~~
