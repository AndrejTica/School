# Klassen und Objekte

## 1. Klassen sind Datentypen

Der Programierer/in soll neben den primitiven Datentypen (int, float, char, ...) 
auch selbst Datentypen erzeugen können.

So könnte man sich im Bereich der

- Autoindustrie folgende Datentypen vorstellen:
  - Auto, Rad, Zylinder, Fahrgestell, ...
- Schule:
  - Schueler, Lehrer, Unterrichtsfach, ...
- Spiele:
  - Spieler, Held, Gegner, Zaubertrank, Hindernis

Objektorientierte Programmiersprachen erlauben das Definieren neuer Datentypen. Diese werden **Klassen** genannt.

> KLASSEN sind Datentypen (zB: Auto, Pflanze, Spieler)

Merke:
> Klassennamen
> - beginnen mit einem Großbuchstaben
> - sind meist in einer eigenen Datei: (Pflanze.java)

Die neuen Datentypen/Klassen haben auch ihre eigenen Operatoren/Funktionen

> KLASSE = DATEN + FUNKTIONEN (werden METHODEN genannt)

Zum Beispiel kann man:

- Schueler prüfen oder sie zu einer Schülerliste hinzufügen.
- bei der Klasse Date den Wochentag, den MonatsNamen , .... ermitteln.
- Complex addieren, ...

> Klassen sind wie ein Bauplan.

## 2. Objekte sind Variablen

> OBJEKTE sind Variablen. d.h.

- von einer Klasse können Objekte erzeugt werden
- vgl. dazu: vom Datentyp int können viele int-Variablen erzeugt werden

> Objekte werden mit **new** erzeugt.

Beispiel:

~~~ java
  Complex zahl= new Complex(2.0,3.0);
  Point p= new Point(10,20);
  Fluss salzach= new Fluss();
  Auto meins= new Maserati(1000000.0);
~~~
  
Zusammenfassung:
> Die Klasse Complex beschreibt, woraus komplexe Zahlen bestehen. (zB: Realteil und Imaginärteil)

> Das Objekt zahl ist eine spezielle komlexe Zahl.

## 3. Klasse, Objekt, Konstruktor, Getter/Setter und Pakete

Wir wollen Zufallszahlen generieren:
~~~ java
import java.util.*;
....
Random zufall= new Random();

//erzeugt eine Zufallszahl zwischen 0 ... 100
int zahl= zufall.nextInt(101); 

---
Was ist was?:
    • Package: java.util
    • Klasse: Random
    • Objekt: zufall
    • Methode: nextInt()
~~~

- Die Klasse Random ist im Package java.util enthalten. Solche Packages können wir uns wie Unterverzeichnisse vorstellen, in denen sich Klassen befinden.

- Methoden können wir uns als Programmblöcke vorstellen, die einen Namen haben. nextInt() ist eine Methode der Klasse Random.

- Es gibt folgende Arten von Methoden:
  1. **Konstruktoren** ... heißt wie die Klasse und wird beim Erzeugen eines Objektes automatisch aufgerufen (=Initialisierung der Membervariablen)
  
  2. **Destruktoren** ... heißt public void finalize() und wird beim Zerstören eines Objektes aufgerufen. Hat in Java wenig Bedeutung. In C++ hingegen sehr wichtig.

  3. **Get/Set-Methoden** ... zum lesenden/schreibenden Zugriff auf Membervariablen.

  4. **Allgemeine Methoden** ... um zB: etwas zu berechnen, ...

## 4. Planung der Klasse Complex.java

Wie man eine eigene Klasse erstellt zeigt das folgende Beispiel.

Man geht folgendermaßen vor:

1. **Überlege** einen aussagekräftigen Namen für die neue Klasse.

~~~ java
Complex
~~~

2. **Welche Daten** verwaltet die neue Klasse?

~~~ java
double re; // Realteil
double im; //Imaginärteil
~~~

3. **Wer darf** diese Daten ändern? zB: nicht alle, verwende

~~~ java
private double re; // Realteil
private double im; //Imaginärteil
~~~

1. **Wie erzeugt** man Objekte?

~~~java
// Konstruktion mittels Angabe v. re und im
Complex z1= new Complex(3.0, 4.0);
Complex z2= new Complex(5.0, 6.0);

// Konstruktor ohne Parameter
Complex z3= new Complex();

// Konstruktor mit einer anderen Complex-Zahl
Complex z4= new Complex(z1);
~~~

5. **Welche Methoden** soll es geben?

~~~java
Complex z3= z1.add(z2);
String s= z3.toString();
~~~

## 6. Programmierung der Klasse Complex.java

- Gegeben ist die Testklasse TestComplex.java (s.u).
- Programmieren Sie die Klasse Complex.java

~~~java
Projekt: JAVA-OOP1-Complex
Package: oop1
Datei:   oop1.Complex.java
Package: test
Datei:   TestComplex.java
~~~

~~~java
// test.TestComplex.java
package test;

public class TestComplex{
	public static void main(String[] args){
		// Konstruktion mittels Angabe v. re und im
		Complex z1= new Complex(3.0, 4.0); 

		// Konstruktion mittels Angabe v. re und im
		Complex z2= new Complex(5.0, 6.0); 

		// Konstruktor ohne Parameter → default constructor
		Complex z3= new Complex(); //

		// Konstruktor mit einer anderen Complex-Zahl → copy constructor
		Complex z4= new Complex(z1);

		// Methodenaufruf
		Complex z5= z1.add(z2);

		String s= z5.toString();

		System.out.println(s);
	}
}
~~~

~~~ java
// oop1.Complex.java
package oop1;

public class Complex{
    /* enter code */
}
~~~

## 7. Der this-Zeiger

Bei this handelt es sich um einen Zeiger, der beim Anlegen eines Objekts automatisch generiert wird. this ist eine Referenzvariable, die auf das aktuelle Objekt zeigt und dazu verwendet wird, die eigenen Methoden und Instanzvariablen anzusprechen. Der this-Zeiger ist auch explizit verfügbar und kann wie eine ganz normale Objektvariable verwendet werden.

~~~java
class Konto {
	private double betrag;
	....

	public void setBetrag(double betrag){
		this.betrag= betrag;
	}
	....
}
~~~

## 8. Übung: Die Klasse Rechteck

Bringen Sie das folg. Programm zum Laufen.

~~~java
Projekt: JAVA-OOP1-Rechteck
Package: oop1
Datei:   oop1.Rechteck.java
Package: test
Datei:   TestRechteck.java
~~~

~~~ java
// test.TestRechteck.java
package test;
public class TestRechteck {

    public static void main(String[] args) {

        //Jetzt kann man Objekte erzeugen und mit diesen
        // arbeiten.

        //Default Konstruktor wird aufgerufen
        Rechteck wald= new Rechteck();

        System.out.println("Mein Wald hat die Länge: " +
                            wald.getLaenge());
        //Allg. Konstruktor wird aufgerufen
        Rechteck wiese= new Rechteck(20, 5);

        System.out.println("Meine Wiese hat die Länge: " +
                            wiese.getLaenge());

        int flaeche= wiese.flaeche();
        System.out.println("Meine Wiese hat die Fläche: " +
                            flaeche);

        System.out.println("WIESE: " + wiese.toString());
	}
}
~~~

~~~java
// oop1.Rechteck.java
package oop1;

public class Rechteck {
    // Members sind privat
    private int m_laenge;
    private int m_breite;

    //Default Konstruktor
    public Rechteck(){
        m_laenge= 10;
        m_breite= 5;
    }

    /* enter code */
}
~~~






1.7.  Aufgaben: Klassen, Objekte
- AB-01-oop1-fraction-complex-point-rect.txt
- AB-02-oop2-student-schoolclass.txt
- AB-03-oop2-gegenstand-inventar-spieler-kampf.txt
