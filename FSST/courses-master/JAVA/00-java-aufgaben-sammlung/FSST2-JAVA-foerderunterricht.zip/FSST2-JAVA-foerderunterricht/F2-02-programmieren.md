# Schritt 2: Praktische Beispiele programmieren können

## F2-01-array

File: F2-01-array.zip

1. main.Test_01_intarray_random_search_minimum.java
2. main.Test_02_intarray_unique.java
3. main.Test_03_intarray_rotate.java
4. main.Test_04_chararray_gpspoint.java
5. main.Test_05_chararray_ersetze.java
6. main.Test_06_chararray_isbn.java

## F2-02-function

File: F2-02-function.zip

1. test.T01_MyAlgo.java
2. myalgo.MyAlgo.java

## F2-03-oop1

File: F2-03-oop1.zip

1. test.Test_01_Complex.java
2. test.Test_02_Kreis.java
3. test.Test_03_GPSPoint.java
4. test.Test_04_Datum.java
5. oop1.Complex.java
6. oop1.Kreis.java
7. oop1.GPSPoint.java
8. oop1.Datum.java

## F2-04-oop2

File: F2-04-oop2.zip

1. test.Test_01_Mailbox.java
2. test.Test_02_shs.java
3. oop2.Mailbox.java
4. oop2.Mail.java
5. oop2.SchuelerListe.java
6. oop2.Schueler.java
