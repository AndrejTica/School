package main;

public class Test_03_intarray_rotate {

	public static void main(String[] args) {
	/**
	 *     
	1. Definiere ein int-Array namens a mit 10 Elementen.
    2. Schreib mit Hilfe einer for-Schleife die Werte 0,1,2,... ins Array
    3. Gib das Array aus.
    4. Lies von der Tastatur einen int-Wert ein in die Variable index
    	ACHTUNG: Verwende eine do-while-Schleife für das Einlesen,
    	denn die variable index darf nur Werte einen Wert im Bereich 1 bis 9
    	enthalten. 
    5. Rotiere alle Arrayelemente um index-Stellen
    6. Gib das Array aus
       
	Beispiel: Für index wurde 1 eingegeben
	0,1,2,3,4,5,6,7,8,9
	1,2,3,4,5,6,7,8,9,0

	Hinweis: 
	Rotieren bedeutet:
    	1. Erstes Arrayelement in eine Hilfsvariable speichern
    	2. Alle anderen Arrayelemente im Array um eine Stelle nach vorn verschieben
    	3. zwischengespeicherten Wert hinten ins Array schreiben

	 */

		
	// ENTER CODE
		
	}

}
