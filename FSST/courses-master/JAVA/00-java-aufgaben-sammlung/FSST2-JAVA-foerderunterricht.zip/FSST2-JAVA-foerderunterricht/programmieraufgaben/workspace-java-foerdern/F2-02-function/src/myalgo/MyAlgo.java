/*
myalgo.MyAlgo.java
*/
package myalgo;

public class MyAlgo {

// --------------------------------------------------------
// TEIL 1: einfache Algorithmen bei Arrays 
// --------------------------------------------------------

	public static _____________ logo( __________ txt){
		
		System.out.println("=============================");
		System.out.print("==== " + txt + " ====");
		System.out.println("=============================");
	}

	public static ______________ mischen(int[] arr) {
		java.util.Random rnd= new java.util.Random();
		
        _______________________________________
	}

	public static _________ display(____________ arr) {
        // gibt das array arr auf die Konsole aus.
		
        _______________________________________
	}

	public static _____________ getMin_idx(_________________) {
		// Gibt den index (auch position genannt) des kleinsten
        // Arrayelementes mit return zurück.
		
        _______________________________________
		return _______________;
	}

	public static _________ suche(int key, ______________) {
        // gibt den index (auch position genannt) des
        // gesuchten Wertes zurück.
        // Wenn key im array nicht enthalten ist, wird
        // -1 zurückgegeben.
		
        _______________________________________
	}

	public static _________ sortiere(______________) {
        // sortiert die Werte im Array aufsteigend.
		
        _______________________________________
	}

// --------------------------------------------------------
// TEIL 2: spezielle Übungen Arrays/Strings
// --------------------------------------------------------
	
	public static ______________ isPrime(int number) {
        // prüft ob number eine Primzahl ist.
		// gibt true oder false zurück.
        _______________________________________
	}
	
	public static void printPrimes(int[] arr) {
        // gibt nur die Zahlen im Array aus,
        // die eine Primzahl sind.
        // verwendet die Funktion isPrime()

        _______________________________________
	}

	
	public static boolean isLeapYear(int year) {
		/*
		https://www.timeanddate.de/kalender/schaltjahr

		Welche Jahre sind Schaltjahre?
		Der heute gebräuchliche gregorianische Kalender beinhaltet eine Formel mit drei Kriterien,
		nach denen die Jahre in Gemein- und Schaltjahre unterteilt werden:

		1. Schaltjahre müssen durch 4 teilbar sein.
		2. Ist das Jahr auch durch 100 teilbar, ist es kein Schaltjahr, es sei denn...
		3. ...das Jahr ist ebenfalls durch 400 teilbar – dann ist es ein Schaltjahr.

		Beispiele: 
		Die Jahre 2000 und 2400 sind Schaltjahre (infolge Regel 3); 
		Jahre 1800, 1900, 2100, 2200, 2300 und 2500 sind hingegen keine Schaltjahre (infolge Regel 2 – Regel 3 greift nicht).

		*/
        _______________________________________
	}

}
