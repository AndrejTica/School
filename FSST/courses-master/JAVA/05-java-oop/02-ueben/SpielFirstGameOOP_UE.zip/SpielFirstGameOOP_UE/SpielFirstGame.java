/**
 * TODO:
 * 
 * Bring das Programm zum Laufen
 * 
 * 
 */

import javax.swing.SwingUtilities;
import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JSlider;
import javax.swing.BorderFactory;
import javax.swing.border.TitledBorder;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class SpielFirstGame extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JButton jButtonStart = null;
	private JButton jButtonEnd = null;
	private JPanel jPanelSpiel = null;

	private Ball ball=null;
	private Brett brett=null;
	
	private final int BRETTBREITE=10;
	private final int BRETTHOEHE= 80;
	private final int BALLBREITE= 30;
	private final int  DELAY= 10;

	private javax.swing.Timer timer;  //  @jve:decl-index=0:
	private int ticks;

	/**
	 * -- TIMER ------------------------------------------------
	 */
	public void startTimer()
	{		
		timer= new javax.swing.Timer
		(
				DELAY,
				new java.awt.event.ActionListener()
				{
					public void actionPerformed (java.awt.event.ActionEvent e)
					{
						actionGame();

						//ruft update() und dann paint() auf
						// beide können überschrieben werden
						repaint();
					}

				}
		);

		// TIMER starten
		timer.start();		
	}


	/**
	 * Das Spiel spielen
	 */
	public void actionGame() {
		// Ball bewegen
		ball.move();

		// Brett bewegen
		brett.move();

		// Ball ist ganz rechts
		// d.h. ball ist raus ENDE
		if (ball.getX() > jPanelSpiel.getWidth()) {
			timer.stop();

			JOptionPane.showMessageDialog(null, 
					"Schade: Ein Leben weniger. Dauer:" + ticks*DELAY + " ms", 
					"INFO",
					JOptionPane.INFORMATION_MESSAGE);

			// neues Spiel
			ticks=0;
			ball.setX(50);
			ball.setY(50);
			timer.start();
		}

		// Ball hat brett erreicht
		// ball in andere X-Richtung
		if (ball.getX()+ball.getBreite() >= jPanelSpiel.getWidth() - brett.getBreite()) {   // X-koordinate
			if ((ball.getY()  > brett.getY()) &&
					(ball.getY() < brett.getY() + brett.getHoehe())) {  // y-koordinate

				ball.setDX(-2);
			}
		}		   
	}	



	public void stopTimer(){
		if (timer!=null)
			timer.stop();
		timer=null;
	}

	
	/**
	 * Die GUI immer wieder neu Zeichnen
	 */
	public void paint(Graphics g) {
		super.paint(g);		

		Graphics spielfeld= jPanelSpiel.getGraphics();

		spielfeld.setColor(java.awt.Color.white);
		spielfeld.drawString("zeit: " + ticks*DELAY + " ms",10,10 );

		if (ball != null) 
			ball.repaint();
		if (brett != null) 
			brett.repaint();
	}


	private void initGame(){

	    //brett und ball erzeugen und psoitionieren
	    brett= new Brett(
	    		jPanelSpiel.getWidth() - BRETTBREITE,  // Xpos
	    		jPanelSpiel.getHeight()/2 -BRETTHOEHE/2,   // yPos
	    		BRETTBREITE, BRETTHOEHE, 
	    		1, // dy
	    		jPanelSpiel);

	    //				x,y,breite,     dx,dy
	    ball= new Ball(50,50,BALLBREITE,1,1, jPanelSpiel);

	}

	/**
	 * This method initializes jButtonStart	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonStart() {
		if (jButtonStart == null) {
			jButtonStart = new JButton();
			jButtonStart.setBounds(new Rectangle(14, 16, 88, 32));
			jButtonStart.setText("start");
			jButtonStart.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {

					initGame();

					// los gehts
					startTimer();

					// Spielfeld zeichnen 
					// repaint() ruft update() ruft paint() auf
					repaint();

				}
			});
			jButtonStart.addKeyListener(new java.awt.event.KeyAdapter() {
				public void keyPressed(java.awt.event.KeyEvent e) {
					System.out.println("keyPressed()"); // TODO Auto-generated Event stub keyPressed()
					switch (e.getKeyCode()) {
					case java.awt.event.KeyEvent.VK_UP: 
						brett.andereRichtung();  // rauf
						break;
					case java.awt.event.KeyEvent.VK_DOWN: 
						brett.andereRichtung();   //runter
						break;

					}
				}
			});
		}
		return jButtonStart;
	}

	/**
	 * This method initializes jButtonEnd	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonEnd() {
		if (jButtonEnd == null) {
			jButtonEnd = new JButton();
			jButtonEnd.setBounds(new Rectangle(277, 16, 88, 32));
			jButtonEnd.setText("ende");
			jButtonEnd.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					System.exit(0);

				}
			});
		}
		return jButtonEnd;
	}

	/**
	 * This method initializes jPanelSpiel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelSpiel() {
		if (jPanelSpiel == null) {
			jPanelSpiel = new JPanel();
			jPanelSpiel.setLayout(new GridBagLayout());
			jPanelSpiel.setBounds(new Rectangle(15, 74, 350, 258));
			jPanelSpiel.setBackground(Color.magenta);
		}
		return jPanelSpiel;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SpielFirstGame thisClass = new SpielFirstGame();
				thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				thisClass.setVisible(true);
			}
		});
	}

	/**
	 * This is the default constructor
	 */
	public SpielFirstGame() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(387, 372);
		this.setContentPane(getJContentPane());
		this.setTitle("FirstGameOOP");
		this.addWindowListener(new java.awt.event.WindowAdapter() {   
			public void windowOpened(java.awt.event.WindowEvent e) {

			}

		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJButtonStart(), null);
			jContentPane.add(getJButtonEnd(), null);
			jContentPane.add(getJPanelSpiel(), null);
		}
		return jContentPane;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
