import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class SwingZahlensysteme extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldDual;
	private JTextField textFieldDezi;
	private JTextField textFieldHex;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SwingZahlensysteme frame = new SwingZahlensysteme();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SwingZahlensysteme() {
		setTitle("Swing Zahlensysteme");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 515, 82);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(1, 0, 0, 0));
		contentPane.add(getTextFieldDual());
		contentPane.add(getTextFieldDezi());
		contentPane.add(getTextFieldHex());
	}

	private JTextField getTextFieldDual() {
		if (textFieldDual == null) {
			textFieldDual = new JTextField();
			textFieldDual.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent arg0) {
					// nur 0 und 1 zulassen
					// string lesen und umwandeln in dezi und hex und dort anzeigen
				
					String ziffer=  String.valueOf(arg0.getKeyChar());
					String sDual= textFieldDual.getText();
					
					if ("01".contains(ziffer) || arg0.getKeyCode() == arg0.VK_BACK_SPACE){
						int zahl= FKTMyAlgo.dual2int(sDual);
						
						String sDezimal= FKTMyAlgo.int2dezimal(zahl);
						String sHex= FKTMyAlgo.int2hex(zahl);
						
						textFieldDezi.setText(sDezimal);
						textFieldHex.setText(sHex);
					}else {
						// zeichen rausnehmen
						if (sDual.length() > 1)
							textFieldDual.setText(sDual.substring(0, sDual.length()-1));
						else
							textFieldDual.setText("");
					}
					
					/*
					TODO: Programmiere in FKTMyAlgo
					
					public static int dual2int (String ziffern)
					public static int dezimal2int(String ziffern)
					public static int hex2int(String ziffern)
					
					public static String int2dual(int zahl)
					public static String int2hex(int zahl)
					public static String int2dezimal(int zahl)
					
					*/
				}
			});
			textFieldDual.setBorder(new TitledBorder(null, "Dualzahl", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			textFieldDual.setColumns(10);
		}
		return textFieldDual;
	}
	private JTextField getTextFieldDezi() {
		if (textFieldDezi == null) {
			textFieldDezi = new JTextField();
			textFieldDezi.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Dezimalzahl", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			textFieldDezi.setColumns(10);
		}
		return textFieldDezi;
	}
	private JTextField getTextFieldHex() {
		if (textFieldHex == null) {
			textFieldHex = new JTextField();
			textFieldHex.setBorder(new TitledBorder(null, "Hexadezimalzahl", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			textFieldHex.setColumns(10);
		}
		return textFieldHex;
	}
}
