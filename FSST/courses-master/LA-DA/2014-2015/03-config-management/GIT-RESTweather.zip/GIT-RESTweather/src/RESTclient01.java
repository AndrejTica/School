// RESTclient01.java
// yahoo-wetterdaten für Salzburg 
//

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.PasswordAuthentication;
import java.net.URL;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class RESTclient01 {
	public static void main(String[] args) {

		try {

			URL url = new URL("http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%3D12816173%20and%20u%3D%22c%22&format=xml&diagnostics=true&callback=");

			// PROXY BEGIN
			// -------------------------------------------------------------------------------------------
			// PROXY
//			System.setProperty("http.proxyHost","tmg-z2.htl.org") ;
//			System.setProperty("http.proxyPort", "8080") ;
//
//			Authenticator.setDefault(new Authenticator() {
//				protected PasswordAuthentication getPasswordAuthentication() {
//
//					// pwd lesen
//					JPasswordField passwordField = new JPasswordField(10);
//					passwordField.setEchoChar('*');
//					
//					JOptionPane.showMessageDialog ( null, passwordField, "Enter password", JOptionPane.OK_OPTION );
//					char[] chars = passwordField.getPassword();
//					String pwd = new String(chars);
//
//
//					return new
//							PasswordAuthentication("htl\\ahofmann",pwd.toCharArray());
//				}});

			// PROXY END
			// -------------------------------------------------------------------------------------------


			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			
			//conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			// Daten lesen
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
