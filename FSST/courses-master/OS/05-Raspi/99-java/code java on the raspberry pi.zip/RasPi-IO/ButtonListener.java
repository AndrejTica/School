
/**
 * Write a description of interface ButtonListener here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface ButtonListener
{
    /**
     */
    void buttonEvent(Button button);
}
