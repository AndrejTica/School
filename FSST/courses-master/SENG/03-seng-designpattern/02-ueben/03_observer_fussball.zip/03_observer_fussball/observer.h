#ifndef OBSERVER_H
#define OBSERVER_H

//#include "observable.h"
class Observable;

#include <iostream>
using namespace std;

class Observer
{
public:
    Observer();
 //   virtual void update();
    virtual void update(Observable* o);

};

#endif // OBSERVER_H
