uBeobachter-Muster-Fussball
========================================================================
readme.txt


Aufgabe01:
	presseagentur.h fehlt
	oberservable.h fehlt fast

Aufgabe02:
	Ersetze alle Fragezeichen.
	
Aufgabe03:
	Aus den Oberklassen sollen, wenn möglich abstrakte Klassen
	gemacht werden.


Frage:
	Welche sind das?


Frage:
	Warum funktioniert das Programm, obwohl die Konstruktoren
	der Oberklassen nicht explicit aufgerufen werden?
	
	
