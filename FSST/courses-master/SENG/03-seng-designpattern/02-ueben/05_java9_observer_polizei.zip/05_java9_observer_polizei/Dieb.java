// import java.util.Observable;
// import java.util.Observer;
import java.beans.*;


public class Dieb /*extends Observable*/ {
	private String name;
	private String wo;
	
	// !!!!!!!!!!!!!
	private PropertyChangeSupport pcs;
 
	public Dieb(String name) {
//		super();
		this. pcs=  new PropertyChangeSupport(this);

		this.name= name;
	}
 
	// !!!!!!!!!!!!!!!!!!!!!!!!
	public void addObserver(PropertyChangeListener listener){
		pcs.addPropertyChangeListener(listener);
	
	}
	
	public void aufGehts(String wo) {
		String oldvalue= this.wo;
		this.wo= wo;
		
												// name, oldvalue, newvalue
	   pcs.firePropertyChange("Dieb", oldvalue, this.wo);
	   
	   // Markierung, dass sich was geaendert hat
//	   super.setChanged(); 
	   
	   // ruft fuer alle Beobachter die update-Methode auf
//	   super.notifyObservers(); 
	   
	}
 
	
	public String toString() {
	   return name + " ... ich bin gerade hier: " + wo + "\n";
	}
}
