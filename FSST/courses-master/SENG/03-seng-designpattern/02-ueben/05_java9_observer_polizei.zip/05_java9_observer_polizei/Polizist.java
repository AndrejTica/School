//import java.util.Observable;
//import java.util.Observer;
import java.beans.*;

public class Polizist implements PropertyChangeListener {
	private String name;
	
	public Polizist(String name) {
	   this.name= name;
	}
 
	
/*
	public void update(Observable o, Object arg) {
		 Dieb dieb= (Dieb) o;
		 
		 System.out.println("POLIZIST: " + name);
		 System.out.print(" meldet folg. Beobachtung: " );
		 System.out.println(dieb.toString());		
	}
*/

public void propertyChange(PropertyChangeEvent evt) {
		System.out.println("POLIZIST: " + name);
		System.out.print("... meldet folg. Beobachtung: " );
		System.out.println( evt.getNewValue());	

/*
        System.out.print("Name      = " + evt.getPropertyName());
        System.out.println("Old Value = " + evt.getOldValue());
        System.out.println("New Value = " + evt.getNewValue());
*/
    }

}
