
public class FullException extends Exception{

}

class EmptyException extends Exception{

}