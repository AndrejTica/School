
public class RingSchlange {
	private Object[] s;
	private int size;
	private int front,end;
	
	
	public RingSchlange(int i) {
		s= new Object[i];
		size=i;
		front=0;
		end=0;
	}

	public boolean isEmpty() {
		return front==end;
	}

	public void enqueue(Integer o) throws FullException {
		if (! isFull()){
			end = (end+1)%size;
			s[end]= o;
		}
		else
			throw new FullException();
	}

	
	public boolean isFull() {
		return (end+1)%size == front;
	}

	public Object dequeue() throws EmptyException{
		if(! isEmpty()){
			front= (front+1)%size;
			return s[front];
		}
		else
			throw new EmptyException();
		
	}

}
