/*
 * a.hofmann, 2010
 * 
 * Unterlage: 
 * 	4ME/SENG/04-seng-testen/*
 * 
 * Aufgabe 1:
 * 
 * Der Test liefert einen Error.
 * Korrigieren Sie dies und führen Sie nach jeder Änderung 
 * einen Testlauf durch.
 * 
 * 
 * Aufgabe 2:
 * 
 * Erstellen Sie noch den Test für toString()
 * (siehe: JUnitStack)
 * @Test	
	public void testtoString() throws FullException{
		...
	}
 */

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RingSchlangeTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEmpty(){
		RingSchlange s= new RingSchlange(3);
	
		assertTrue(s.isEmpty());
	}
	
	@Test
	public void testFull() throws FullException{
		RingSchlange s= new RingSchlange(3);
		Integer i1= new Integer(1);
		Integer i2= new Integer(2);
		Integer i3= new Integer(3);
		
		s.enqueue(i1);
		s.enqueue(i2);
		s.enqueue(i3);
		
	
		assertTrue(s.isFull());
		assertFalse(s.isEmpty());
	}
	
	@Test	
	public void testEnqueueAndEmpty()throws FullException{
		RingSchlange s= new RingSchlange(3);
		
		Integer i= new Integer(1);
		Integer j;
		
		s.enqueue(i);
		assertFalse(s.isEmpty());
	}
	
	@Test	
	public void testEnqueueDequeueAndEmpty()throws EmptyException, FullException{
		RingSchlange s= new RingSchlange(3);
		
		Integer i= new Integer(1);
		Integer j;
		
		s.enqueue(i);
		j= (Integer) s.dequeue();
	
		assertTrue(s.isEmpty());
		assertEquals(i, j);
	}
	
	@Test	
	public void testFullException(){
		try {
			RingSchlange s= new RingSchlange(3);
			Integer i1= new Integer(1);
			Integer i2= new Integer(2);
			Integer i3= new Integer(3);
			Integer i4= new Integer(3);
			
			
			s.enqueue(i1);
			s.enqueue(i2);
			s.enqueue(i3);
			s.enqueue(i4);

			fail("enqueue worked on full ringschlange");
	
		} catch (FullException expected) {
			// todo �.
		}
	}
	
	@Test	
	public void testEmptyException(){
		try {
			RingSchlange s= new RingSchlange(3);
	
			s.dequeue();
			
			fail("dequeue worked on empty ringschlange");
	
		} catch (EmptyException expected) {
			// todo �.
		}
	}
		
}
