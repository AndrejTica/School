# Förderunterricht: FSST2 JAVA A.Hofmann

Inhalt:

- Arrays/Strings
- Funktionen/Methods
- OOP

Vorgehen:

## Schritt 1: IST-Analyse mit https://www.w3schools.com/java/default.asp

- Bei Arrays/Strings verstehe ich das nicht:
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  
- Bei Funktionen/Methods verstehe ich das nicht:
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________

- Bei OOP verstehe ich das nicht:
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  - _______________________________________________
  
## Schritt 2: Praktische Beispiele programmieren können

- Java-Projekt: F2-01-array
- Java-Projekt: F2-02-function
- Java-Projekt: F2-03-oop1
- Java-Projekt: F2-03-oop2
  
## - Schritt 3: Tests bestehen / Programme schreiben können

- MAB-array
- MAB-function
- MAB-oop
