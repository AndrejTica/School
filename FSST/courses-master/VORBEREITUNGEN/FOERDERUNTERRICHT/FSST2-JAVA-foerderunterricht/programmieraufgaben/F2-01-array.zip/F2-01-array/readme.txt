Hinweis: Java-Array-Strings:
===========================

Strings und char-Arrays
-----------------------
	String s1= "Hallo";
	
	s1 += " Welt";
	
	char[] sArr= s1.toCharArray();
	
	sArr[0]= 'X';
	char ch= sArr[0]; // 'X'
	
	String s2= String.valueOf(sArr);
	
Strings vergleichen
-------------------
	boolean istGleich= s1.equals(s2);  // Strings vergleichen: liefert true oder false
	
	
Zeichenweise auf Strings zugreifen
----------------------------------	
	String s3="HALLO";
	char ch1= s3.charAt(0);  // 'H'
	
	
Strings <---> int konvertieren
--------------------------------	
	String s3= "100";
	int zahl= Integer.parseInt(s3);
	zahl= zahl + 23;
	s3= String.valueOf(zahl);

	
Zeichen (hier eine Ziffer) in eine Zahl umwandeln
------------------------------------------------	
	String s4="987";
	int zahl= (int) (s4.charAt(0) - '0');
	System.out.println(zahl); // 9 wird ausgegeben
		
	