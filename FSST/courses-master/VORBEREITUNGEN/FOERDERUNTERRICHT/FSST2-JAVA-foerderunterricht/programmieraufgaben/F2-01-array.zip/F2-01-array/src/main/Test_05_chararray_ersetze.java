package main;

public class Test_05_chararray_ersetze {

	public static void main(String[] args) {
		/**
		* Ersetze
		Gegeben sei folgender Programmcode:
		
			String s1 = "ueb immer treu und redlichkeit";
			String s2 = "opqrstu";
		
		Es soll nun der Text s1 geändert werden, und zwar auf folgende Art: 
		
		Jedes Zeichen im Text s1, das im Text s2 vorkommt, soll durch ’*’ ersetzt werden.  
		
		Im obigen Beispiel würde s1 dann beinhalten:
		*eb imme* **e* *nd *edlichkei*
		
		1. Lies s1 von der Konsole ein
		2. Lies s2 von der Konsole ein
		3. Ersetze die Zeichen in s1
		4. Gib s1 aus.
		*/

		String s1="";
		String s2="";
		
		// ENTER CODE
		
		System.out.println("s1 ersetzt: " + s1);
	}

}
