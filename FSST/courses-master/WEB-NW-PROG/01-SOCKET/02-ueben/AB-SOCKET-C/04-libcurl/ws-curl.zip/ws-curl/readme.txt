========================================================================
libcurl und curl 
========================================================================

*AUFGABE: install curl
sudo apt-get install curl libcurl4-openssl-dev -y



* AUFGABE: curl verwenden mit htl-proxy
Versuche:
curl -x http://tmg-z2.htl.org:8080 --proxy-user USERNAME:PWD -L http://www.zamg.ac.at/ogd


* AUFGABE: wget
Bringen Sie das Programm zamg-wget-salzburg.c zum Laufen


* AUFGABE: libcurl verwenden mit htl-proxy
s. Makefile 
bzw. simple-with-proxy.c


========================================================================
AUFGABE: libcurl - erste programme
========================================================================
Bringen Sie die C-Programme zum Laufen.

Weitere Beispiele finden Sie bei:
http://curl.haxx.se/libcurl/c


Insbesondere ist vielleicht dieses Programm dienlich:
http://curl.haxx.se/libcurl/c/httpput.html
 


========================================================================
AUFGABE: Wetterdaten ZAMG Open Data
========================================================================


Hier eine telnet - session
---------------------------------------
telnet  www.zamg.ac.at 80
Trying 138.22.100.21...
Connected to www.zamg.ac.at.
Escape character is '^]'.
GET /ogd/ HTTP/1.1
Host: www.zamg.ac.at
Accept: */*

HTTP/1.1 200 OK
Date: Tue, 18 Feb 2014 11:21:09 GMT
Server: Apache
Content-Disposition: attachment; filename="tawes1h.csv"
Content-Length: 2026
Expires: Sat, 26 Jul 1997 05:00:00 GMT
Cache-Control: no-cache, must-revalidate
Pragma: no-cache
Content-Type: text/csv

"Station";"Name";"Höhe m";"Datum";"Zeit";"T °C";"TP °C";"RF %";"WR °";"WG km/h";"WSR °";"WSG km/h";"N l/m²";"LDred hPa";"LDstat hPa";"SO %"
11010;"Linz/Hörsching";298;"18-02-2014";"12:00";6,9;1,9;71;100;13;;24,1;0;1018,9;981;100
11012;"Kremsmünster";383;"18-02-2014";"12:00";3,2;2;90;121;5,4;116;13,3;0;1019,6;971,9;93
11022;"Retz";320;"18-02-2014";"12:00";1,9;;97;55;16,9;53;22;0;1022,1;982,5;0
11035;"Wien/Hohe Warte";203;"18-02-2014";"12:00";6,2;2,6;77;129;16,9;118;31,3;0;1021,7;996,2;90
11036;"Wien/Schwechat";183;"18-02-2014";"12:00";4,4;3,1;92;130;24,1;;33,5;0;1021,9;999,6;6
11101;"Bregenz";424;"18-02-2014";"12:00";3,7;1,8;88;348;5,4;341;11,9;0;1018,2;965,1;29
11121;"Innsbruck";579;"18-02-2014";"12:00";7,5;0,5;61;259;27,4;258;40,3;0;1018,3;948,9;100
11126;"Patscherkofel";2247;"18-02-2014";"12:00";-0,4;-9,5;51;168;40,7;163;57,2;0;;772,5;100
11130;"Kufstein";495;"18-02-2014";"12:00";7,3;0,1;61;205;12,6;200;26,6;0;1017,6;958,9;100
11150;"Salzburg";430;"18-02-2014";"12:00";9,1;1,3;61;150;20,5;;27,7;0;1016,6;963,7;100
11155;"Feuerkogel";1618;"18-02-2014";"12:00";4,7;-4,3;53;198;14,4;206;19,1;0;;834,8;100
11157;"Aigen im Ennstal";640;"18-02-2014";"12:00";5,2;1,3;77;214;3,6;185;14,8;0;1020,7;943;86
11171;"Mariazell";866;"18-02-2014";"12:00";5,6;0,3;70;173;19,8;176;32,4;0;1018,7;917,4;100
11190;"Eisenstadt";184;"18-02-2014";"12:00";3,4;3,4;100;131;19,4;118;31;0;1022,2;999,6;0
11204;"Lienz";659;"18-02-2014";"12:00";5;0;71;243;2,9;268;9,4;0;1023,9;944;100
11240;"Graz/Flughafen";340;"18-02-2014";"12:00";1,7;1,6;100;140;3,6;;11,2;0;1023,6;978,7;0
11244;"Bad Gleichenberg";280;"18-02-2014";"12:00";3,3;;93;172;4;187;10,1;0;1023,7;990,2;0
11265;"Villacher Alpe";2140;"18-02-2014";"12:00";-4,1;-4,8;97;232;66,6;234;71,6;0;;782,9;100
11331;"Klagenfurt/Flughafen";447;"18-02-2014";"12:00";2,7;1,3;93;172;2,5;197;6,1;0;1024,6;969,2;0
11343;"Sonnblick";3105;"18-02-2014";"12:00";-7,5;-10,9;77;;50,8;257;59;0;;694,5;100
11389;"St. Pölten";270;"18-02-2014";"12:00";8,2;3,7;74;355;10,4;338;22;0;1019,2;986,6;100
Connection closed by foreign host.


Aufgabe:
------------------------------------------------------------------------------------------
1. install volkszähler
	www.volkszaehler.org

2. install libcurl

3. ./zamg-opendata.exe "Salzburg" "T °C"

4. als cronjob

