./zamg2vz.sh Salzburg  98fd2600-b4bb-11e3-afa6-fd34350f1281
./zamg2vz.sh Bregenz  c1b717a0-b5b6-11e3-a58c-ef8aeeeb51dc
./zamg2vz.sh Linz/Hörsching     2cc3ce40-b5b8-11e3-ae7a-c5e4bb8633c9
./zamg2vz.sh Retz            	c803b980-b5b6-11e3-9f74-152449a53762
./zamg2vz.sh Kremsmünster       0684e4a0-b5b8-11e3-a70f-edd61321fe02
./zamg2vz.sh "Wien/Hohe Warte"  c34283a0-b5b6-11e3-a4ac-0b13b97cbac0
./zamg2vz.sh Wien/Schwechat     d54447a0-b5b6-11e3-846a-b7388ef567a1
./zamg2vz.sh Bregenz     	c1b717a0-b5b6-11e3-a58c-ef8aeeeb51dc
./zamg2vz.sh Kufstein        	147578f0-b5b7-11e3-9c82-85cc4f734eef
./zamg2vz.sh Feuerkogel       	1293ac50-b5b8-11e3-8d38-ad9f6f0d5630
./zamg2vz.sh Innsbruck        	c256ebd0-b5b6-11e3-907e-c78475285974
./zamg2vz.sh Patscherkofel   	245dd830-b5b7-11e3-904a-73dde2ae6d47
