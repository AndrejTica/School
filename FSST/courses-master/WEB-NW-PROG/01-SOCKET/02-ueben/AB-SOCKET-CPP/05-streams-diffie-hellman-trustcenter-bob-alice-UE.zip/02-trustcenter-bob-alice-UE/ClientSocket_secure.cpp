// Implementation of the ClientSocket_secure class

#include "ClientSocket_secure.h"
#include "SocketException.h"

#include <iostream>
using namespace std;

ClientSocket_secure::ClientSocket_secure ( string host, int port, int key ){
	if ( ! Socket::create() ){
		throw SocketException ( "Could not create client socket." );
	}

	if ( ! Socket::connect ( host, port ) ){
		throw SocketException ( "Could not bind to port." );
	}

// !!!!!!!!!!!!!!!!!!!!!!

	cipherstream_in= new ________________(________________);
	cipherstream_out= new ________________(________________);

}


const ClientSocket_secure& ClientSocket_secure::operator << ( const string& s ) const{
// !!!!!!!!!!!!!!!!!!!!!!
cout << "ClientSocket_secure::operator<< SEND(plainText) is:" << s << endl;
	cipherstream_out->________________( s);
	string sout= cipherstream_out->________________();

cout << "ClientSocket_secure::operator<< SEND(cryptText) is:" << sout << endl;

cout << "ClientSocket_secure::operator>> SENDING ..."  << endl;
// !!!!!!!!!!!!!!!!!!!!!!
	if ( ! Socket::________________ ( sout) ){
		throw SocketException ( "Could not write to socket." );
	}

	return *this;
}


const ClientSocket_secure& ClientSocket_secure::operator >> ( string& s ) const {
cout << "ClientSocket_secure::operator>> RECEIVING ..."  << endl;

	if ( ! Socket::recv ( s ) ){
		throw SocketException ( "Could not read from socket." );
	}
// !!!!!!!!!!!!!!!!!!!!!!
	else{
cout << "ClientSocket_secure::operator>> RECEIVED(cryptText) is:" << s << endl;
		cipherstream_in->setCryptText(s);
		s= cipherstream_in->________________();

cout << "ClientSocket_secure::operator>> RECEIVED(plainText) is:" << s << endl;
	}

	
	return *this;
}

