// Definition of the ClientSocket_secure class

#pragma once

#include "Socket.h"
// !!!!!!!!!!!!!!!!!!!!!!
#include "cipherstream.h"
using namespace std;


class ClientSocket_secure : private ________________{
	public:
		// !!!!!!!!!!!!!!!!!!!!!!
		ClientSocket_secure ( string host, int port, int key );

// !!!!!!!!!!!!!!!!!!!!!!
		virtual ~ClientSocket_secure(){
			________________ cipherstream_out;
			________________ cipherstream_in;
		};

		const ClientSocket_secure& operator << ( const string& ) const;
		const ClientSocket_secure& operator >> ( string& ) const;
	private:
// !!!!!!!!!!!!!!!!!!!!!!
		CipherStream* cipherstream_out;
		CipherStream* cipherstream_in;
};

