
#include "ServerSocket_secure.h"
#include "SocketException.h"

#include <string>
#include <iostream>

#include <cstdlib>
#include <cstdio>
#include <cmath>


#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// consts
const int TRUSTCENTER_PORT=30000;
const char* TRUSTCENTER_HOST= "localhost";
const int BOB_PORT=4444;
const char* BOB_HOST= "localhost";


#include "ClientSocket.h"
class DH {
	private:
		int trustcenter_port;
		string trustcenter_hostname;

		string myName;
		string partnerName;
		int n,g;
		int myPubKey;
		int partnerPubKey;
		int secretNumber;
		int symKEY;

		void getNG();
		void calcPubKey();
		void sendPubKey();
		void receivePartnerPubKey();
		void calcSymKEY();
	public:
		DH(string hostname, int port, string myName, string partnerName){
			trustcenter_hostname= hostname;
			trustcenter_port= port;
			this->myName=myName;
			this->partnerName=partnerName;


			getNG();
			calcPubKey();
			sendPubKey();
			receivePartnerPubKey();
			calcSymKEY();
		}

		int getSymKEY()const{
			return symKEY;
		}

		~DH(){};
};
/*
void DH::getNG(){}
void DH::calcPubKey(){}
void DH::sendPubKey(){}
void DH::receivePartnerPubKey(){}
void DH::calcSymKEY(){}
*/

void DH::getNG(){
		// 1. RECEIVE g,n from trustcenter
cout << "... receiving n,g from trustcenter (GET:NG)" << endl;
	string data, part;

	ClientSocket trustcenter(trustcenter_hostname, trustcenter_port);

	trustcenter << "GET:NG";
	trustcenter >> data;

	stringstream ss(data);
	// N
	std::getline(ss, part, ':');
	sscanf(part.c_str(),"%i", &n);
	// G
	std::getline(ss, part, ':');
	sscanf(part.c_str(),"%i", &g);
	
cout << "... got n= "<<n<<", g="<<g <<endl;
}


void DH::calcPubKey(){
	
	secretNumber= rand()%5;	
cout << "... choosing secret number: = " << secretNumber << endl;
cout << "... calculating Public Key: PK= (int) pow("<<g<<","<< secretNumber <<") % " << n << endl;

	myPubKey= (int) pow(________________ , ________________) % ________________; 

cout << "... Public key= " << myPubKey << endl;
}



void DH::sendPubKey(){
cout << "... sending Public Key to TC: = " << myPubKey << endl;
	ClientSocket trustcenter(trustcenter_hostname, trustcenter_port);

	ostringstream os;
	os << "ADD:PK:" << ________________ <<":" << ________________;
	trustcenter << os.str();

cout << "... ADD:PK:" << myName << ":" << myPubKey<< endl;
}



void DH::receivePartnerPubKey(){
cout << "... receiving/waiting for partner public key" << endl;

	partnerPubKey=-1;
	do{
		usleep(1000*1000*5); // 5sec

		string data;
		ostringstream os;
		os << "GET:PK:" << partnerName;

		ClientSocket trustcenter(trustcenter_hostname, trustcenter_port);
		trustcenter << os.str();
		trustcenter >> data;

cout << "... got from trustcenter: " << data << endl;
	
		if (data != "-401" && data != "-402"){
			sscanf(data.c_str(), "%i", &partnerPubKey);
		}

	} while (partnerPubKey == -1);
	
cout << "... got from trustcenter Partner's Public Key = " << partnerPubKey << endl;

}


void DH::calcSymKEY(){
	symKEY= (int) pow(________________, ________________) % ________________;
cout << "... calculating symKEY = (int) pow(";
cout << partnerPubKey <<"," << secretNumber <<")%" << n << "= "<< symKEY <<endl;
}




