// Implementation of the ServerSocket_secure class

// !!!!!!!!!!!!!!!!!!!!!!
#include "ServerSocket_secure.h"

#include "SocketException.h"
#include <iostream>
using namespace std;


ServerSocket_secure::ServerSocket_secure ( int port, int key ){
	if ( ! Socket::create() ){
		throw SocketException ( "Could not create server socket." );
	}

	if ( ! Socket::bind ( port ) ){
		throw SocketException ( "Could not bind to port." );
	}

	if ( ! Socket::listen() ){
		throw SocketException ( "Could not listen to socket." );
	}


// !!!!!!!!!!!!!!!!!!!!!!
	cipherstream_in= new ________________(________________);
	cipherstream_out= new ________________(________________);
}



ServerSocket_secure::ServerSocket_secure ( int key ): Socket(){
// !!!!!!!!!!!!!!!!!!!!!!
	cipherstream_in= new CipherStream(key);
	cipherstream_out= new CipherStream(key);
}




const ServerSocket_secure& 
ServerSocket_secure::operator << ( const std::string& s ) const{

// !!!!!!!!!!!!!!!!!!!!!!
cout << "ServerSocket_secure::operator<< SEND(plainText) is:" << s << endl;

	cipherstream_out->encrypt(s);
	string sout=cipherstream_out->getCryptText();

cout << "ServerSocket_secure::operator<< SEND(cryptText) is:" << sout << endl;
cout << "ServerSocket_secure::operator>> SENDING ..."  << endl;

	if ( ! Socket::send ( sout ) ){
		throw SocketException ( "Could not write to socket." );
	}

	return *this;
}


const ServerSocket_secure& 
ServerSocket_secure::operator >> ( string& s ) const{
// !!!!!!!!!!!!!!!!!!!!!!
	string cipherText;

cout << "ServerSocket_secure::operator>> RECEIVING ..."  << endl;
	if ( ! Socket::recv ( ________________ ) ){
		throw SocketException ( "Could not read from socket." );
	}

// !!!!!!!!!!!!!!!!!!!!!!
cout << "ServerSocket_secure::operator>> RECEIVED(cryptText) is:" << cipherText << endl;

	cipherstream_in->setCryptText(cipherText);
	s= cipherstream_in->________________();
cout << "ServerSocket_secure::operator>> RECEIVED(plainText) is:" << s << endl;

	return *this;
}


void ServerSocket_secure::accept ( ServerSocket_secure& sock ){
	if ( ! Socket::accept ( sock ) ){
		throw SocketException ( "Could not accept socket." );
	}
}

