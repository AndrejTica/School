/** alice.cpp
* ahofmann, 2017
*/

#include "ClientSocket_secure.h"
#include "SocketException.h"

#include <iostream>
#include <cstdlib>
using namespace std;

#include "DH.h"


int main ( int argc, char* argv[] ){
	cout << endl << "ALICE starting ....";
	cout << endl << "enter \"go\" to start ...";
	string in;
	cin >> in;

														// me     //partner
	DH diffie_hellman(TRUSTCENTER_HOST, TRUSTCENTER_PORT,"ALICE", "BOB");

	int symKEY= diffie_hellman.getSymKEY();


	ClientSocket_secure client_socket(BOB_HOST, BOB_PORT, symKEY);
	string reply;

	try{
	string data="Test message.";

cout << "ALICE: sending <" << data << ">" << endl;

		client_socket << data;
		client_socket >> reply;

cout << "ALICE: received: <" << reply << ">" << endl;
	}catch ( SocketException& e) {
		cerr << "error: SocketException ..." << endl;
		exit(1);
	}

	cout << endl << "ALICE finished ....";
	cout << endl << "enter \"stop\" to finish ...";
	cin >> in;

	return 0;
}

