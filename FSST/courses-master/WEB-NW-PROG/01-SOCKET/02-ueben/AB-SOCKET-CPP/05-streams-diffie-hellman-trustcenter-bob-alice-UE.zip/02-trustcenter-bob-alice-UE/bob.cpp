/** bob.cpp
* ahofmann, 2017
*/

#include "ServerSocket_secure.h"
#include "SocketException.h"

#include <iostream>
#include <cstdlib>
using namespace std;

#include "DH.h"

int main ( int argc, char* argv[] ){
	cout << endl << "BOB starting ....";
	cout << endl << "enter \"go\" to start ...";
	string in;
	cin >> in;
														// me     //partner
	DH diffie_hellman(TRUSTCENTER_HOST, TRUSTCENTER_PORT,"BOB", "ALICE");
	int symKEY= diffie_hellman.getSymKEY();

	
	// Create the socket
	ServerSocket_secure server ( BOB_PORT, ________________ );
	cout << "BOB ...running on port " << BOB_PORT << "...."<< endl;

	while ( true ){
		ServerSocket_secure new_sock(________________);
		server.________________ ( new_sock );

		int pid= fork();
		if (pid==0){ // child ----------------------------------------------
			try{
				bool quit=false;
				while ( ! quit ){
					string data;

					________________ >> data;

					quit= (data=="quit" || data=="quit\r\n")?true:false;
					std::cout <<"Server got: <" << data << ">" << std::endl;

					________________ << data;
				}

				std::cout <<"Server closing connection..." << std::endl;
	
			}catch ( SocketException& ) {}
			
			exit(0);
		}else{
			// parent ------------------------------------------------------
			int state;
			waitpid(-1, &state, WNOHANG);
		}	
	} //while

	return 0;
}

