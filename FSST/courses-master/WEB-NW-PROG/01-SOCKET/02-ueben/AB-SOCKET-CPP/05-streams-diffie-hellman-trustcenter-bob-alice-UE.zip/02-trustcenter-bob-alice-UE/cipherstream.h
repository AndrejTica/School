// ahofmann, 2014
// cipherstream.h


#ifndef CIPHERSTREAM_H
#define CIPHERSTREAM_H

#include <sstream>
#include <iostream>

#include <string>
using namespace std;

#include <cstdlib> // srand


class CipherStream{
	private:
		int key;
		string cryptText;

	public:
		CipherStream(int key){
			this->key= key;
			________________(key); // init key
			cryptText="";
		}

	// encrypt
		CipherStream& operator << (const string& s){
			this->encrypt(s);
			return ________________;
		}
		CipherStream& operator << (const char* p){
			this->encrypt(string(p));
			return *this________________;
		}

		void encrypt(const string& s){
			________________(key);
			int nextKey;
			for (int i=0; i< s.________________(); i++){
				nextKey= ________________();
				cryptText ________________ (s[i] ^ nextKey);  
			}
		}
		
	// decrypt
		CipherStream& operator >> (string& s){
			s= this->decrypt();
			return ________________;		
		}

		string decrypt(){
			// init key-generator
			________________(key);

			string plainText="";

			int nextKey;
			for (int i=0; i< cryptText.size(); i++){
				nextKey= ________________();
				plainText +=________________ (cryptText[i] ^ nextKey);  
			}

			return plainText;
		}
		
// GET/SET CryptText
		const string& str() const{
			return cryptText;
		}

		const string& getCryptText() const{
			return str();
		}

		
		void setCryptText(string& cryptText){
			this->cryptText= cryptText;

			// adapt key
			________________(key);
			for(int i=0; i< cryptText.size();i++)
				________________();
		}

// -------------------- end


		void reset(){
			cryptText="";
			srand(key);
		}

	// output
		friend ostream& operator<<(________________& o, ________________& cs){
	
			o << "[ ";
			for (unsigned int i=0; i< cs.cryptText.size() -1; i++){
				o << (int) cs.cryptText[i] << "," ;
			}
			o << (int) cs.cryptText[cs.cryptText.size() -1];
			o << " ]" << endl;

			return o;
		}
};
#endif

