# Diffie-Hellman, TrustCenter, Alice and Bob
---------------------------------------------------------------------------

## Topic
* programs:
	* TRUSTCENTER on port 30000
	* ALICE (acts like a client)
	* BOB (acts like a server on port 4444) 
* use symmetric cipher (streamcipher)
* instead of key-exchange use Diffie-Hellman
* Alice and Bob use encrypted communication
* Alice,Bob use plain communication with trustcenter
* test with wireshark


## Overview
Alice uses:
	Socket, SocketException
	ClientSocket
	ClientSocket_secure.cpp
	DH.h
	alice.cpp

Bob uses:
	Socket, SocketException
	ClientSocket
	ServerSocket_secure
	DH.h
	bob.cpp

TrustCenter uses
	Socket, SocketException
	ServerSocket
	trustcenter.h, run-trustcenter.cpp

## compile and run:
* see Makefile
	make
	make run-tc
	make bob
	make alice

