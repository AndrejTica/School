// run-trustcenter.cpp
/*
"GET:NG"
	"123:456"

"ADD:PK:BOB:123"
	"200 OK"

"GET:PK:BOB"
	"123"
	"-402"

"?"
	"-401"

./run-trustcenter.exe 

*/
#include "trustcenter.h"

// ht
// consts
const int TRUSTCENTER_PORT=30000;
string n="7";
string g="5";

int main ( int argc, char* argv[] ){

	TrustCenter trustcenter(TRUSTCENTER_PORT,n,g);
	
	trustcenter.accept();


	return 0;
}

