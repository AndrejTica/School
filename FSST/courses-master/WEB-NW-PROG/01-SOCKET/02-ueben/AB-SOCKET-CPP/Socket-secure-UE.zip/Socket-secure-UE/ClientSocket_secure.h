// Definition of the ClientSocket_secure class

#ifndef ClientSocket_class
#define ClientSocket_class

#include "Socket.h"

// !!!!!!!!!!!!!!!!!!!!!!
#include "cipherstream.h"

// !!!!!!!!!!!!!!!!!!!!!!
class ClientSocket_secure : private Socket{
	public:
// !!!!!!!!!!!!!!!!!!!!!!
		ClientSocket_secure ( std::string host, int port , int key); 
		virtual ~ClientSocket_secure(){
			// !!!!!!!!!!!!!!!!!!!!!!
			//		ENTER CODE HERE
			};

		const ClientSocket_secure& operator << ( const std::string& ) const;
		const ClientSocket_secure& operator >> ( std::string& ) const;

// !!!!!!!!!!!!!!!!!!!!!!
	private:
		CipherStream* cipherstream_out;
		CipherStream* cipherstream_in;
};


#endif
