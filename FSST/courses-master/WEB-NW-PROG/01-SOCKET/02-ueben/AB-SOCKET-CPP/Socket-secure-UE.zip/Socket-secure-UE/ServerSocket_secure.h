// Definition of the ServerSocket_secure class

#ifndef ServerSocket_class
#define ServerSocket_class

#include "Socket.h"

// !!!!!!!!!!!!!!!!!!!!!!
#include "cipherstream.h"

// !!!!!!!!!!!!!!!!!!!!!!
class ServerSocket_secure : private Socket{
	public:
	
// !!!!!!!!!!!!!!!!!!!!!!
		ServerSocket_secure ( int port , int key);
		ServerSocket_secure (){};


		virtual ~ServerSocket_secure(
// !!!!!!!!!!!!!!!!!!!!!!
//		ENTER CODE HERE
		);


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		const ServerSocket_secure& operator << ( const std::string& ) const;
		const ServerSocket_secure& operator >> ( std::string& ) const;

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		void accept ( ServerSocket_secure& );


// !!!!!!!!!!!!!!!!!!!!!!
private:  
		CipherStream* cipherstream_out;
		CipherStream* cipherstream_in;

};


#endif
