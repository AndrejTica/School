
#include "cipherstream.h"

#include <iostream>
using namespace std;

ostream& operator<<(ostream& o, const CipherStream& e){
	
	o << "[";
	
	for(int i=0; i< e.cipherText.size() -1; i++)
		o << (int) e.cipherText[i] << ",";
		
	o<< (int) e.cipherText[e.cipherText.size()-1];
	
	o<< "]" ;

	return o;
}
