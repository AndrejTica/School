// cipherstream.h

#pragma once

#include <string>
using namespace std;

#include <cstdlib>

class CipherStream{
	private:
		int key;
		string cipherText;
		
	public:
		CipherStream(int k){
			this->key= k;
			
			// init seed
			srand(this->key);
			
			// init cipherText
			cipherText="";
		}
		
		void encrypt(const string& plain){
			for( int i=0; i< plain.size(); i++){
				cipherText += plain[i] ^ rand();
			}
		}
		string decrypt(){
			string retPlain= "";
			srand(this->key);
			
			for(int i=0; i< cipherText.size(); i++)
				retPlain += cipherText[i] ^ rand();
			
			return retPlain;
		}
		
		
		CipherStream& operator<<(const string& plain){
			this->encrypt(plain);
			return *this;
		}
		
		
		CipherStream& operator>>(string& plain){
			plain= this->decrypt();
			return *this;
		}
		
		const string& str(){
			return cipherText;
		}
		
		void reset(){
			cipherText="";
			srand(this->key);
		}
		
		friend ostream& operator<<(ostream& o, const CipherStream& e);
		
};
