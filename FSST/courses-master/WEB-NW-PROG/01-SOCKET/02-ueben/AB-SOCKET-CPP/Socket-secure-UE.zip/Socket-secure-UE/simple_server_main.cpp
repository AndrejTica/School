#include "ServerSocket_secure.h"
#include "SocketException.h"
#include <string>

//ht
#include <iostream>
using namespace std;


// ht
int main ( int argc, char* argv[] )
{
	if (argc!= 2){
		cout << "usage: " << argv[0] << " #key" <<endl;
		exit(1);
	}

  try
    {
      // Create the socket
      ServerSocket_secure server ( 30000 , atoi(argv[1]) );
      
      std::cout << "running.... port " << 30000<<endl;

    while ( true )
	{

	  ServerSocket new_sock;
	  server.accept ( new_sock );

	  try
	    {
			bool quit=false;	
			while ( ! quit )
			{
			  std::string data;
			  
			  new_sock >> data;

			  quit= (data=="quit" || data=="quit\r\n")? true:false ;
			  
			  
			  cout << "SERVER: got <" << data << ">" << endl;
			  
			  new_sock << data;
			}
	    }
	  catch ( SocketException& ) {}

	}
    }
  catch ( SocketException& e )
    {
      std::cout << "Exception was caught:" << e.description() << "\nExiting.\n";
    }

  return 0;
}
