document.body.style.visibility = "hidden";

var JSEOptions = {stylesheet: "css/highlight.css"};
