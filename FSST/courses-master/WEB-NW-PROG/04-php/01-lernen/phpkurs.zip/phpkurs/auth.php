<?
// auth.php
// AUTH anforderung senden
//  -----------------------
function SendAuth() {
	header("WWW-Authenticate: Basic realm=\"Verbotene Zone\"");
	header("HTTP/1.0 401 Unauthorized");

	// Ersatzseite
	print "<html><body>Zugangsdaten waren falsch.</body></html>";
}

if (!isset($_SERVER["PHP_AUTH_USER"])) { // nicht gesetzt
	SendAuth();
	exit(); // Skript beenden
} 
else {

	if (!(($_SERVER["PHP_AUTH_USER"] == "informatik") and 
		  ($_SERVER["PHP_AUTH_PW"] =="comein"))) {

		// Authentifizierung fehlgeschlagen!

		SendAuth();
		exit(); // Skript beenden
	}

}


// -------------------- 
//   gesch�tzte Seite:
// -------------------- 
?>
<!DOCTYPE html>
<html>
<head><title>AUTH-TEST</title></head>
<body>

<h1>Willkommen auf der gesch&uuml;tzten Seite.</h1>

<? 
$user= $_SERVER["PHP_AUTH_USER"];
print "Ihr username ist <B>$user</b> und Ihr Passwort ist zu finden in ";
print '<b>$_SERVER["PHP_AUTH_PW"]</b>';
?> 
</body>
</html>
