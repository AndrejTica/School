<? //COOKIE schon gesetzt ?
if (!isset($_COOKIE["CookieName"])) {

   setcookie("CookieName", "CookieWert", time()+3600*24*30); //30 tage
}

?>

<!DOCTYPE html><head><title>Cookie Test</title></head>
<body>

<?
  print "Das Cookie: CookieName hat den Wert: "; 
  print $_COOKIE["CookieName"];


  //C:Dokumente und Einstellungen\hofmann\Lokale Einstellungen\Temporary Internet Files

  //setcookie("CookieName", "CookieWert", time()-3600); // cookie loeschen

?>

</body>

</html>

