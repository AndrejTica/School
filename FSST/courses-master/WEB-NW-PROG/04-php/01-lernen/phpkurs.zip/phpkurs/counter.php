<?

$filename = "counter.txt";

$fp = fopen($filename, "r+");

$count = fread($fp, filesize($filename));

$count++;

print "Schon $count Besucher waren auf meiner Seite!";

rewind($fp);

fwrite($fp, $count);

fclose($fp);

?>

