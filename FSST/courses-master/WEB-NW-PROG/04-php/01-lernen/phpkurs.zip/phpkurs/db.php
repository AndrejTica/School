<html>
<head><title>DB-Formular</title></head>

<body>
<?
if (!isset($product)){ //Formular aufbauen
?>
	<h1>DEMO: Datenbankzugriff</h1>

	<form action="db.php" method="POST">
	<table>

	<tr><td>Produkt:
	    </td>
	    <td><input type="text" name="product" value= "mysql or mssql">
            </td>
	</tr>
	
	<tr><td>Server:
	    </td>
	    <td><input type="text" name="server"  value= "localhost">
            </td>
	</tr>


	<tr><td>database:
	    </td>
	    <td><input type="text" name="database" value= "schueler or schuelerdb">
            </td>
	</tr>

	<tr><td>table:
	    </td>
	    <td><input type="text" name="table" value= "fragen">
	    </td>
	</tr>

	<tr><td>spalte1:
	    </td>
	    <td><input type="text" name="column1" value= "fragen">
	    </td>
	</tr>
	<tr><td>spalte2:
	    </td>
	    <td><input type="text" name="column2" value= "antwort">
	    </td>
	</tr>

	<tr><td>user:
	    </td>
	    <td><input type="text" name="user" value= "schueler">
	    </td>
	</tr>
	<tr><td>passwd:
	    </td>
	    <td><input type="password" name="passwd" value= "">
	    </td>
	</tr>
	</table>

	<input type="submit" value="OK">
	<input type="reset" value="reset">

	</form>
	<pre> a.hofmann: mysql...database=schueler     mssql...database=schuelerdb
	</pre>
	</body>
	</html>
<? }
else {
	if ($product=="mysql") {
		$link = mysql_connect($server, $user, $passwd);
		$ret=   mysql_select_db($database, $link);
		$res=   mysql_query($a="SELECT ". $column1 .",". $column2 ." FROM " .$table , $link);

		if ($res != false) {
			$n = mysql_affected_rows($link);

			print "<table>";
			print "<tr><td><b>$column1</b></td><td><b>$column2</b></td></tr>";
			
			for ($i=0; $i<$n; $i++) {
				print "<tr><td>";
				print mysql_result($res, $i, $column1);

				print "</td><td>";
				print mysql_result($res, $i, $column2);
	
				print "</td></tr>\n";
			}

		mysql_free_result($res);
		}

		mysql_close($link);

		print "</table>";
	}
	else { //mssql

		$link = mssql_connect($server, $user, $passwd);
		$ret=   mssql_select_db($database, $link);
		$res =  mssql_query("SELECT ". $column1 .",". $column2 ." FROM " .$table , $link);

		if ($res != false) {
			$n = mssql_num_rows($res);

			print "<table>";
			print "<tr><td><b>$column1</b></td><td><b>$column2</b></td></tr>";
		
			for ($i=0; $i<$n; $i++) {
				print "<tr><td>";
				print mssql_result($res, $i, $column1);
	
				print "</td><td>";
				print mssql_result($res, $i, $column2);

				print "</td></tr>\n";

			}

		@mssql_free_result($res);
		}

		mssql_close($link);

		print "</table>";
     }

} // isset?>