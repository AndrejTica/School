<?
$d = dir("download");
while ($entry = $d->read()) {
echo "<a href=\"download/$entry\">$entry</a><br>\n";
}
$d->close();
?>
 
