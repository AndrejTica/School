<!DOCTYPE html>
<html>

<head><title>Erster PHP-Test</title></head>

<body>

<?php print "Hallo Welt!<br>PHP ist super <br>ich kann dassssssssssss!!!"; ?>

</body>

</html>

