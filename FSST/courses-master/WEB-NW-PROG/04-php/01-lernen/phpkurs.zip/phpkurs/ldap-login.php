<?php

if (isset($_POST['username'])){
// Grundlegende Abfolge bei LDAP ist verbinden, binden, suchen,
// interpretieren des Sucheergebnisses, Verbindung schlie�en

echo "<h3>LDAP query Test</h3>";
echo "Verbindung ...";
$ds=ldap_connect("dc-s.htl.org"); // muss ein g�ltiger LDAP Server
// sein!
echo "Ergebnis der Verbindung: ".$ds."<p>";

if ($ds) {
	echo "Bindung ...";
	//$r=ldap_bind($ds); // das ist ein "anonymer" bind,
//	$r=ldap_bind($ds, $_POST['username'],$_POST['passwort']); // bind,
	$r=ldap_bind($ds, $_POST['username'],"?????????????"); // bind,

	// typischerweise nur Lese Zugriff
	echo "Ergebnis der Bindung ".$r."<p>";

	echo "Suche nach " . $_POST['suche'];

	// Suchen des Nachnamen-Eintrags
//geht $sr=ldap_search($ds,"ou=user,dc=htl,dc=org", $_POST['suche']);

	$sr=ldap_search($ds,$_POST['basedn'], $_POST['suche']);
//	$sr=ldap_search($ds,$_POST['basedn'], "sn=*");


	echo "Ergebnis der Suche ".$sr."<p>";

	echo "Anzahl gefundenen Eintr�ge ".ldap_count_entries($ds,$sr)."<p>";

	echo "Eintr�ge holen ...<p>";
	$info = ldap_get_entries($ds, $sr);
	echo "Daten f�r ".$info["count"]." Items gefunden:<p>";

	for ($i=0; $i<$info["count"]; $i++) {
		echo "dn ist: ". $info[$i]["dn"] ."<br>";
		echo "erster cn Eintrag: ". $info[$i]["cn"][0] ."<br>";
		echo "erster email Eintrag: ". $info[$i]["mail"][0] ."<p>";
	}

	echo "Verbindung schlie�en";
	ldap_close($ds);

} 
else {
	echo "<h4>Verbindung zum LDAP Server nicht m�glich</h4>";
}
	

}
else{ //anmelde seite
	?>
	<html>
	<head><title>formular in php</title></head>
	<body>
	<h1>formular in php</h1>

	<form action="ldap-login.php" method="POST">
	<table>
	<tr>
	<td>Username:</td>
	<td><input type="text" name="username" value="win_login@htl.org" size=40></td>
	</tr>

	<tr>
	<td>Passwort:</td>
	<td><input type="password" name="passwort"></td>
	</tr>

	<tr>
	<td>basedn:</td>
	<td><input type="text" name="basedn" value="OU=4HNC, OU=Benutzer, OU=Informatik, DC=EDU,DC=HTL,DC=ORG" size=70></td>
	</tr>

	<tr>
	<td>Suchstring:</td>
	<td><input type="text" name="suche" value="sn=H*"></td>
	</tr>

	</table>

	<input type="submit" value="Abschicken">

	</form>

	</body>
	</html>
	<?
}
?>
