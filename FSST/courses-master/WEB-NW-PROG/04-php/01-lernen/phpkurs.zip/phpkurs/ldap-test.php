<?php
// Grundlegende Abfolge bei LDAP ist verbinden, binden, suchen,
// interpretieren des Sucheergebnisses, Verbindung schlie�en

echo "<h3>LDAP query Test</h3>";
echo "Verbindung ...";
$ds=ldap_connect("dc-z.htl.org"); // muss ein g�ltiger LDAP Server
// sein!
echo "Ergebnis der Verbindung: ".$ds."<p>";

if ($ds) {
echo "Bindung ...";
//$r=ldap_bind($ds); // das ist ein "anonymer" bind,
$r=ldap_bind($ds, "win_login@htl.org","PWD"); // das ist ein bind,

// typischerweise nur Lese Zugriff
echo "Ergebnis der Bindung ".$r."<p>";

echo "Suche nach (sn=S*) ...";
// Suchen des Nachnamen-Eintrags
$sr=ldap_search($ds,"OU=user,dc=htl,dc=org", "sn=S*");
echo "Ergebnis der Suche ".$sr."<p>";

echo "Anzahl gefundenen Eintr�ge ".ldap_count_entries($ds,$sr)."<p>";

echo "Eintr�ge holen ...<p>";
$info = ldap_get_entries($ds, $sr);
echo "Daten f�r ".$info["count"]." Items gefunden:<p>";

for ($i=0; $i<$info["count"]; $i++) {
echo "dn ist: ". $info[$i]["dn"] ."<br>";
echo "erster cn Eintrag: ". $info[$i]["cn"][0] ."<br>";
echo "erster email Eintrag: ". $info[$i]["mail"][0] ."<p>";
}

echo "Verbindung schlie�en";
ldap_close($ds);

} else {
echo "<h4>Verbindung zum LDAP Server nicht m�glich</h4>";
}
?> 
