<?

// Lotto - 6 aus 45

// seed f�r Zufallszahlen setzen

srand ((double) microtime()*1000000);

$i = 0;

$z = array(); // damit foreach funktioniert

do {

$r = rand(1, 45);

// pr�fen ob schon gezogen

foreach ($z as $einz) {

if ($einz == $r) {

// neu ermitteln

continue 2;

}

}

// ins Array aufnehmen

$z[] = $r;

$i++;

} while ($i < 6);

// sortieren

sort($z);

print implode(",", $z);

?>

