<HTML>
<HEAD>
<TITLE>Fragenkatalog (mssql)</TITLE>
</HEAD>
<BODY>

<?php 

// Datenbank verbinden
$myServer = "nbhofa"; 
$myUser = "schueler"; 
$myPass = "schueler"; 
$myDB = "schuelerdb"; 
$s = @mssql_connect($myServer, $myUser, $myPass) or die("Couldn't connect to SQL Server on $myServer"); 

// Datenbank ausw�hlen
$d = @mssql_select_db($myDB, $s) or die("Couldn't open database $myDB"); 

echo "<h2>Fragenkatalog (MSSQL)(A.Hofmann)</h2>";

if (isset($_GET['id'])){
	$query  = "SELECT id,thema,kapitel,frage,antwort,hinweis FROM fragen where id=" . $_GET['id'];
        $result = mssql_query($query); 
 
        echo "<table>";
        
	// Datens�tze holen
        while ($row = mssql_fetch_row($result)) {
          echo "<tr><td color=\"0c0c0c\"><B>Thema:</B></td><td>$row[1]</td></tr>";
          echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
          echo "<tr><td><B>Frage:</B></td><td>$row[3]</td></tr>";
          echo "<tr><td><B>Antwort:</B></td><td><B>$row[4]</b></td></tr>";
          echo "<tr><td><B>Hinweis:</B></td><td>$row[5]</td></tr>";
 
          echo "<tr><td><b><A HREF=\"/htl/mssql/fragen.php\">Zur&uuml;ck</A></td><td>&nbsp;</td></tr>";
         }

        echo "</table>";

}
else {
	// Datenbank abfragen
	$query= "SELECT id,thema,kapitel,frage FROM fragen order by thema,kapitel,frage";
        $result = mssql_query($query); 
 
        echo "<table>";
        
	// Datens�tze holen
        while ($row = mssql_fetch_row($result)) {
          echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
          echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
          echo "<tr><td><B>Frage:</B></td><td><A HREF=\"/htl/mssql/fragen.php?id=$row[0]\">$row[3]</A></td></tr>";
         }

        echo "</table>";

}
$numRows = mssql_num_rows($result); 
echo "<hr>" . $numRows . " Row" . ($numRows == 1 ? "" : "s") . " Returned <br>"; 
echo $query;

?>
</BODY>
</HTML>
