<HTML>
<HEAD>
<TITLE>mssql_fragen</TITLE>
</HEAD>
<BODY>

<?php 

$myServer = "nbhofa"; 
$myUser = "sa"; 
$myPass = "mssql"; 
$myDB = "Northwind"; 

$s = @mssql_connect($myServer, $myUser, $myPass) or die("Couldn't connect to SQL Server on $myServer"); 

//echo $s ." =rueck von connect";

$d = @mssql_select_db($myDB, $s) 
or die("Couldn't open database $myDB"); 

$query = "SELECT TitleOfCourtesy+' '+FirstName+' '+LastName AS Employee "; 
$query .= "FROM Employees "; 
$query .= "WHERE Country='USA' AND Left(HomePhone, 5) = '(206)'"; 

$result = mssql_query($query); 
$numRows = mssql_num_rows($result); 

echo "<h1>" . $numRows . " Row" . ($numRows == 1 ? "" : "s") . " Returned </h1>"; 

while($row = mssql_fetch_array($result)) 
{ 
echo "<li>" . $row["Employee"] . "</li>"; 
} 

// ------------------------------------
$query = "SELECT test, vorname,nachname from vmysql "; 
mssql_query(" SET ANSI_NULLS ON"); 
mssql_query("SET ANSI_WARNINGS ON"); 

$result = mssql_query($query); 
$numRows = mssql_num_rows($result); 

echo "<h1>" . $numRows . " Row" . ($numRows == 1 ? "" : "s") . " Returned </h1>"; 

while($row = mssql_fetch_array($result)) 
{ 
echo "<li>" . $row["test"] .$row["vorname"] .$row["nachname"] . "</li>"; 
} 



?> 
   </BODY>
   </HTML>
