<?php

print $_REQUEST["vorname"] . " " . $_REQUEST["nachname"] ;

?>

