﻿<?php
// myform2.php

if ( ! isset($_REQUEST["name"])){
// Formular aufbauen
?>
	<!DOCTYPE html>
	<head><title>Formular</title></head>
	<body>
	<h1>Formular</h1>
	<form  method="POST" action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	Name: <input type="text" name="name" placeholder="mustermann"> <br>
	E-mail: <input type="text" name="email" value="max@mustermann"> <br>
	Website: <input type="text" name="website" value="http://mustermann.at"> <br>
	Comment: <textarea name="comment" rows="5" cols="40">hier steht noch nichts</textarea> <br>

	Gender:
	<input type="radio" name="gender" value="female">Female
	<input type="radio" name="gender" value="male" checked>Male<br>
	<input type="submit" value="Abschicken">
	</form>
	</body>
	</html>

	<?php
}
else {
	// Usereingaben verarbeiten

	// define variables and set to empty values
	$name = $email = $gender = $comment = $website = "";
	function test_input($data){
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}

	if ($_SERVER["REQUEST_METHOD"] == "POST"){
	  $name = test_input($_POST["name"]);
	  $email = test_input($_POST["email"]);
	  $website = test_input($_POST["website"]);
	  $comment = test_input($_POST["comment"]);
	  $gender = test_input($_POST["gender"]);

	?>
	<!--  Ausgabe -->
		<!DOCTYPE html>
	<head><title>Formular</title></head>
	<body>
	<h1>Usereingaben</h1>

	<?php
	print "<br>Name: $name";
	print "<br>Email: $email";
	print "<br>Website: $website";
	print "<br>Comment: $comment";
	print "<br>Gender: $gender";
	?>
	
	</body>
	</html>

	<?php
	}
}
?>
