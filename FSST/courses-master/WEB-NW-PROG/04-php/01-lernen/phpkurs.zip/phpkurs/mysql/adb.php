<HTML>
<HEAD>
<TITLE>Adressbuch(php und mysql)</TITLE>
</HEAD>
<BODY bgcolor="cccccc">
<h1>Adressbuch (php und mysql A.Hofmann)</h2>
[<a href="adb-save-sql.php">Save as SQL</a>]

<?
// 
// lISTPage
//

// Datenbank verbinden: host, user, pwd
$cn= mysql_connect("localhost", "schueler", "comein");      
// Datenbank auswaehlen
$db= mysql_select_db("schueler", $cn) or die("Fehler beim öffnen der Datenbank schueler");


// Datenbank abfragen
$result = mysql_query("SELECT nickname,email,comment FROM schueler.adb order by nickname",$cn); 
 
echo "<table border=\"1\" cellspacing=\"0\">";
echo "<tr>";
echo "<td><B>TODO</B></td>";
echo "<td><B>Nickname:</B></td>";
echo "<td><B>Email:</B></td>";
echo "<td><B>Comment:</B></td>";
echo "</tr>";

// Datens�ze holen
while ($row = mysql_fetch_row($result)) {
	echo "<tr>";
	echo "<td>[<a href=\"\">del</a>]</td>";
	echo "<td>$row[0]</td>";
	echo "<td>$row[1]</td>";
	echo "<td>$row[2]</td>";
	echo "</tr>";
}

//while ($row = mysql_fetch_row($result)) {
//	echo "<tr><td><B>Nickname:</B></td><td>$row[0]</td></tr>";
//	echo "<tr><td><B>Email:</B></td><td>$row[1]</td></tr>";
//	echo "<tr><td><B>Comment:</B></td><td>$row[2]</td></tr>";
//}

echo "</table>";
mysql_free_result($result);
mysql_close($cn);
?>
</BODY>
</HTML>
