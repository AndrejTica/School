<HTML>
<HEAD>
<TITLE>Fragenkatalog (mysql)</TITLE>
<style>
table {backcolor:red}
</style>
</HEAD>
<BODY>

<?
// Datenbank verbinden
@mysql_connect("localhost", "schueler", "comein");      

// Datenbank ausw�hlen
$link= mysql_select_db("schueler") or die("Fehler beim �ffnen der Datenbank");


echo "<h2>Fragenkatalog (A.Hofmann)</h2>";


if (isset($_GET['id'])) { 
// 
// FormularPage
//
        $result = mysql_query("SELECT id,thema,kapitel,frage,antwort,hinweis FROM fragen where id=" . $_GET['id']); 
 
 		echo "<form action=\"fragen-edit.php\" method=\"POST\">";
		echo "<input type=\"hidden\" name=\"id\" value=\"" . $_GET['id'] . "\">";
		
        echo "<table>";
        
		// Datens�tze holen
         while ($row = mysql_fetch_row($result)) {

   			echo "<tr><td><B>Thema:</B></td><td><input type=\"text\" name=\"thema\" value=\"$row[1]\" size=120></td></tr>";
	        echo "<tr><td><B>Kapitel:</B></td><td><input type=\"text\" name=\"kapitel\" value=\"$row[2]\" size=120></td></tr>";
	        echo "<tr><td><B>Frage:</B></td><td><input type=\"text\" name=\"frage\" value=\"$row[3]\" size=120></td></tr>";
	        echo "<tr><td><B>Antwort:</B></td><td><textarea rows=\"8\" cols=\"90\" name=\"antwort\">$row[4]</textarea></td></tr>";
	        echo "<tr><td><B>Hinweis:</B></td><td><textarea rows=\"8\" cols=\"90\" name=\"hinweis\">$row[5]</textarea></td></tr>";

	        echo "<tr><td><input type=\"submit\" value=\"Speichern\"></td><td><input type=\"reset\" value=\"Reset\"></td></tr>";

	 		echo "<tr><td><b><A HREF=\"fragen.php\">Zur&uuml;ck</A></td>";
	 		echo "<td>&nbsp;</td></tr>";
         }

         echo "</table>";
         echo "</form>";
}
else{
// 
// ActionPage
//
        
	// Datenbank updaten
         $result = mysql_query("update fragen set thema='$thema',kapitel='$kapitel',frage='$frage', antwort='$antwort', hinweis='$hinweis' where id=$id"); 
 
        echo "update fragen set thema='$thema',kapitel='$kapitel',frage='$frage', antwort='$antwort', hinweis='$hinweis' where id=$id";
        
        echo "<br>" . mysql_error();
        echo "<hr>";

        $result = mysql_query("SELECT id,thema,kapitel,frage,antwort,hinweis FROM fragen where id=$id");         
  
	// Datens�tze holen
         
         echo "<table>";

         while ($row = mysql_fetch_row($result)) {
	         echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
	         echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
	         echo "<tr><td><B>Frage:</B></td><td><A HREF=\"fragen.php?id=$row[0]\">$row[3]</A></td></tr>";
	         echo "<tr><td><B>Antwort:</B></td><td>$row[4]</A></td></tr>";
	         echo "<tr><td><B>Hinweis:</B></td><td>$row[5]</td></tr>";
         }

		echo "<tr><td><b><A HREF=\"fragen-edit.php?id=$id\">Edit</A></td>";
		echo "<td><b><A HREF=\"fragen.php\">Zur&uuml;ck</A></td>";
 		echo "</tr>";


        echo "</table>";

}

// Datenbank schliessen
mysql_close();

         ?>
   </BODY>
   </HTML>
