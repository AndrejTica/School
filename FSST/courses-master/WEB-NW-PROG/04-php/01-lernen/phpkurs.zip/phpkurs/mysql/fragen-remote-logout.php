<?php
session_start();


	unset($_SESSION['host']);
	unset($_SESSION['user']);
	unset($_SESSION['password']);
	unset($_SESSION['db']);
	

	session_destroy();
?>