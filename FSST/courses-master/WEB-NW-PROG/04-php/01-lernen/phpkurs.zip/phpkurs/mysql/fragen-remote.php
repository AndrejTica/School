<?php
session_start();
?>

<HTML>
<HEAD>
<TITLE>Fragenkatalog (mysql)</TITLE>
</HEAD>
<BODY>


<?php
if (isset($host)) {
	$_SESSION['host']= $host;
	$_SESSION['user']= $user;
	$_SESSION['password']= $password;
	$_SESSION['db']= $db;
}

if (!isset($_SESSION['host'])) {

	?>
	<h1>Fragenkatalog</h1>
	
	<form action="fragen-remote.php" METHOD="POST">
	<table border="1">
	<tr>
	<td>HOST: 
	</td>
	<td>
	<input type="text" name="host" value="localhost" size="60">
	</td>
	</tr>
	<tr>
	<td>USER: 
	</td>
	<td>
	<input type="text" name="user" value="schueler" size="60">
	</td>
	</tr>
	
	<tr>
	<td>PASSWORD: 
	</td>
	<td>
	<input type="password" name="password" value="" size="60">
	</td>
	</tr>
	
	<tr>
	<td>DB: 
	</td>
	<td>
	<input type="text" name="db" value="schueler" size="60">
	</td>
	</tr>
	
	<tr>
	<td>GO: 
	</td>
	<td>
	<input type="submit" name="submit" value="abschicken" size="60">
	</td>
	</tr>
	
	</form>
	
	</table>

	<?php
	exit();
	

}
?>



<?

echo "Connected To: " .$_SESSION['host'] . "/" . $_SESSION['user']  . "/*****" .  "/" . $_SESSION['db'];
echo "<br><a href=\"fragen-remote-logout.php\">logout</a>";

// Datenbank verbinden
@mysql_connect($_SESSION['host'], $_SESSION['user'], $_SESSION['password']) or die("Fehler beim Connect zum Server");      

// Datenbank ausw�hlen
$link= mysql_select_db($_SESSION['db']) or die("Fehler beim �ffnen der Datenbank");


echo "<h2>Fragenkatalog (A.Hofmann)</h2>";


if (isset($_GET['id'])) { 
// 
// AntwortPage
//
        $result = mysql_query("SELECT id,thema,kapitel,frage,antwort,hinweis FROM fragen where id=" . $_GET['id']); 
 
 
        echo "<table>";
        
		// Datens�tze holen
         while ($row = mysql_fetch_row($result)) {

   			echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
	        echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
	        echo "<tr><td><B>Frage:</B></td><td>$row[3]</td></tr>";
	        echo "<tr><td><B>Antwort:</B></td><td>$row[4]</td></tr>";
	        echo "<tr><td><B>Hinweis:</B></td><td>$row[5]</td></tr>";

	 		echo "<tr><td><b><A HREF=\"fragen-remote.php\">Zur&uuml;ck</A></td>";
	 		echo "<td><A HREF=\"fragen-remote-edit.php?id=$row[0]\">Edit&nbsp;</td></tr>";
         }

         echo "</table>";

}
else{
// 
// FragenPage
//
        
	// Datenbank abfragen
         $result = mysql_query("SELECT id,thema,kapitel,frage FROM fragen order by thema, kapitel, frage"); 
 
        echo "<table>";
        
	// Datens�tze holen
         while ($row = mysql_fetch_row($result)) {
         echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
         echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
         echo "<tr><td><B>Frage:</B></td><td><A HREF=\"fragen-remote.php?id=$row[0]\">$row[3]</A></td></tr>";
         }

        echo "</table>";

}
         ?>
   </BODY>
   </HTML>
