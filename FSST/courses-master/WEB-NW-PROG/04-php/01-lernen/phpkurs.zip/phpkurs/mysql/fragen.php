<HTML>
<HEAD>
<TITLE>Fragenkatalog (mysql)</TITLE>
</HEAD>
<BODY>

<?
// Datenbank verbinden
@mysql_connect("localhost", "schueler", "comein");      

// Datenbank ausw�hlen
$link= mysql_select_db("schueler") or die("Fehler beim �ffnen der Datenbank");


echo "<h2>Fragenkatalog (A.Hofmann)</h2>";


if (isset($_GET['id'])) { 
// 
// AntwortPage
//
        $result = mysql_query("SELECT id,thema,kapitel,frage,antwort,hinweis FROM fragen where id=" . $_GET['id']); 
 
 
        echo "<table>";
        
		// Datens�tze holen
         while ($row = mysql_fetch_row($result)) {

   			echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
	        echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
	        echo "<tr><td><B>Frage:</B></td><td>$row[3]</td></tr>";
	        echo "<tr><td><B>Antwort:</B></td><td>$row[4]</td></tr>";
	        echo "<tr><td><B>Hinweis:</B></td><td>$row[5]</td></tr>";

	 		echo "<tr><td><b><A HREF=\"fragen.php\">Zur&uuml;ck</A></td>";
	 		echo "<td><A HREF=\"fragen-edit.php?id=$row[0]\">Edit&nbsp;</td></tr>";
         }

         echo "</table>";

}
else{
// 
// FragenPage
//
        
	// Datenbank abfragen
         $result = mysql_query("SELECT id,thema,kapitel,frage FROM fragen order by thema, kapitel, frage"); 
 
        echo "<table>";
        
	// Datens�tze holen
         while ($row = mysql_fetch_row($result)) {
         echo "<tr><td><B>Thema:</B></td><td>$row[1]</td></tr>";
         echo "<tr><td><B>Kapitel:</B></td><td>$row[2]</td></tr>";
         echo "<tr><td><B>Frage:</B></td><td><A HREF=\"fragen.php?id=$row[0]\">$row[3]</A></td></tr>";
         }

        echo "</table>";

}
         ?>
   </BODY>
   </HTML>
