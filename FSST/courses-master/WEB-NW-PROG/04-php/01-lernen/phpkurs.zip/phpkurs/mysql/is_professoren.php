﻿<?php
// is_professoren.php

$conn= mysql_connect("localhost", "is_uni","comein") or
                               die("Verbindungsversuch fehlgeschlagen");
mysql_select_db("is_uni", $conn) or 
                die("Konnte die Datenbank nicht waehlen.");
$sql    = "SELECT persnr, name FROM is_uni.is_professoren";
$query  = mysql_query($sql) or die("Anfrage nicht erfolgreich");
$anzahl = mysql_num_rows($query);
echo "Anzahl der Datensätze: $anzahl";
?>
<table border="1"><tr><td>PERSNR</td><td>NAME</td></tr>
<?php
while ($row = mysql_fetch_array($query)){
   print "<tr><td>";
   print $row['persnr'] . "</td>";
   print "<td>" . $row['name'] . "</td></tr>";
}
print "</table>";
?>
