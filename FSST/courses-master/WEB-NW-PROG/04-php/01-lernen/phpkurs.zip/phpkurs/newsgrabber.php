<?
// newsgrabber.php
// F�r PHP5 und h�her
$url = fopen("http://www.heise.de/newsticker/", "r");
$news = stream_get_contents($url);
fclose($url);


$news = strstr($news, "<h1>7-Tage-News</h1>"); // start von news
$end = strpos($news, "<p class=\"weitere\">"); // ende
$news = substr($news, 0, $end);

// Links reparieren
$news = str_replace("=\"/", "=\"http://www.heise.de/", $news);

print $news;

?>

/* HINWEIS:
string substr (string string, int start [, int length])
    Substr() gibt den Teil von string zur�ck, der durch die start und length Parameter 
    definiert wurde. 


int strpos (string haystack, string needle [, int offset])
    Gibt als numerischen Wert die Position des ersten Vorkommens von needle 
    innerhalb der Zeichenkette haystack zur�ck. 

*/