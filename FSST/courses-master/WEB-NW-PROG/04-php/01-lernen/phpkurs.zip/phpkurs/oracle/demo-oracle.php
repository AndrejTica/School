<html>
<body>

<?php
print "<PRE>";
$db = "";

$c1 = ocilogon("schueler","comein",$db);
$c2 = ocilogon("schueler","comein",$db);

function create_table($conn)
{ $stmt = ociparse($conn,"create table schueler.hallo (test
varchar2(64))");
  ociexecute($stmt);
  echo $conn." created table\n\n";
}

function drop_table($conn)
{ $stmt = ociparse($conn,"drop table schueler.hallo");
  ociexecute($stmt);
  echo $conn." dropped table\n\n";
}

function insert_data($conn)
{ $stmt = ociparse($conn,"insert into schueler.hallo values('$conn' || ' ' || to_char(sysdate,'DD-MON-YY HH24:MI:SS'))");
  ociexecute($stmt,OCI_DEFAULT);
  echo $conn." inserted hallo\n\n";
}

function delete_data($conn)
{ $stmt = ociparse($conn,"delete from schueler.hallo");
  ociexecute($stmt,OCI_DEFAULT);
  echo $conn." deleted hallo\n\n";
}

function commit($conn)
{ ocicommit($conn);
  echo $conn." commited\n\n";
}

function rollback($conn)
{ ocirollback($conn);
  echo $conn." rollback\n\n";
}

function select_data($conn)
{ $stmt = ociparse($conn,"select * from schueler.hallo");
  ociexecute($stmt,OCI_DEFAULT);
  echo $conn."----selecting\n\n";
  while (ocifetch($stmt))
    echo $conn." <".ociresult($stmt,"TEST").">\n\n";
  echo $conn."----done\n\n";
}

create_table($c1);
insert_data($c1);   // tr�gt eine Zeile ein und benutzt dabei c1
insert_data($c2);   // tr�gt eine Zeile ein und benutzt dabei c2

select_data($c1);   // die Ergebnisse beider Eintragungen wird zur�ckgegeben
select_data($c2);   

rollback($c1);      // Rollback benutzt c1

select_data($c1);   // ein Rollback auf beide Eintragungen
select_data($c2);   

insert_data($c2);   // tr�gt eine Zeile ein und benutzt dabei c2
commit($c2);        // der commit f�r c2

select_data($c1);   // das Ergebnis der Eintragung �ber c2 wird zur�ckgegeben

delete_data($c1);   // l�schen aller Zeilen �ber c1
select_data($c1);   // keine Zeile zur�ckgegeben
select_data($c2);   // keine Zeile zur�ckgegeben
commit($c1);        // commit f�r c1

select_data($c1);   // keine Zeile zur�ckgegeben
select_data($c2);   // keine Zeile zur�ckgegeben


drop_table($c1);
print "</PRE>";
?>

</body>
</html>