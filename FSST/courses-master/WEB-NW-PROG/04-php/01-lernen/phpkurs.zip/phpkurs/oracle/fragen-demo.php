<html>
<body>
<?php
// fragen-demo.php
		$db = ocilogon("schueler","comein");
		$stmt = ociparse($db,"select * from fragen where thema='SQL'");

		ociexecute($stmt);

		echo "<table border=1 cellspacing=0>";
		echo "<tr><td><b>FRAGE</b></td><td><b>ANTWORT</b></td></tr>";
		while (ocifetch($stmt)) {
			echo "<tr><td>";
			echo ociresult($stmt,"FRAGE");   // muss gross geschrieben sein
			echo "</td><td>";
			echo ociresult($stmt,"ANTWORT");
			echo "</td></tr>";
		}
		echo "</table>";
	?>
</body>
</html>
