<?php

function parseToXML($htmlStr) 
{ 
$xmlStr=str_replace('<','&lt;',$htmlStr); 
$xmlStr=str_replace('>','&gt;',$xmlStr); 
$xmlStr=str_replace('"','&quot;',$xmlStr); 
$xmlStr=str_replace("'",'&apos;',$xmlStr); 
$xmlStr=str_replace("&",'&amp;',$xmlStr); 
return $xmlStr; 
} 


// Opens a connection to a SQL server
$db = "";

$connection = ocilogon("is_uni","comein",$db);
if (!$connection) {
  die('Not connected : ' . mysql_error());
}


$stmt = ociparse($connection,"select * from is_uni.adbmap");
ociexecute($stmt,OCI_DEFAULT);





header("Content-type: text/xml");

// Start XML file, echo parent node
echo '<markers>';

// Iterate through the rows, printing XML nodes for each
while (ocifetch($stmt))
{
  echo '<marker ';
  
  echo 'nickname="' . parseToXML(ociresult($stmt,"NICKNAME")) . '" ';
  echo 'address="' . parseToXML(ociresult($stmt,"ADDRESS")) . '" ';
  echo 'lat="' . parseToXML(ociresult($stmt,"LAT")) . '" ';
  echo 'lng="' . parseToXML(ociresult($stmt,"LNG")) . '" ';

  echo '/>';
}
  

// End XML file
echo '</markers>';

?>
