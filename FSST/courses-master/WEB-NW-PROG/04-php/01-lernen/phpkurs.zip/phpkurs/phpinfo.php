<!DOCTYPE html>
<head><title>Erster PHP-Test</title></head>
<body>

<?php 
  phpinfo(); 
?>

</body>
</html>