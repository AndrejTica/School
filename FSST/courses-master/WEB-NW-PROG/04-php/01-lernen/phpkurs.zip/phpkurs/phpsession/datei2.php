<?php
session_start();
// MUSS IMMER am Beginn stehen
require('./functions.php');
check_login();
?>


	<html>
	<head>
  	<title>PHP: SESSION LOGIN</title>
	</head>
	<body bgcolor="0xffccbb">

	<h1>eine zweite html-Datei </h1>
	Diese Seite konnte nur mit korrekter Anmeldung gelesen werden!!!
	
	<ul>
	<li> <a href="einedatei.php">einedatei.php</a></li>
	<li> <a href="index.php">index.php</a></li>
	<li> <a href="datei2.php">datei2.php</a></li>
	</ul>
	
	<p>
	Zur Kontrolle:<br>
	
	user= <?php echo $_SESSION['user'] . "<br>"; ?>
	pw= <?php echo $_SESSION['pw'] ."<br>"; ?>
	

	<hr>
	<a href="logout.php">logout</a>
</body>
</html>
