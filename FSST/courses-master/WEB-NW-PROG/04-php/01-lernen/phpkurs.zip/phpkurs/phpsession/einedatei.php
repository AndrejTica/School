<?php
session_start();
// MUSS IMMER am Beginn stehen
require('./functions.php');
check_login();
?>


	<html>
	<head>
  	<title>PHP: SESSION LOGIN</title>
	</head>
	<body bgcolor="0xffccbb">

	<h1>eine html-Datei </h1>
	Diese Seite konnte nur mit korrekter Anmeldung gelesen werden!!!
	
	<p>
	Zur Kontrolle:<br>
	
	user= <?php echo $_SESSION['user'] . "<br>"; ?>
	pw= <?php echo $_SESSION['pw'] ."<br>"; ?>
	

	<hr>
	<a href="logout.php">logout</a>
</body>
</html>
