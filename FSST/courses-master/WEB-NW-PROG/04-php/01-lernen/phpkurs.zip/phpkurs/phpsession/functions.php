<?php

// DB erzeugen: siehe schuelerdb.sql
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


// ____________________________________________________________________________________
// name:          loginform()
//
// description:   Erstellt die Login-Page (<form>....</form>)
//                Benutzt im action-Attribut: $PHP_SELF
//                   
// in:   
//
// out:  
// ____________________________________________________________________________________
function loginform() {
$loginform = '<html><html><head><title>PHP: SESSION LOGINFORM</title></head>';
$loginform .= '<body bgcolor="0xffccbb">';
	
$loginform .= '<h1>Login: php-Session mit User/PWD in Mysql</h1>';
$loginform .= 'localhost.schuelerdb.user(user,pw)<br>';

$loginform .= '<form action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" method="POST">';
$loginform .= '<table cellspacing="2" cellpadding="0" border="1">';
$loginform .= '<tr>';
$loginform .= '<td>Benutzer </td>';
$loginform .= '<td><input type="Text" name="user" value="" size="15"; maxlength="20"></td>';
$loginform .= '</tr>';
$loginform .= '<tr>';
$loginform .= '<td>Kennwort </td>';
$loginform .= '<td><input type="Password" name="pw" value="" size="15" maxlength="20"></td>';
$loginform .= '</tr>';
$loginform .= '<tr>';
$loginform .= '<td><input type="Submit" name="" value="Senden"> </td>';
$loginform .= '<td><input type="reset" value="reset"> </td>';
$loginform .= '</tr>';
$loginform .= '</table>';
$loginform .= '</form></body></html>';

print $loginform;

}



// ____________________________________________________________________________________
// name:          logout
//
// description:   l�scht die session-Variablen und zerst�rt die aktive session
//                   
// in:            
//
// out:           
// ____________________________________________________________________________________
function logout() {
  
	unset($_SESSION['logged_in']);
	unset($_SESSION['user']);
	unset($_SESSION['pw']);

	session_destroy();
  }




// ____________________________________________________________________________________
// name:          check_user_in_db
//
// description:   �berpr�ft user, und password in Mysql-DB
//                   
//
// in:            $_SESSION['user'], $_SESSION['pw']
//
// out:           setzt $_SESSION['logged_in'] und liefert true
//                oder
//                liefert false
// ____________________________________________________________________________________
function check_user_in_db() {
	
	mysql_connect("localhost", "schueler", "comein") or die("ERROR: CONNECT to MYSQL");
	$link= mysql_select_db("schuelerdb");

	$sql = "SELECT user, pw FROM user where user='".$_SESSION['user']."'";
   	$r_user = mysql_query($sql);

	if( mysql_num_rows($r_user) > 0 ){

        	$result = mysql_fetch_array($r_user);

     		if( $result['pw'] == $_SESSION['pw'] AND $result['user'] == $_SESSION['user']){

			        $_SESSION['logged_in']=true;
            		return true;
        	}
        	else {
            		return false;
        	}
    } 
    else
    	return false;
    	
} 


// ____________________________________________________________________________________
// name:          check_login
//
// description:   �berpr�ft,
//                ob user und pwd gerade im Login-Formular eingegeben wurden
//                ob noch nicht einmal das Login-Formular angezeigt wurde
//                ob bereits angelemdet
//                   
//
// in:            $_SESSION['user'], $_SESSION['pw']
//
// out:           setzt $_SESSION['logged_in'] und liefert true
//                oder
//                liefert false
// ____________________________________________________________________________________
function check_login() {

// ________________________
// komme vom login-formular
// ________________________
if (isset($_SESSION['logged_in']) == false and isset($_POST['user'])==true ){
	
	// setze Session-Variablen: user, pw
	$_SESSION['user'] = $_POST['user'];
	$_SESSION['pw'] = $_POST['pw'];

	// pr�fe, ob richtiger Benutzername und Passwort
	if (check_user_in_db() == false) {
	        $_SESSION['user'] = '';
        	$_SESSION['pw'] = '';
        	echo '<h3>Falscher Benutzername oder Passwort</h3>';
        	echo '<blockquote>Ein Tipp: guest/guest</blockquote>';
        	

        	loginform();
        	exit(1);
	}
}

// ______________________________
// oder bin noch nicht angemeldet
// ______________________________
elseif (isset($_SESSION['logged_in']) == false ){   

	loginform();
    exit(1);
}
// ___________________________
// oder bin bereits angemeldet
// ___________________________
elseif (isset($_SESSION['logged_in'])==true) {
	return;
}

}


?>
