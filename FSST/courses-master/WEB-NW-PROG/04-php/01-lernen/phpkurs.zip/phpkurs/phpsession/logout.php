<?php
session_start();
require('./functions.php');
logout();
?>


	<html>
	<head>
  	<title>PHP: SESSION LOGOUT</title>
	</head>
	<body bgcolor="0xffccbb">
	
	<h3>Bye!!!</h3>
</body>
</html>
