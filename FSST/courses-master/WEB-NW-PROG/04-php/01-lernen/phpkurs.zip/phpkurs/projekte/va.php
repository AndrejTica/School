<!-- BEGIN ----Veranstaltungskalender------------------------------- Veranstaltungskalender -->
<!-- Anton Hofmann -->
<!------ HEUTE     MORGEN    Balken ------->
<TABLE width=100%><TR>
<TD bgcolor="#FFD17E"><FONT FACE="Arial,Helvetica,Geneva" size=-2 color="#002A4C">
<B>HEUTE <?php print date('d.m.'); ?></B></FONT></TD><TD bgcolor="#FFD17E">
<FONT FACE="Arial,Helvetica,Geneva" size=-2 color="#002A4C">
<B>MORGEN <?php print date("d.m.",mktime(0,0,0,date("m"), date("d")+1,date("Y"))) ; ?> 
</B></FONT></TD></TR>
<TR align=top><TD valign=top><FONT FACE="Arial,Helvetica,Geneva" size=-2 color="#002A4C">


<!--------HEUTE  SPALTE -------------------------------->
<?php $conn = Ora_Logon("dbstart@db1", "dbstart2000");
$curs = ora_open($conn);
ora_commitoff($conn);

$query_heute = sprintf("select zeit, titel, id from va_veranstaltungen where to_char(datum, 'DD.MM.YYYY') = to_char(sysdate,'DD.MM.YYYY') order by zeit");
ora_parse($curs, $query_heute);
ora_exec($curs);

$ncols = ora_numcols($curs);
while (ora_fetch($curs))
  {
   $i=0;
   while($i<$ncols-1) {
 	$zeit= ora_getcolumn($curs,$i);
	$i++;
	$titel= ora_getcolumn($curs,$i);
	$i++;
	$id= ora_getcolumn($curs,$i);
	print "<FONT color=\"gray\">"; 
	print "$zeit    "; 
	print "<A HREF=\"http://db1.sbg.ac.at:6711/webdb/";
	print "dbstart.RPT_VA_kurz.show?p_arg_names=va_veranstaltungen.id&p_arg_values=$id\">";
	print "$titel"; 
	print "</FONT></A><br>";
   }
 }
ora_close($curs);ora_logoff($conn);
?>
</FONT></TD>
<TD valign=top><FONT FACE="Arial,Helvetica,Geneva" size=-2 color="#002A4C">


<!------------ MORGEN SPALTE --------------------------------------->
<?php 
$conn = Ora_Logon("dbstart@db1", "dbstart2000");
$curs = ora_open($conn);
ora_commitoff($conn);
$query = sprintf("select zeit, titel, id from va_veranstaltungen where to_char(datum, 'DD.MM.YYYY') = to_char(sysdate+1, 'DD.MM.YYYY') order by zeit");

ora_parse($curs, $query);
ora_exec($curs);

$ncols = ora_numcols($curs);
while (ora_fetch($curs))
  {
   $i=0;
   while($i<$ncols-1) {
	$zeit= ora_getcolumn($curs,$i);
	$i++;
	$titel= ora_getcolumn($curs,$i);
	$i++;
	$id= ora_getcolumn($curs,$i);
	print "<FONT color=\"gray\">"; 
	print "$zeit    "; 
	print "<A HREF=\"http://db1.sbg.ac.at:6711/webdb/";
	print "dbstart.RPT_VA_kurz.show?p_arg_names=va_veranstaltungen.id&p_arg_values=$id\">";
	print "$titel"; 
	print "</FONT></A><br>";
   }
 }
ora_close($curs);ora_logoff($conn);
?>
</FONT></TD></TR>
</TABLE>
<!-- END ----Veranstaltungskalender---------------------------------- Veranstaltungskalender -->
<!-- Anton Hofmann -->