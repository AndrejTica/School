<?php
$num = array(0,10,15,20,35,23);
$mixed = array(
"dbhost" => "localhost",
"dbuser" => "root",
"dbpass" => "",
15 => "test"
);

// count ermittelt die Anzahl der Elemente eines Arrays.
for ($i=0; $i<count($num); $i++) {
	print "num[$i] = ".$num[$i]."<br>";
}

print "<br><br>";
foreach ($mixed as $k => $v) {
	print "$k => $v<br>";
}

print "<br><br>";
reset($mixed);
while (list($k,$v) = each($mixed)) {
print "$k => $v<br>";
}

print "<br><br>";
$arr = array(0,15,56);
array_push($arr, 25, array(0,25,3), 67);
print_r($arr);
?>