<!DOCTYPE html>
<html><Head><title>PHP-demo</title></head>
<body>

<h1>PHP-demo: Upload</h1>


<?php

$temp= $_FILES['thefile']['tmp_name'];
$file= $_FILES['thefile']['name'];

if (!move_uploaded_file( $temp, "upload/$file")) {
	print "Datei ung&uuml;tig oder zu gross.";
}
else {
	$d = dir("upload");
	while ($entry = $d->read()) {
		echo "<a href=\"upload/$entry\">$entry</a><br>\n";
	}
	$d->close();
}

?>
</body>
</html>
