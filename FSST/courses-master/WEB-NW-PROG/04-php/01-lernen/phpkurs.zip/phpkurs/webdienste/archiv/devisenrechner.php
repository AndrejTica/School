Quelltext der Datei: ./tag5/soap/devisenrechner.php

Dateigr�sse: 1.59 kb

[Anzeige mit Zeilennummern]

<?php
require_once 'aufklapp.php';
$country1 = isset($_POST['country1']) ? $_POST['country1'] : 'Switzerland';
$country2 = isset($_POST['country2']) ? $_POST['country2'] : '';
$betrag   = isset($_POST['betrag']) ? $_POST['betrag'] : 100;
$kurs = '';
$search_result = '';
if ($country1 != '' && $country2 != '')
{
    try
    {
        $wechselkurs = new SoapClient("http://www.xmethods.net/sd/2001/CurrencyExchangeService.wsdl", array('trace' => 1));
    
        $parameters = array(
            'country1'     => $country1,    
            'country2'     => $country2,    
            );   
        $kurs = $wechselkurs->__call("getRate", $parameters, array(''));    
    }
    catch (SoapFault $ex)
    {
        echo "Fehler bei der Verbindung: {$ex->faultstring}";
    }
}
?>
<h2>SOAP-Devisenrechener</h2>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
Betrag:<br />
<input type="text" name="betrag" value="<?php echo $betrag; ?>"/><br /><br />
<?php
$waehrungen = array('Canada'=>'Canada Dollar CAD',
                    'Switzerland'=>'Schweizer Franken CHF',
                    'Euro'=>'Euro EUR',
                    'UK'=>'Britisches Pfund GBP',
                    'Japan'=>'Japanischer Yen JPY',
                    'Sweden'=>'Schwedische Krone SEK',
                    'USA'=>'US Dollar USD'
                    );
$menu = & new AufklappMenu($country1, $waehrungen, 'country1');
echo 'Von: '.$menu->erzeugeMenu();
$menu = & new AufklappMenu($country2, $waehrungen, 'country2');
echo ' nach: '.$menu->erzeugeMenu();
?>
    <br /><br />
    <input type="submit" value=" Berechnen "/>
</form>
<br />
<?php
if ($kurs != '')
{
    echo $betrag.' '.$waehrungen[$country1].' = '.($kurs*$betrag).' '.$waehrungen[$country2];
    echo '<br />Wechselkurs: '.$kurs;
}
?>

