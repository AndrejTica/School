<?php
$client = new SOAPClient('http://api.google.com/GoogleSearch.wsdl');
 
try {
  $result = $client->doGoogleSearch(
    '1KpT5iFQFHJprYWf4uLyV9taCtuFTG17',
    'Professionelle Softwareentwicklung mit PHP 5',
    0,
    1
  );
 
  foreach ($result->resultElements as $resultElement) {
    print $resultElement->URL;
  }
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>

