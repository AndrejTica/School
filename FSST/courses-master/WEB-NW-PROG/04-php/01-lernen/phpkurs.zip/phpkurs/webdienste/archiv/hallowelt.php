<?php
class Webdienst {
  public function hallowelt($inputString) {
    return 'Hallo Welt: ' . $inputString;
  }
}
 
try {
  $server = new SOAPServer('hallowelt.wsdl');
  $server->setClass('Webdienst');
  $server->handle();
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
