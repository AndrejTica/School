﻿/*
<?php
try {
  $client = new SOAPClient('http://localhost/home/phpkurs/webdienste/hallowelt.php?wsdl');
 
  print $client->halloWelt('Einem Webdienst Daten übergeben');
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
*/


<?php
try {
  $client = new SOAPClient('http://localhost/home/phpkurs/webdienste/hallowelt.php?wsdl');

 
  if (isset($cname)) 
  	print $client->halloWelt($cname);

  else { ?>

	<form action="halloweltclient-mit-wsdl.php" method="get">
	<h1>WEBDIENST-CLIENT: hallowelt (mit wsdl-Datei)</h1>
	<BOLD>Text an den Webservice: </BOLD>
	<input type="text" name="cname" size="40">
	<input type="submit" value="abschicken">
	</form>

	<?php exit();

  }
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
