<?php
try {
  $client = new SOAPClient(
    NULL,
    array(
      'location' => 'http://localhost/home/phpkurs/webdienste/hallowelt.php',
      'uri'      => 'http://localhost/home/phpkurs/webdienste/hallowelt',
      'style'    => SOAP_RPC,
      'use'      => SOAP_ENCODED
    )
  );

 
  if (isset($cname)) 
  	print $client->halloWelt($cname);	//aufruf des webdienstes

  else { ?>

	<form action="halloweltclient-ohne-wsdl.php" method="get">
	<h1>WEBDIENST-CLIENT: hallowelt</h1>
	<BOLD>Text an den Webservice: </BOLD>
	<input type="text" name="cname" size="40">
	<input type="submit" value="abschicken">
	</form>

	<?php exit();

	//  	print $client->halloWelt("select * from fragen");
  }
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
