http://xml.phpkurs.ch/kl/tag6/?m=6
Quelltext der Datei: ./tag6/soap/SOAPArticleServerPhp5.php

Dateigr�sse: 3.08 kb

[Anzeige mit Zeilennummern]

<?php
/**
* Die Klasse SOAPArticleServer<br />
* erzeugt einen SOAP-Server f�r die Artikeldatenbank
* mit der SOAP-Erweiterung
* @access public
* @package SPLIB
*/
class SOAPArticleServerPhp5 {
    /**
    * Objekt zum Datenbankzugriff
    * @access private
    * @var object
    */
    private $db;

    /**
    * Instanz von SOAP-Server
    * @access private
    * @var object
    */
    private $soapServer;

    /**
    * SOAPArticleServer constructor<br />
    * @param object instance of database access class
    * @param boolean auto start server
    * @access public
    */
    public function __construct($db, $root, $autostart = true) {
        error_reporting(E_ALL ^ E_NOTICE);
        $this->db= $db;
        if ( $autostart )
            $this->start($root);
    }

    /**
    * Returns an array of articles
    * @return array of objects
    * @access public
    */
    public function getArticles () {
        $sql="SELECT
                article_id, title, author
              FROM
                articles
              WHERE
                public = '1'
              ORDER BY
                title";
        $result=$this->db->query($sql);

        if ( $result->isError() )
            return new SoapFault('Server', 'Problem fetching data');

        $articles = array();
        while ( $row = $result->fetch() ) {
            $articles[]=$row;
        }
        return $articles;
    }

    /**
    * Return a single article
    * @param int article_id
    * @return object
    * @access public
    */
    public function getArticleById($articleID) {
        if ( !is_numeric($articleID) )
            return new SoapFault('Client', 'Expecting numeric article ID');

        $articleID=addslashes($articleID);

        $sql="SELECT
                title, author, body
              FROM
                articles
              WHERE
                article_id = '".$articleID."'";
        $result=$this->db->query($sql);

        if ( $result->isError() )
            return new SoapFault('Server', 'Problem fetching data');

        return $row = $result->fetch();
    }

    /**
    * Startet den Server und weist ihn an, nach
    * hereinkommenden Anfragen zu horchen<br/>
    * Falls das Argument autostart nicht mit dem Wert
    * false an den Konstruktor �bergeben wurde, wird die
    * Methode automatisch aufgerufen.
    * @return void
    * @access public
    */
    public function start($root) {
        $this->soapServer = new SoapServer($root.'/kl/tag6/soap/clientPEAR.php?wsdl');
        if (isset($_SERVER['REQUEST_METHOD']) &&
            $_SERVER['REQUEST_METHOD']=='POST') {
            $this->soapServer->handle();
        } else {
            if (isset($_SERVER['QUERY_STRING']) &&
                strcasecmp($_SERVER['QUERY_STRING'],'wsdl')==0) {
                header("Content-type: text/xml");
                $this->soapServer->handle();
            } else  {
                echo ('This is the new il600501 SOAP Server. Click
                <a href="?wsdl">here</a> for WSDL' );
            }
            exit;
        }
    }
}
?>

=====================================

Quelltext der Datei: ./tag6/soap/clientHF.php

Dateigr�sse: 455 bytes

[Anzeige mit Zeilennummern]

<?php
// Die Klasse MySQL einbinden
require_once('../../SPLIB/Database/MySQL.php');

// Die Klasse SOAPArticleServer einbinden
require_once('SOAPArticleServerPhp5.php');
require_once '../root.php';

// Variablen f�r die Klasse MySQL definieren
require_once("../../db_login.php");

// die Klasse MySQL instanziieren
$db= new MySQL($host,$dbUser,$dbPass,$dbName);

// Die Klasse ArticleServer instanziieren
$server= new SOAPArticleServerPhp5($db,$root);

?>

=====================================
Quelltext der Datei: ./tag6/soap/harryfuecks.php

Dateigr�sse: 2.69 kb

[Anzeige mit Zeilennummern]

<?php
require_once 'PEAR.php';
require_once '../root.php';
  
// Die Klasse ArticleClient instanziieren
$articleClient = new SoapClient($root.'/kl/tag6/soap/clientHF.php?wsdl');

// Start building a table
$table="<table>\n";

// If we're viewing a single article
if ( isset ( $_GET['id'] ) ) 
{
    // Call the getArticle() SOAP method
    $article = $articleClient->getArticleById($_GET['id']);

    // Handle any errors
    if (PEAR::isError($article)) 
    {
        $fault=$article->getFault();
        trigger_error('Fault: '.$fault->faultcode.' '.$fault->faultstring);
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>\n";
    } 
    else 
    {
        // Build the table
        $table.="<tr>\n<td class=\"title\">".$article->title.
                "</td>\n</tr>\n";
        $table.="<tr>\n<td class=\"author\">by ".$article->author.
                "</td>\n</tr>\n";
        $table.="<tr>\n<td>".$article->body."</td>\n</tr>\n";
    }

} 
else 
{
    // Call the getArticles() SOAP method
    $articles = $articleClient->getArticles();

    // Handle any errors
    if (PEAR::isError($articles)) 
    {
        $fault=$articles->getFault();
        trigger_error('Fault: '.$fault->faultcode.' '.$fault->faultstring);
        $table.="<tr>\n<td>Service unavailable at this time</td>\n</tr>\n";
    } 
    else 
    {
        // Loop through each article building the table
        foreach ( $articles as $article ) 
        {
            $table.="<tr>\n";
            $table.="<td><a href=\"".$_SERVER['PHP_SELF'].
                    "?id=".$article->article_id."\">".$article->title."</a></td>";
            $table.="<td>".$article->author."</td>";
            $table.="</tr>\n";
        }
    }
}

// Finish the table
$table.="</table>\n";
?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title> Sitepoint Articles </title>
<meta http-equiv="Content-type" content="text/html"
    charset="iso-8859-1" />
<style type="text/css">
h1 {
    font-family: verdana;
    font-size: 15px;
    font-weight: bold;
    color: navy;
}
table {
    background-color: silver;
    width: 450px;
}
th {
    background-color: #f2f3f5;
    font-family: verdana;
    font-size: 11px;
    font-weight: bold;
    text-align: left;
}
td {
    background-color: white;
    font-family: verdana;
    font-size: 11px;
}
a {
    font-weight: bold;
}
.title {
    font-size: 14px;
    font-weight: bold;
}
.author {
    font-weight: italic;
    text-align: right;
}
</style>
</head>
<body>
<h1>Latest Articles</h1>
<?php echo ( $table ); ?>
</body>
</html>

