﻿<html>
<head>
<title>Webservices: Client - Beispiel (BabelFischService)</title>
</head>
<body bgcolor="#cccccc">

<h1>Webservices: Client - Beispiel (BabelFischService)</h1>


<?php
if (isset($_GET['txt'])){

/*$client = new SoapClient("http://www.xmethods.net/sd/2001/BabelFishService.wsdl", 
										array('proxy_host'     => "pr-z.htl.org",
                                            'proxy_port'     => 8080,
                                            'proxy_login'    => "user@htl",
                                            'proxy_password' => "pwd"));
*/
$client = new SoapClient('http://www.xmethods.net/sd/2001/BabelFishService.wsdl');

$result = $client->BabelFish($_GET['von_nach'], $_GET['txt']);

echo "<h1>Original</h1>";
echo $_GET['txt'];

echo "<h1>&Uuml;bersetzung</h1>";
echo $result;

}
else { 
?>

<form action="babelfish-client.php" method="GET">
<table border="1" cellspacing="0" cellpadding="2">
<tr>
<td><b>Von-Nach:</b></td><td><input type="text" name="von_nach" value="de_en"></td>
</tr>

<tr>
<td><b>Von-Nach:</b></td><td><input type="text" size=60 name="txt" value="HALLO, WELT!"></td>
</tr>
<tr>
<td><b>&nbsp;</b></td><td><input type="submit" value="absenden"></td>
</tr>

</table>

<? 
}

?>
</body>
</html>
