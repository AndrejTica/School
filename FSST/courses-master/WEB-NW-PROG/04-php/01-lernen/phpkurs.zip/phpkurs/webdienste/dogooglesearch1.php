<?php

$search = isset($_POST['search']) ? $_POST['search'] : '';
$search_result = '';

if ($search != '')
{
    try
    {
        $google = new SoapClient("http://api.google.com/GoogleSearch.wsdl", array('trace' => 1));
        $togoogle  = "";    
        $togoogle .= $search;    
        echo "Ihre Anfrage: $togoogle";                        
        // Hier den Google-Key eintragen !!    
        $parameters = array(
            //'key'     => 'Rb/GjsZQFHL064rh/SLmY1vWvzpvN0/P',    
            'key'     => '1KpT5iFQFHJprYWf4uLyV9taCtuFTG17',    
            'q'          => $togoogle,                        
            'start'    => 0,                       
            'maxResults' => 10,                        
            'filter'=> FALSE,                        
            'restrict'=>'',                        
            'safeSearch'=>FALSE,                        
            'lr' => '',                        
            'ie' => '',                        
            'oe' => '');
               
        $result = $google->__call("doGoogleSearch", $parameters, array('urn:GoogleSearch'));    
        $num_result = $result->estimatedTotalResultsCount;    
        $elements = $result->resultElements;    
        $time = $result->searchTime;    
        $search_result = '';    
        if (is_array($elements))    
        {        
            $search_result  = "Es wurden $num_result Ergebnisse in $time Sekunden gefunden:<br/>";        
            foreach($elements as $item)        
            {            
            $size = $item->cachedSize;            
            $title = utf8_decode($item->title);            
            $url = $item->URL;            
            $text = utf8_decode($item->snippet);            
            $search_result.="<h3>$title ($size Byte)</h3>$text<br/><a href=\"$url\">$url</a>";        
            }    
        } 
        else 
        {    
            $search_result = "Es wurden keine Ergebnisse gefunden.";    
        }
    }
    catch (SoapFault $ex)
    {
        echo "Fehler bei der Verbindung: {$ex->faultstring}";
    }
}
echo '<form method="POST" action="'.$_SERVER['PHP_SELF'].'">        
        <input type="text" name="search" value="'.$search.'"/>        
        <input type="submit" value="Suchen"/>   
        </form>'; 
echo $search_result;
?>

