* Folien:
	E:\home\fh\vsys\2007\www\WorkshopWebdienste_v1.doc

* Uebung: Webdienste:

* http://localhost/home/phpkurs/webdienste/zeitdienst/zeit_client.php


* http://localhost/home/phpkurs/webdienste/babelfish.php


* http://localhost/home/phpkurs/webdienste/dogooglesearch1.php
	//mit eingabefeld f. die suche