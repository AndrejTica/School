<?php
try {
  $client = new SOAPClient(
    NULL,
    array(
      'location' => 'http://localhost/home/phpkurs/webdienste/zeitdienst/zeit_server.php',
      'uri'      => 'http://localhost/home/phpkurs/webdienste/zeitdienst/zeitdienst',
      'style'    => SOAP_RPC,
      'use'      => SOAP_ENCODED
    )
  );
 
  print "Aktuelle Uhrzeit: " . $client->zeit();
}
 
catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
