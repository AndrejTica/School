<?php
class Webdienst {
  public function zeit() {
    return 'Dein Webdienst sagt: Es ist jetzt: ' . date("H:i");
  }
}
 
try {
  $server = new SOAPServer(
    NULL,
    array(
      'uri' => 'http://localhost/home/phpkurs/webdienste/zeitdienst/zeitdienst'
    )
  );
 
  $server->setClass('Webdienst');
  $server->handle();

}catch (SOAPFault $f) {
  print $f->faultstring;
}
?>
