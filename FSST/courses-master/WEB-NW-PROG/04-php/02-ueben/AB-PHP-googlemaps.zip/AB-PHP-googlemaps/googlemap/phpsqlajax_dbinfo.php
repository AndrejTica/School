<?php
$username="schueler";
$password="comein";
$database="schueler";
?>