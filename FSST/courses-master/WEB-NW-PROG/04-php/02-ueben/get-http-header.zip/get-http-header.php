<?PHP
/***********************************************************************************
*** Script:     get-http-header.php                                              ***
*** Funktion:   Lesen und anzeigen des HTTP-Header einer �bergebenen URL         ***
*** Author:     Oliver Gehring                                                   ***
*** URL:        http://www.webmaster-imho.de                                     ***
*** Version:    1.0 - 11/2010                                                    ***
*** Lizenz:     Dieses Script ist Teil des HTTP-Tutorial im Webmaster-IMHO Blog. ***
***             http://www.webmaster-imho.de/webserver/http-protokoll-tutorial/  ***
***             Das Script (aber nicht das Tutorial!) darf frei kopiert,         ***
***             weitergegeben und ver�ndert werden, solage der oben aufgef�hrte  ***
***             Author sowie die URL mit angegeben wird.                         ***
***********************************************************************************/



  //keine Fehler anzeigen:
  ini_set("display_errors","Off");
//  ini_set("display_errors","On");

  
  //empfangene Daten pr�fen:
  if((isset($_POST["url"]))and($_POST["url"]<>""))
    $url=htmlentities(stripslashes($_POST["url"]),ENT_QUOTES);
  else $url="";  
  if(isset($_POST["data"]))
    $data=" checked";
  else $data="";  

?>
<html>
<head>
<title>Zeige HTTP-Header</title>
</head>
<body>

<div style="text-align:center;">
<h1>Zeige HTTP-Header</h1>
<h5><a href="http://www.webmaster-imho.de" target="_blank">Webmaster-IMHO... Der Webmaster Blog</a></h5>
<hr>
<br>
<b>Anzeige des Antwort-HTTP-Header vom Webserver f&uuml;r folgende URL:</b><br>
<form action="get-http-header.php" method="post">
<input name="url" type="text" size="100" value="<?php echo $url;?>">
<input type="submit" value="Header holen"><br>
<input type="checkbox" name="data" value="data"<?php echo $data;?>> auch den Datenteil der Server-Antwort anzeigen
</form>
<br><br><br>
<?PHP

  //URL parsen:
  //(hier m�sste nochmal eine richtige URL-Pr�fung hin)
  $url=str_replace("http://","",strtolower($url));
  if($url<>"")
    $array=@parse_url("http://".$url);

  //URL abfragen:  
  if(isset($array["host"]))
  {
    if(!isset($array["path"])) $array["path"]="/";
    if(isset($array["query"])) $array["path"].="?";
      else $array["query"]="";

    $hdl=@fsockopen($array["host"],80);
    if($hdl)
    {
      if($data<>"") $r=30;
        else $r=10;
      echo"<b>HTTP-Header der Server-Antwort:</b><br>\n";
      echo"<textarea readonly cols=\"80\" rows=\"".$r."\" wrap=\"off\" style=\"border:1px solid #000000\">\n";

      //HTTP GET Request senden:
      fputs($hdl,"GET ".$array["path"].$array["query"]." HTTP/1.1\n");
      fputs($hdl,"Host: ".$array["host"]."\n");
      fputs($hdl,"User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; de; rv:1.8.1.9) Gecko/20071025 Firefox/2.0.0.9\n");
      fputs($hdl,"Connection: close\n\n");

      //Antwort empfangen:
      $header=true;
      while(!feof($hdl) and $header)
      {
        $s=trim(fgets($hdl,4096));
        echo htmlentities($s,ENT_QUOTES)."\n";

        //wenn Header zu Ende den Empfang abbrechen:
        if(($s=="")and($data=="")) $header=false;
      }
      fclose($hdl);

      echo"</textarea>\n";
    }
    else
      echo"<b>Achtung:</b> Die URL konnte nicht ge&ouml;ffnet werden!";
  }
  elseif($url<>"")
    echo"<b>Achtung:</b> Die &uuml;bergebene URL wurde nicht erkannt.";
?>
</div>

</body>
</html>
