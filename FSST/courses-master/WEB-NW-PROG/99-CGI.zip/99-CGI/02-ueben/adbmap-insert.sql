INSERT INTO  `adbmap`.`adbmap` (
`nickname` ,`email` ,`comment` ,`address` ,`lat` ,`lng`)
VALUES (
'ich',  'ich@email',  'ich bin es',  'www.ich.com',  '47.123577',  '7.12452'
);
INSERT INTO  `adbmap`.`adbmap` (
`nickname` ,`email` ,`comment` ,`address` ,`lat` ,`lng`)
VALUES (
'du',  'du@email',  'du bist es',  'www.du.com',  '47.123577',  '7.12452'
);
INSERT INTO  `adbmap`.`adbmap` (
`nickname` ,`email` ,`comment` ,`address` ,`lat` ,`lng`)
VALUES (
'er',  'er@email',  'er ist es',  'www.er.com',  '47.123577',  '7.12452'
);
INSERT INTO  `adbmap`.`adbmap` (
`nickname` ,`email` ,`comment` ,`address` ,`lat` ,`lng`)
VALUES (
'sie',  'sie@email',  'sie ist es',  'www.sie.com',  '47.123577',  '7.12452'
);
INSERT INTO  `adbmap`.`adbmap` (
`nickname` ,`email` ,`comment` ,`address` ,`lat` ,`lng`)
VALUES (
'es',  'es@email',  'es ist es',  'www.es.com',  '47.123577',  '7.12452'
);
