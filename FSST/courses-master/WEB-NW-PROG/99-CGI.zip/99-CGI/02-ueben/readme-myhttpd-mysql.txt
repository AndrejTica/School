#
# myhttpd-mysql
#
# eigner HTTP-Service mit Zugriff auf 
# MySql: DB=adbmap; user=adbmap; table=adbmap
# 
# Vorbedinungen: t_fileserver.c
#

0. cd /opt/lampp/cgi-bin/cgikurs

1. mkdir myhttpd-mysql
   cd myhttpd-mysql

2. copy t_fileserver.c
   cp ../fileserver/t_fileserver.c .

3. edit: t_fileserver.c
   3.1. soll auf port 80 starten
   3.2. soll die vom socket gelesenen Daten ausgeben 
	    printf("got= <%s>\n",buf);
   3.3. soll den Dateinamen extrahieren, öffnen und
	 über den socket ausgeben.
	 
4. t_fileserver.exe erzeugen und starten
   gcc t_fileserver.c -o t_fileserver.exe
   sudo ./t_fileserver.exe

5. mysql starten
   /opt/lampp/lampp startmysql
   
6. Das HTML-Formular kopieren
   cp /opt/lampp/htdocs/cgikurs/mysql/adbmap.htm .
   edit: adbmap.htm
   <form action="" method="GET">   d.h. action muss leer sein.
   
7. Web-Browser starten und folg. URL eingeben
   http://localhost/adbmap.htm
   
   Anmerkung: im Verzeichnis myhttpd-mysql sind folg. Dateien
        1. adbmap.htm
        2. t_fileserver.exe, t_fileserver.c
        
   mit http://localhost/adbmap.htm wird eben diese Datei adbmap.htm geladen.

   D.h.
   adbmap.htm wird von t_fileserver.exe "ausgeliefert"
   
   Anm: auch folg. Datei kann geladen werden.
   http://localhost/t_fileserver.c
   

8. Wir wollen nun das fileserver-programm für den Zugriff auf 
   MySql umschreiben.
   
   cp t_fileserver.c myhttpd-mysql.c


   Aufgabenstellung:
                    port 80
                    lies Nachricht vom Client

                    falls
                    GET /adbmap.htm HTTP 1.1.....
                    lies Datei ein und gib sie an
                    Client zurück
 
                    falls
                    GET /adbmap.htm?xxx=yyy ........  vorkommt
                    wird der Text analysiert und 
                    entsprechend dem adbmap-Beispiel weiter verfahren


  Zur Information:
                    GET /adbmap.htm?command=List
                    GET /adbmap.htm?command=GetEmail&nickname=chefin
                    GET /adbmap.htm?command=Delete&nickname=chefin
                    GET /adbmap.htm?command=Insert&nickname=nickname&email=email&comment=comment



Die einfache Lösung:  putenv(), popen(), fgets()

   Beim Interpretieren des Textes verwenden wir das zuvor geschriebene Programm
   in 
   
   /opt/lampp/cgi-bin/cgikurs/mysql/adb_main.cgi
   
   Denn dieses Programm analysiert den sog. QUERY_STRING und stellt die
   Schnittstelle zur MySQl Datenbank her. 
   
   Die MySql-Abfrageergebnisse werden auf stdout geschrieben.
   Genau das was wir brauchen können. 
   Denn wir wissen, dass man mit popen() ein Programm 
   starten kann und stdout dieses Programmes mit fgets auslesen kann.
   
   Wenn wir wissen, dass man mit putenv() eine Umgebungsvariable setzen kann, 
   ist alles ganz einfach.
   
   Hier eine kurze Zusammenfassung:
	       * INTERPRETIERE QUERY_STRING
	       * Webclient schickt zB:
	       * GET /adbmap.htm?command=Delete&nickname=1 HTTP/1.1
	       
	       * Lösung:
	       * selektiere substring
	       *      command=Delete&nickname=1
	       * setze mit putenv die Environmentvariable QUERY_STRING
	       * 
	       * starte mit popen ("./adb_main.cgi")
	       * lies Ausgabe von popen aus und
	       * sende diese an den Webclient

	    
	    // adb_main.cgi macht die eigentliche Arbeit
	    //    interpretiert die Environmentvariable QUERY_STRING und
	    //    führt die Aufrufe zur Datenbank durch
	    //    die Ausgabe wird an stdout geschickt.
	    //
	    // Diese Ausgabe wird von popen() ausgegeben und mit fgets()
	    // gelesen und an das Web-client Programm geschickt.

9. gcc myhttpd-mysql.c -o myhttpd-mysql.exe

10. sudo ./myhttpd-mysql.exe

11. http://localhost/adbmap.html
12. fertig