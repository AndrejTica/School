================================================================================
Projekt: Diplomarbeiten der HTL-Salzburg als eBOOK
================================================================================
TODO 1:
	Quelle: www.htl-innovativ.at
	Export der HTL-Salzburg Daten: --> htl_projekte.csv
	
TODO 2:
	htl_projekte.csv in eine mysql-DB importieren
	user/db/Tabelle: htl_projekte 

TODO 3:
	c-Programm: htl_projekte_ebook.c mit 
		a) Zugriff auf die DB und
		b) erstellen einer HTML-Datei
		
	Aufruf:
	./htl_projekte_ebook.exe "where jahr='2012'" > htl_projekte_2012.html
	./htl_projekte_ebook.exe < "where jahr='2012' or jahr='2011'" > htl_projekte_2011_2012.html
	...
		
TODO 4:
	Erstellen des eBook:
	mit calibre, jutoh bzw. ecub





--------------------------------------------------------------------------------
TODO 2:
	htl_projekte.csv in eine mysql-DB importieren
	user/db/Tabelle: htl_projekte 
--------------------------------------------------------------------------------

1. Mysql: http://localhost/phpmyadmin
-------------------------------------
* CREATE DATABASE htl_projekte
* CREATE USER htl_projekte

CREATE TABLE `htl_projekte` (
  `id` int(11) NOT NULL auto_increment,
  `titel_ger` varchar(255) NOT NULL default '',
  `titel_eng` varchar(255) NOT NULL default '',
  `abstrakt_ger` text NOT NULL,
  `abstrakt_eng` text NOT NULL,
  `typ` varchar(20) default NULL,
  `kat_id` int(11) default NULL,
  `stichworte_ger` varchar(255) default NULL,
  `stichworte_eng` varchar(255) default NULL,
  `jahr` smallint(6) default NULL,
  `klasse` varchar(50) default NULL,
  `skz` mediumint(9) NOT NULL default '0',
  `abteilung` varchar(255) NOT NULL default '',
  `betreuer` varchar(255) NOT NULL default '',
  `zus_betreuer` varchar(255) NOT NULL default '',
  `team` text NOT NULL,
  `team_leader` varchar(255) NOT NULL default '',
  `team_mail` varchar(255) NOT NULL default '',
  `link` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `adminlink` varchar(25) default NULL,
  `schuelerlink` varchar(25) default NULL,
  `anmerkung` text,
  `genehmigt` tinyint(4) NOT NULL default '0',
  `bild` varchar(255) NOT NULL default '',
  `datei` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `i_kat_id` (`kat_id`),
  FULLTEXT KEY `i_ft_titel_stichworte_ger` (`titel_ger`,`stichworte_ger`),
  FULLTEXT KEY `i_ft_titel_stichworte_eng` (`titel_eng`,`stichworte_eng`)
) ENGINE=MyISAM 

DEFAULT CHARSET=latin1 AUTO_INCREMENT=4372 ;
 



2. Mysql: http://localhost/phpmyadmin
-------------------------------------
csv-Datei in DB laden

Database htl_projekte auswählen
->SQL
LOAD DATA LOCAL
        INFILE '/home/ahofmann/htl_projekte.csv'
        REPLACE
        INTO TABLE htl_projekte
        FIELDS
                TERMINATED BY ';'
                OPTIONALLY ENCLOSED BY '"' 
                
                
                
3. Test, ob alles funktioniert hat
---------------------------------------
SELECT `id`,`titel_ger`,`jahr`,`klasse`,`team`,`abstrakt_ger` FROM `htl_projekte` 


*** FERTIG ***



--------------------------------------------------------------------------------
TODO 3:
	c-Programm: htl_projekte_ebook.c mit 
		a) Zugriff auf die DB und
		b) erstellen einer HTML-Datei
		
	Aufruf:
	./htl_projekte_ebook.exe "where jahr='2012'" > htl_projekte_2012.html
	./htl_projekte_ebook.exe < "where jahr='2012' or jahr='2011'" > htl_projekte_2011_2012.html
	...
--------------------------------------------------------------------------------

* Verzeichnis erstellen und dorthin wechseln: 
---------------------------------------------
	/opt/lampp/cgi-bin/cgikurs/htl_projekte_ebook

* Verzeichnis erstellen und Bilder dorthin kopieren: 				
---------------------------------------------
	/opt/lampp/cgi-bin/cgikurs/htl_projekte_ebook/bilder



* CSS-Datei erstellen: htl_projekte_ebook.css
---------------------------------------------
﻿
/* htl_projekte_ebook.css
 * 
 * legt die Hintergrundfarbe und den Rand für die gesamte Seite fest 
 */
body { background-color:#FFFFCC; margin:0px; padding:45px 35px 45px 25px; }


/* Schriftart für alle Elemente die Schrift enthalten */
p,div,ul,ol,h1,h2,h3,h4,h5,th,td { font-family:Arial,sans-serif; }


/* seperate Schriftfarbe für Überschriften */
h1,h2,h3,h4 { color:#990000; }

/* Schriftgrößen */
h1 { font-size:32px; }
h2 { font-size:27px; }
h3 { font-size:22px; }
h4 { font-size:18px; }
h5 { font-size:16px; }
p,div,ol,ul,td,th { font-size:14px; }


/* Ein Rahmen mit gerundeten Kanten */
.div2
{
border:1px solid #aaaaaa;
left:200px;top:50px;

padding: 6px;
padding-top: 6px;
padding-bottom: 6px;

margin-buttom: 30px;

-moz-border-radius:10px;
-khtml-border-radius:30px;
}

/* tabellen */
table {
   border-collapse: collapse;
   text-indent:5px; 
   background-color: #FFFFDD;
   }
 


* C-Programm erstellen: htl_projekte_ebook.c
---------------------------------------------
/*
 * htl_projekte_ebook.c
 * 
 * gcc -I/opt/lampp/include -L/opt/lampp/lib/mysql -lmysqlclient htl_projekte_ebook.c -o htl_projekte_ebook.exe
 * 
 *  Aufruf: ./htl_projekte_ebook.exe "jahr='2012'" > htl_projekte_ebook_2012.html

 *
 * todo: install mysql-development-package: see: www.apachefriends.org
 * todo: gedit /etc/ld.so.config.d/lampp-mysql.conf
 *       /opt/lampp/lib/mysql
 * 
 * ldconfig -v
 */

#include <stdio.h>
#include <mysql.h>
#include <stdlib.h>

#define HOST "localhost"
#define USER "root"
#define PWD ""
#define DB "htl_projekte"
#define TABLE "htl_projekte"


#define SQL "SELECT id, titel_ger, abstrakt_ger, stichworte_ger,team, team_leader, jahr,typ,klasse,betreuer,abteilung FROM `htl_projekte`"

#define id 0
#define titel_ger 1
#define abstrakt_ger 2
#define stichworte_ger 3
#define team 4
#define team_leader 5
#define jahr 6
#define typ 7
#define klasse 8
#define betreuer 9
#define abteilung 10


int main (int argc, char *argv[]){
	MYSQL *mysql;
	MYSQL_ROW  row;
	MYSQL_RES  *res;
	 
	char sql[2048];
	char buf[2048];
	
	if (argc > 1){
	   // where - klausel aufnehmen
	    sprintf(sql, "%s %s ", SQL, argv[1]);
	}
	else{
	    sprintf(sql, "%s", SQL);
	}
	
	
        //HTTP-Body
	printf("<html><head><title>Diplomarbeiten der HTL Salzburg/Elektronik</title>\n");
//	printf("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
	printf("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=latin1\">\n");
	
	printf("<link rel=\"stylesheet\" type=\"text/css\" href=\"htl_projekte_ebook.css\">\n");
	printf("</head>\n");
    printf("<body>\n");



???????????????????????????????????????????????????????????????????????????
﻿	while ((row = mysql_fetch_row (res)) != NULL) {
	    mysql_field_seek (res, 0);

//Überschrift h1	    
	    printf("<h1>%s</h1>\n", row[ titel_ger ]);

	    
	    printf("<div class=\"div2\">");

//foto und logo	    
	    sprintf(buf, "<img src=\"bilder/foto-%s.jpg\" width=\"160\" height=\"120\" border=\"2\"  alt=\"Team\"> &nbsp; &nbsp;", row[id]);
	    printf("%s\n", buf);
	    
	    sprintf(buf, "<img src=\"bilder/logo-%s.jpg\" width=\"160\" height=\"120\" border=\"2\"  alt=\"Logo\"> &nbsp; &nbsp;", row[id]);
	    printf("%s\n", buf);

//Abstrakt
	    printf("<p>%s</p>\n", row[ abstrakt_ger]);
	    
	    
//Schlagworte	    
	    printf("<p><b>Schlagworte:</b> %s</p>\n", row[ stichworte_ger]);
	    
//Projektteam      
      
	    printf("<table border=1>");

	    printf("<tr>");
	    printf("<td>Projektteam:");
	    printf("</td>");
	    printf("<td>");
	    printf("<b>%s , %s , %s</b>\n", row[ team_leader], row[ team], row[klasse ]);
	    printf("</td>");
	    printf("</tr>\n");

   	    printf("<tr>");
	    printf("<td>Jahr/Typ:");
	    printf("</td>");
	    printf("<td>");
	    printf("<b>%s, %s</b>\n", row[ jahr], row[typ]);
	    printf("</td>");
	    printf("</tr>\n");

	    printf("<tr>");
	    printf("<td>BetreuerIn");
	    printf("</td>");
	    printf("<td>");
	    printf("<b>%s</b>\n", row[ betreuer]);
	    printf("</td>");
	    printf("</tr>\n");

	    printf("<tr>");
	    printf("<td>Abteilung/Kontakt:");
	    printf("</td>");
	    printf("<td>");
	    printf("<b>%s</b>\n", row[ abteilung]);
	    printf("</td>");
	    printf("</tr>\n");

	    
	    printf("</table>\n");
	
   printf("</div>\n");

//wegen calibre ????
printf("<div style=\"page-break-before: always\"></div>\n");	    
	}
	
??????????????????????????????????????????????????????????????????????????????



	printf("</body></html>");
	return 0;
}


---------------------------------------------------------------------------
TODO 4:
	Erstellen des eBook:
	mit calibre, jutoh bzw. ecub
	
	EBOOK: 
	html und calibre
---------------------------------------------------------------------------

* ordner erstellen
	/opt/lampp/cgi-bin/htl_projekte_ebook/ebook

* Dateien reinkopieren
	.html
	.css
	bilder  (ordner mit foto####.jpg und logo####.jpg)
	cover.jpg (kann mit ecub bearbeitet werden)

calibre
	1. neues buch
	2. html hinzufügen
	3. metadaten einzeln
		cover.jpg
	4. inhaltsverz.
		1. checkbox
		2. //h:h1

		









99. +ZUsatzinfo: WEB-LINKS
--------------------------------------
http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&stylesheet=http%3A%2F%2Fsrv05173.members.omanbros.com%2Ffileadmin%2Fvorlagen%2Fstyles%2Fhtlinnovativ.css&sitesize=0&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg



http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&hide_az=1&hide_sortierung=1&stylesheet=http://srv05173.members.omanbros.com/fileadmin/vorlagen/styles/htlinnovativ.css&&projekt_id=4235


http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417

http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&sitesize=0&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg




Alle Projkete der HTL 501417
http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&sitesize=1000&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg


============================================================
Projekt: Diplomarbeiten der HTL-Salzburg als Bilder-Gallerie
============================================================
tiltviewer, simpleviewer


============================================================
Projekt: Diplomarbeiten der HTL-Salzburg als Bilder-Gallerie
============================================================
wordpress und bilder-Galerie

