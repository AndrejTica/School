================================================================================
Projekt: Diplomarbeiten der HTL-Salzburg als tiltview-gallery
================================================================================
	Aufgabe1:
		csv-Datei in eine mysql-DB importieren
		DB/USER/TABelle: htl_projekte
		
		
	Aufgabe2:
		c-Programm mit 
			a) Zugriff auf die DB und
			b) erstellen der Datei gallery.xml
			
	Aufgabe3:
		Anpassung der index.html (farben, css-Einstellungen
		
		
-------------------------------------------------------------------------------
Aufgabe2:
	c-Programm mit 
		a) Zugriff auf die DB und
		b) erstellen der Datei gallery.xml			
-------------------------------------------------------------------------------

* Verzeichnis:
/opt/lampp/cgi-bin/cgikurs/htl_projekte_tiltviewer



* C-Programm:
htl_projekte_tiltviewer.c
vgl. ikt5-readme-todo-ebook.txt

* Erstellen Sie die Datei: gallery.xml

<tiltviewergallery>
<photos>
  <photo imageurl="imgs/XXXBILDXXX.jpg" 
      linkurl="http://www.htl-innovativ.at/index.php?lang=ger&modul=detail&id=XXXIDXXX">
    <title>XXXTITELXXX</title>
    <description>
      XXXTEAMXXX
      XXXABSTRAKT_GERXXX
      XXXJAHRXXX,XXXKLASSEXXX
    </description>
  </photo>
.....
</photos>
</tiltviewergallery>

 

-------------------------------------------------------
Aufgabe3:
	Anpassung der index.html (farben, css-Einstellungen)
-------------------------------------------------------




		




99. +ZUsatzinfo: WEB-LINKS
--------------------------------------
http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&stylesheet=http%3A%2F%2Fsrv05173.members.omanbros.com%2Ffileadmin%2Fvorlagen%2Fstyles%2Fhtlinnovativ.css&sitesize=0&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg



http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&hide_az=1&hide_sortierung=1&stylesheet=http://srv05173.members.omanbros.com/fileadmin/vorlagen/styles/htlinnovativ.css&&projekt_id=4235


http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417

http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&sitesize=0&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg




Alle Projkete der HTL 501417
http://www.htl-innovativ.at/htl_innovativ_data.php?skz=501417&sitesize=1000&hide_az=1&hide_statistik=0&hide_sortierung=1&order=jg

